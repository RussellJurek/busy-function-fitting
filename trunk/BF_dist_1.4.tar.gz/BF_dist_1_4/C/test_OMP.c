#include<stdlib.h>
#include<stdio.h>
#include<omp.h>

int main(){

  int i = omp_get_num_procs();
  printf("%d cores found.\n",i);

}

