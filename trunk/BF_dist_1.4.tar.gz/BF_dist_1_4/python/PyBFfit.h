/*

This is version 1.4 of the C BusyFunc library that fits the Busy Function to data.
See Westmeier, Jurek, Obreschkow, Koribalski & Staveley-Smith (2013) for more details about the implementation
and the Busy Function.

v1.4 updates
------------
1. Removed the (>= 0.0) constraint on the power-law scaling.
2. Changed the 2 <= n <= 8 power-law index constraint to 1 <= n <= 8.
3. BUG FIX: The partial derivative of the BF with respect to the power-law exponent, n, was previously over-estimated 
in magnitude by 33%.
4. BUG FIX: The function ApproxObsCovar was using an incorrect range when applying/removing the power-law exponent's 
internal re-mapping.

v1.3 updates
------------
None.

v1.2 updates
------------
1. Created a version of the v1.1 C/C++ library that doesn't use OMP.
2. Python setup.py script uses the files, PyBFfit.h and libPyBFfit.a. These are symbolic links to either the 
OMP or non-OMP enabled C libraries.

v1.1 updates
------------
1. Added the ability to generate random variants of a Busy Function fit from a fit's covariance matrix.
2. The number of LVM seeds and maximum iterations per seed *must* now be specified. Previously, 1000 seeds and 30 
iterations/seed were used.
3. A single, 8 parameter BF curve can be used as the sole LVM seed. This is achieved by populating the fit_params array 
and requesting -1 LVM seeds.
4. BUG FIX: In v1.0, the best fit of previous BF variants were changing the values of x_min and x_max when 
FitBusyFunc_engine was called for a given BF variant. This has been corrected. x_min and x_max are now calculated from 
the values mid and amp, which are calculated only once at the beginning of FitBusyFunc.
5. FitBusyFunc now returns an integer value corresponding to the BF variant that returned the best fit. This change was 
made, because the fit dimensionality is not a unique identifier. The fit dimensionality is now returned in a variable
that is passed by reference, best_NOp.

Email: Russell.Jurek@gmail.com

Version 1.4 created September 23rd, 2014 by Russell J. Jurek.
Version 1.3 created September 15th, 2014 by Russell J. Jurek.
Version 1.2 created December 26th, 2013 by Russell J. Jurek.
Version 1.1 created November 9th, 2013 by Russell J. Jurek.
Version 1.0 created June 30th, 2013 by Russell J. Jurek.

*/

#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<omp.h>
#include<time.h>

#ifndef _cBFfit_
#define _cBFfit_

// Chain of functions that carry out Busy Function fitting --- multiple versions for float and double typed data

void BusyFunc(double x, double a[], double *y, double dyda[], int fit_mode, double mid, double amp);

void FitBusyFunc_engine_flt(int NOvals, float * x_vals, float * y_vals, float * n_vals, double * model_params, int fit_mode, int NOs, double ** start_vals, double mid, double amp, double ** fit_covar, int iter_max, int vb_flag);

void FitBusyFunc_engine_dbl(int NOvals, double * x_vals, double * y_vals, double * n_vals, double * model_params, int fit_mode, int NOs, double ** start_vals, double mid, double amp, double ** fit_covar, int iter_max, int vb_flag);

int FitBusyFunc_flt(int NOvals, float * x_vals, float * y_vals, float * n_vals, float * fit_params, float ** fit_covar, int * best_NOp, int NOs, int iter_max, int vb_flag);

int FitBusyFunc_dbl(int NOvals, double * x_vals, double * y_vals, double * n_vals, double * fit_params, double ** fit_covar, int * best_NOp, int NOs, int iter_max, int vb_flag);

void covsrt(double **covar, int ma, int ia[], int mfit);

void mrqcof_flt(float x[], float y[], float sig[], int ndata, double a[], int ia[], int ma, double **alpha, double beta[], double *chisq, void (*funcs) (double, double [], double *, double [], int, double, double), int fit_mode, double mid, double amp);

void mrqcof_dbl(double x[], double y[], double sig[], int ndata, double a[], int ia[], int ma, double **alpha, double beta[], double *chisq, void (*funcs) (double, double [], double *, double [], int, double, double), int fit_mode, double mid, double amp);

int mrqmin_flt(float x[], float y[], float sig[], int ndata, double a[], int ia[], int ma, double **covar, double **alpha, double *chisq, void (*funcs)(double, double [], double *, double [], int, double, double), double *alamda, int fit_mode, double mid, double amp, int * mfit, double * ochisq, double * atry, double * beta, double * da, double ** oneda);

int mrqmin_dbl(double x[], double y[], double sig[], int ndata, double a[], int ia[], int ma, double **covar, double **alpha, double *chisq, void (*funcs)(double, double [], double *, double [], int, double, double), double *alamda, int fit_mode, double mid, double amp, int * mfit, double * ochisq, double * atry, double * beta, double * da, double ** oneda);

void svbksb(double **u, double w[], double **v, int m, int n, double b[], double x[]);

void svdcmp(double **a, int m, int n, double w[], double **v);
 
double ran2(long * idum);

double pythag(double a, double b);

// functions used to generate an arbitrary number of correlated Busy Function fit parameters,
// and derive uncertainties in observational properties

void choldc(double ** a, int n);

double inverf(double p);

void CreateRandFits_flt(int NOr, float ** rand_fits, int fit_type, float * BF_fit, float ** BF_covar, double x_min, double x_max, int vb_flag);

void CreateRandFits_dbl(int NOr, double ** rand_fits, int fit_type, double * BF_fit, double ** BF_covar, double x_min, double x_max, int vb_flag);

void CalcObsParams_flt(int NOr, float ** rand_fits, int NOvals, float * x_vals, float ** obs_vals, int vb_flag);

void CalcObsParams_dbl(int NOr, double ** rand_fits, int NOvals, double * x_vals, double ** obs_vals, int vb_flag);

void heapsort_flt(int n, float ra[]);

void heapsort_dbl(int n, double ra[]);

void AnalyseObsVals_flt(int NOr, int NOprops, float ** obs_vals, float ** obs_stats, int vb_flag);

void AnalyseObsVals_dbl(int NOr, int NOprops, double ** obs_vals, double ** obs_stats, int vb_flag);

// functions to calculate a linear approximation of the observable parameter covariance matrix
void ApproxObsCovar_flt(int fit_type, int NOvals, float * x_vals, float * fit_params, float ** fit_covar, float ** obs_covar, double x_min, double x_max);

void ApproxObsCovar_dbl(int fit_type, int NOvals, double * x_vals, double * fit_params, double ** fit_covar, double ** obs_covar, double x_min, double x_max);

#endif




