#!/usr/local/bin/python

#####################################################################################################
#                                                                                                   #
# This is the python demo script for version 1.4 of the module that fits the Busy Function to data. #
# See Westmeier, Jurek, Obreschkow & Koribalski (2013) for more details about the implementation    #
# and the Busy Function.                                                                            #
#                                                                                                   #
# Created by Russell J. Jurek, 3rd September 2014.                                                  #
# Email: Russell.Jurek@gmail.com                                                                    #
#                                                                                                   #
#####################################################################################################

# import libraries
import sys;
import re;
import BusyFunc;
import matplotlib;
import matplotlib.pyplot as plt;
import scipy.special;
import math;

# define the main() function
def main():

    # check that sufficient arguments were entered on the command line
    if(int(len(sys.argv)) < 2):
        #print "Insufficient number of arguments. Use 'python FitSpectrum -h' to see script usage.",
        print("Insufficient number of arguments. Use 'python FitSpectrum -h' to see script usage.");
        sys.exit()

    # check if the first argument is -h or -H and display help message
    if((str(sys.argv[1]) == "-h") or (str(sys.argv[1]) == "-H")):
        print("Instructions for FitSpectrum: \n\nThis program uses the C/C++ Busy Function fitting library to fit the Busy Function to a single spectra. This program assumes that each line of the input file contains an x and y value, as well as an optional noise value for each (x,y). This program also assumes space delimited input files.\n\nUsage: FitSpectrum input_file [x_col] [y_col] [noise_col] [-v or -vv] \n       FitSpectrum -h\n\nThe input_file is the only mandatory input. All other inputs are optional, which is represented by []. The optional inputs are:\nx_col: The column containing the x values. Count from 0. Default is 0.\ny_col: The column containing the y values. Count from 0. Default is 1.\nnoise_col: The column containing the noise values. Default is -99, which assigns a value of 1 for every x.\n-v: Turn verbosity to medium (default is none).\n-vv: Turn verbosity to high (default is none).\n\nThe fitting results are written to the terminal. The first value is the dimensionality of the best fitting BF model. The next 16 values are the BF fit parameters and their uncertainties (listed in value, error pairs). The next value is chi^2. The remaining 64 values are the chi^2 covariance matrix.\nThe values are written out in scientific notation to accommodate especially large or small values.\n"); 
        sys.exit()

    # open input file
    print("Opening input file: " + sys.argv[1]);
    try:
        input_file = open(sys.argv[1],'rU');
    except:
        print("WARNING!!! Failed to open input file. Exiting.");
        sys.exit()

    # set the input columns
    x_col = 0;
    y_col = 1;
    y_err_col = 2;
    vb_flag = -1;
    if(len(sys.argv) > 2):
        x_col = int(sys.argv[2]);
        y_col = int(sys.argv[3]);
        if(len(sys.argv) >= 4):
            for i in range(4,len(sys.argv)):
                if(str(sys.argv[i]) == "-v"):
                    vb_flag = 0;
                elif(str(sys.argv[i]) == "-vv"):
                    vb_flag = 1;
                else:
                    y_err_col = int(sys.argv[4]);

    # initialise x_vals, y_vals and y_errs lists
    x_vals = [];
    y_vals = [];
    y_errs = [];

    # read input file into three arrays: x_vals, y_vals and y_errs
    print("Reading columns " + str(x_col) + "," + str(y_col) + "," + str(y_err_col) + " into x_vals, y_vals and y_errs.");
    for line in input_file:
        match = re.search(r'^#',line);
        if(match == None):
            row = line.split();
            x_vals.append(float(row[x_col]));
            y_vals.append(float(row[y_col]));
            y_errs.append(float(row[y_err_col]));

    # close the input file
    print("Closing input file: " + sys.argv[1]);
    input_file.close();

    # call the Busy Function fitting routine 
    # 1. Set the x-range containing signal (VERY conservative --- set to limits of data)
    x_min = x_vals[0] + (0.05 * (x_vals[(len(x_vals) - 1)] - x_vals[0]));
    x_max = x_vals[0] + (0.95 * (x_vals[(len(x_vals) - 1)] - x_vals[0]));
    print("Calling BusyFunc.fit with vb_flag 0, x_min = " + str(x_min) + " & x_max = " + str(x_max)); 
    # 2. Call the BusyFunc.fit function in the BusyFunc module 
    fit_type, dim, fit_params, fit_covar = BusyFunc.fit(x_vals,y_vals,y_errs,vb_flag,x_min,x_max,1000,30);

    # refine the Busy Function fit
    fit_type, dim, fit_params, fit_covar = BusyFunc.refine(x_vals,y_vals,y_errs,vb_flag,3000,fit_params)

    # print the BF fitting results to the terminal
    print("Busy Function fit results (fit type = " + str(fit_type) + ", " + str(dim) + " dimensions):");
    i = 0;
    line = "";
    for i in range(8):
        line = line + str(fit_params[(2 * i)]) + " +/- " + str(fit_params[((2 * i) + 1)]) + ", ";
    print(line); 
    print("chi^2 = " + str(fit_params[16]));
    print("Busy Function fit covariance matrix:");
    j = 0;
    for j in range(8):
        i = 0;
        line = "";
        for i in range(8):
            line = line + str(fit_covar[j][i]) + " ";
        print(line);

    # generate 10,000 random BF fit variants
    rand_fits = BusyFunc.rand_fits(10000,fit_type,fit_params,fit_covar,x_min,x_max,vb_flag)

    # calculate observational values for each random BF variant
    obs_vals = BusyFunc.obs_vals(rand_fits,x_vals,vb_flag)

    # calculate statistical properties of observational parameters
    obs_stats = BusyFunc.obs_stats(obs_vals,vb_flag)

    # display statistics
    print("Total intensity --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis ");
    i = 0;
    line = "";
    for i in range(8):
        line = line + str(obs_stats[0][i]) + " ";
    print(line);
    print("Peak intensity --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis ");
    i = 0;
    line = "";
    for i in range(8):
        line = line + str(obs_stats[1][i]) + " ";
    print(line);
    print("Peak intensity position --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis ");
    i = 0;
    line = "";
    for i in range(8):
        line = line + str(obs_stats[2][i]) + " ";
    print(line);
    print("W_50 width --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis ");
    i = 0;
    line = "";
    for i in range(8):
        line = line + str(obs_stats[3][i]) + " ";
    print(line);
    print("W_50 position --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis "); 
    i = 0;
    line = "";
    for i in range(8):
        line = line + str(obs_stats[4][i]) + " ";
    print(line);
    print("W_20 width --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis ");
    i = 0;
    line = "";
    for i in range(8):
        line = line + str(obs_stats[5][i]) + " ";
    print(line);
    print("W_20 position --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis ");
    i = 0;
    line = "";
    for i in range(8):
        line = line + str(obs_stats[6][i]) + " ";
    print(line);

    # calculate a linear approximation of the observational parameter covariance matrix
    approx_errs, approx_obs_covar = BusyFunc.approx_obs_covar(fit_type,x_vals,fit_params,fit_covar,x_min,x_max)

    # display linear approximation of the observational parameter covariance matrix
    print("Observational parameter covariance matrix:");
    j = 0;
    for j in range(7):
        i = 0;
        line = "";
        for i in range(7):
            line = line + str(approx_obs_covar[j][i]) + " ";
        print(line);
    
    # display corresponding uncertainties in observational parameters
    print("Resultant errors:");
    i = 0;
    line = "";
    for i in range(7):
        line = line + str(approx_errs[i]) + " ";
    print(line);

    # plot the results
    print("Generating plots . . . ")

    # plotting variables
    NOa = 1501
    hist_vals = []
    for i in range(10):
        hist_vals.append(0.0)
    hist_HD_vals = []
    for i in range(100):
        hist_HD_vals.append(0.0)
    hist2D_vals = []
    for i in range(10):
        hist2D_vals.append([])
        for j in range(10):
            hist2D_vals[i].append(0.0)
    hist2D_HD_vals = []
    for i in range(100):
        hist2D_HD_vals.append([])
        for j in range(100):
            hist2D_HD_vals[i].append(0.0)
    p_min = [9E30,9E30,9E30,9E30,9E30,9E30,9E30,9E30]
    p_max = [-9E30,-9E30,-9E30,-9E30,-9E30,-9E30,-9E30,-9E30]
    mapped_fit = [0,0,0,0,0,0,0,0]
    inv_covar_proj = [[0,0],[0,0]]
    
    # determine range of BF fit random variants
    for i in range(10000):
        for j in range(8):
            p_max[j] = p_max[j] if (p_max[j] > rand_fits[i][j]) else rand_fits[i][j]
            p_min[j] = p_min[j] if (p_min[j] < rand_fits[i][j]) else rand_fits[i][j]

    for i in range(8):
        if(abs(p_max[i] - p_min[i]) <= 1.00000E-30):
            p_min[i]-=0.05 
            p_max[i]+=0.05

    # plot the data with the busy function fit overlaid
    BF_vals = []
    resid_vals = []
    for i in range(len(x_vals)):
        BF_vals.append(float( 0.25 * fit_params[0] * (1.0 + scipy.special.erf((fit_params[2] * (x_vals[i] - fit_params[4])))) * (1.0 + scipy.special.erf((fit_params[6] * (fit_params[8] - x_vals[i])))) * (1.0 + (fit_params[10] * (pow((abs((fit_params[12] - x_vals[i]))),fit_params[14])))) ))
        resid_vals.append(float(y_vals[i] - BF_vals[i]))
    plt.figure(1)
    plt.plot(x_vals,y_vals,'k',x_vals,BF_vals,'r',x_vals,resid_vals,'b')
    plt.xlabel('channel/frequency/km s$^{-1}$')
    plt.ylabel('intensity')
    plt.title('data with fit overplot')
    del(BF_vals)
    del(resid_vals)

    # plot parameter fits and correlated errors --- error ellipses overlaid on HD distributions
    plot_tmp_vals = []
    plot_tmp_x_vals = []
    for i in range(NOa):
        plot_tmp_vals.append(0.0)
        plot_tmp_x_vals.append(0.0)

    if(fit_params[0] > 0.0):
        mapped_fit[0] = math.log(fit_params[0])
    else:
        mapped_fit[0] = -1000.0
    if(math.isnan(mapped_fit[0])):
        mapped_fit[0] = 0.0
    if(math.isinf(mapped_fit[0])):
        mapped_fit[0] = 9E30 if (mapped_fit[0] > 0.0) else -9E30
    if(fit_params[2] > 0.0):
        mapped_fit[1] = math.log(fit_params[2])
    else: 
        mapped_fit[1] = -1000.0
    if(math.isnan(mapped_fit[1])):
        mapped_fit[1] = 0.0
    if(math.isinf(mapped_fit[1])):
        mapped_fit[1] = 9E30 if (mapped_fit[1] > 0.0) else -9E30
    mapped_fit[2] = math.asin((fit_params[4] - (0.5 * (x_min + x_max)))/(0.5 * (x_max - x_min)))
    if(math.isnan(mapped_fit[2])): 
        mapped_fit[2] = 0.0
    if(math.isinf(mapped_fit[2])):
        mapped_fit[2] = 9E30 if (mapped_fit[2] > 0.0) else -9E30
    if(fit_params[6] > 0.0):
        mapped_fit[3] = math.log(fit_params[6])
    else: 
        mapped_fit[3] = -1000.0;
    if(math.isnan(mapped_fit[3])):
        mapped_fit[3] = 0.0
    if(math.isinf(mapped_fit[3])):
        mapped_fit[3] = 9E30 if (mapped_fit[3] > 0.0) else -9E30
    mapped_fit[4] = math.asin((fit_params[8] - (0.5 * (x_min + x_max)))/(0.5 * (x_max - x_min)))
    if(math.isnan(mapped_fit[4])):
        mapped_fit[4] = 0.0
    if(math.isinf(mapped_fit[4])):
        mapped_fit[4] = 9E30 if (mapped_fit[4] > 0.0) else -9E30
    #if(fit_params[10] > 0.0):
    #    mapped_fit[5] = math.log(fit_params[10])
    #else: 
    #    mapped_fit[5] = -1000.0;
    mapped_fit[5] = fit_params[10];
    if(math.isnan(mapped_fit[5])):
        mapped_fit[5] = 0.0
    if(math.isinf(mapped_fit[5])):
        mapped_fit[5] = 9E30 if (mapped_fit[5] > 0.0) else -9E30
    mapped_fit[6] = math.asin((fit_params[12] - (0.5 * (x_min + x_max)))/(0.5 * (x_max - x_min)))
    if(math.isnan(mapped_fit[6])):
        mapped_fit[6] = 0.0
    if(math.isinf(mapped_fit[6])):
        mapped_fit[6] = 9E30 if (mapped_fit[6] > 0.0) else -9E30
    mapped_fit[7] = math.asin((fit_params[14] - 4.5)/3.5);
    if(math.isnan(mapped_fit[7])):
        mapped_fit[7] = 0.0
    if(math.isinf(mapped_fit[7])):
        mapped_fit[7] = 9E30 if (mapped_fit[7] > 0.0) else -9E30

    # over-write covariance matrix according to fit type; erase information about redundant parameters using information from relevant parameters
    if(fit_type == 1):
        for i in range(8): 
            fit_covar[3][i] = fit_covar[1][i] 
            fit_covar[i][3] = fit_covar[i][1]
        for i in range(8):
            fit_covar[6][i] = 0.5 * (fit_covar[2][i] + fit_covar[4][i])
            fit_covar[i][6] = 0.5 * (fit_covar[i][2] + fit_covar[i][4])
    elif(fit_type == 2):
        for i in range(8):
            fit_covar[3][i] = fit_covar[1][i] 
            fit_covar[i][3] = fit_covar[i][1]
        for i in range(8):
            fit_covar[6][i] = 0.5 * (fit_covar[2][i] + fit_covar[4][i])
            fit_covar[i][6] = 0.5 * (fit_covar[i][2] + fit_covar[i][4])
    elif(fit_type == 3):
        for i in range(8):
            fit_covar[3][i] = fit_covar[1][i] 
            fit_covar[i][3] = fit_covar[i][1]
        for i in range(8):
            fit_covar[6][i] = 0.5 * (fit_covar[2][i] + fit_covar[4][i])
            fit_covar[i][6] = 0.5 * (fit_covar[i][2] + fit_covar[i][4])
    elif(fit_type == 4):
        for i in range(8):
            fit_covar[3][i] = fit_covar[1][i]
            fit_covar[i][3] = fit_covar[i][1]
        for i in range(8):
            fit_covar[6][i] = 0.5 * (fit_covar[2][i] + fit_covar[4][i])
            fit_covar[i][6] = 0.5 * (fit_covar[i][2] + fit_covar[i][4])
    elif(fit_type == 5):
        for i in range(8):
            fit_covar[3][i] = fit_covar[1][i] 
            fit_covar[i][3] = fit_covar[i][1]

    # adjust obs_stats[][2] (min) and obs_stats[][3] (max) if they're the same
    for j in range(7):
        if(obs_stats[j][2] == obs_stats[j][3]):
            obs_stats[j][2]*=0.995
            obs_stats[j][3]*=1.005
        if(obs_stats[j][2] == obs_stats[j][3]):
            obs_stats[j][2]-=0.005
            obs_stats[j][3]+=0.005
    
    # construct plots of BF fit parameter distributions
    plt.figure(2)
    for j in range(7):

        for k in range(j+1,8):

            # initialise 2D distribution peak
            y_max = -9E30
    
            # determine 2D distribution
            for v in range(100):
                for m in range(100):
                    hist2D_HD_vals[v][m] = 0.0
            SD_step = 0.01 * (p_max[j] - p_min[j]) * (p_max[k] - p_min[k])
            HD_step = 0.01 * SD_step

            for i in range(10000):

                m = int(math.floor(((rand_fits[i][j] - p_min[j])/(0.01 * (p_max[j] - p_min[j])))))
                v = int(math.floor(((rand_fits[i][k] - p_min[k])/(0.01 * (p_max[k] - p_min[k])))))

                if((m >= 0) and (m < 100) and (v >= 0) and (v < 100)):
                    hist2D_HD_vals[v][m]+=(1.0/(float(10000)))
                    y_max = y_max if (y_max > hist2D_HD_vals[v][m]) else hist2D_HD_vals[v][m]
        
            # convert 2D HD distribution into logarithmic counts
            for v in range(100):
                for m in range(100):
                    if(hist2D_HD_vals[v][m] > 0.0):
                        hist2D_HD_vals[v][m] = math.log(hist2D_HD_vals[v][m])/math.log(10.0)
                    else:
                        hist2D_HD_vals[v][m] = -1000.0
            y_max = math.log(y_max)/math.log(10.0)
            y_min = -5.0
            if(y_min >= y_max):
                y_min = y_max - 0.1

            # plot HD 2D distribution
            sub_plt = plt.axes([(0.1 + (0.125 * float(j))),(0.1 + (0.125 * float((k - 1)))),0.125,0.125])
            sub_plt.axis([(p_min[j] - 0.1 * (p_max[j] - p_min[j])),(p_max[j] + 0.1 * (p_max[j] - p_min[j])),(p_min[k] - 0.1 * (p_max[k] - p_min[k])),(p_max[k] + 0.1 * (p_max[k] - p_min[k]))])
            sub_plt.imshow(hist2D_HD_vals,interpolation='nearest',cmap='Greys',origin='lower',extent=[p_min[j],p_max[j],p_min[k],p_max[k]],vmin=y_min,vmax=y_max,aspect='auto')

            if(j == 0):
                if(k == 0):
                    plt.ylabel(r'\$alpha$')
                    sub_plt.tick_params(labelbottom=False)
                elif(k == 1):
                    plt.xlabel(r'$\alpha$')
                    plt.ylabel(r'$\beta_{1}$')
                elif(k == 2):
                    plt.ylabel(r'$\gamma_{1}$')
                    sub_plt.tick_params(labelbottom=False)
                elif(k == 3):
                    plt.ylabel(r'$\beta_{2}$')
                    sub_plt.tick_params(labelbottom=False)
                elif(k == 4):
                    plt.ylabel(r'$\gamma_{2}$')
                    sub_plt.tick_params(labelbottom=False)
                elif(k == 5):
                    plt.ylabel(r'$\phi$')
                    sub_plt.tick_params(labelbottom=False)
                elif(k == 6):
                    plt.ylabel(r'$\theta$')
                    sub_plt.tick_params(labelbottom=False)
                elif(k == 7):
                    plt.ylabel('n')
                    sub_plt.tick_params(labelbottom=False)
                    
            elif((j + 1) == k):
                sub_plt.tick_params(labelleft=False)
                if(j == 0):
                    plt.xlabel(r'$\alpha$')
                elif(j == 1):
                    plt.xlabel(r'$\beta_{1}$')
                elif(j == 2):
                    plt.xlabel(r'$\gamma_{1}$')
                elif(j == 3):
                    plt.xlabel(r'$\beta_{2}$')
                elif(j == 4):
                    plt.xlabel(r'$\gamma_{2}$')
                elif(j == 5):
                    plt.xlabel(r'$\phi$')
                elif(j == 6):
                    plt.xlabel(r'$\theta$')
                elif(j == 7):
                    plt.xlabel('n')
        
            else:
                sub_plt.tick_params(labelbottom=False)
                sub_plt.tick_params(labelleft=False)
    
            # plot median values
            sub_plt.plot(fit_params[(2 * j)],fit_params[(2 * k)],'+r')
    
            det_covar_proj = (fit_covar[j][j] * fit_covar[k][k]) - (fit_covar[j][k] * fit_covar[k][j])
            if(abs(det_covar_proj) >= 1.0000E-30):
            
                inv_covar_proj[0][0] = fit_covar[k][k] / det_covar_proj
                if(math.isnan(inv_covar_proj[0][0])):
                    inv_covar_proj[0][0] = 0.0
                if(math.isinf(inv_covar_proj[0][0])):
                    inv_covar_proj[0][0] = 9E30 if (inv_covar_proj[0][0] > 0.0) else -9E30
                inv_covar_proj[1][0] = -1.0 * fit_covar[j][k] / det_covar_proj;
                if(math.isnan(inv_covar_proj[1][0])):
                    inv_covar_proj[1][0] = 0.0
                if(math.isinf(inv_covar_proj[1][0])):
                    inv_covar_proj[1][0] = 9E30 if (inv_covar_proj[1][0] > 0.0) else -9E30
                inv_covar_proj[0][1] = -1.0 * fit_covar[k][j] / det_covar_proj
                if(math.isnan(inv_covar_proj[0][1])):
                    inv_covar_proj[0][1] = 0.0
                if(math.isinf(inv_covar_proj[0][1])):
                    inv_covar_proj[0][1] = 9E30 if (inv_covar_proj[0][1] > 0.0) else -9E30
                inv_covar_proj[1][1] = fit_covar[j][j] / det_covar_proj
                if(math.isnan(inv_covar_proj[1][1])):
                    inv_covar_proj[1][1] = 0.0
                if(math.isinf(inv_covar_proj[1][1])):
                    inv_covar_proj[1][1] = 9E30 if (inv_covar_proj[1][1] > 0.0) else -9E30
            
                # plot 1-sigma error ellipses
                for i in range(NOa - 1):
        
                    plot_angle = 6.283185307 * (float(i)) / (float((NOa - 1)))
                    plot_radius = float(((inv_covar_proj[1][1] * math.sin(plot_angle) * math.sin(plot_angle)) + (inv_covar_proj[0][0] * math.cos(plot_angle) * math.cos(plot_angle)) + ((inv_covar_proj[0][1] + inv_covar_proj[1][0]) * math.cos(plot_angle) * math.sin(plot_angle))))
                    if(plot_radius > 0.0):
                        plot_radius = math.sqrt((2.3 / plot_radius))
                    else:
                        plot_radius = 0.0
        
                    plot_tmp_x_vals[i] = mapped_fit[j] + (plot_radius * math.cos(plot_angle))
                    plot_tmp_vals[i] = mapped_fit[k] + (plot_radius * math.sin(plot_angle))
                    if(j == 0):
                        plot_tmp_x_vals[i] = math.exp(plot_tmp_x_vals[i])
                    elif(j == 1):
                        plot_tmp_x_vals[i] = math.exp(plot_tmp_x_vals[i])
                    elif(j == 2):
                        plot_tmp_x_vals[i] = (0.5 * (x_min + x_max)) + ((0.5 * (x_max - x_min)) * math.sin(plot_tmp_x_vals[i]))
                    elif(j == 3):
                        plot_tmp_x_vals[i] = math.exp(plot_tmp_x_vals[i])
                    elif(j == 4):
                        plot_tmp_x_vals[i] = (0.5 * (x_min + x_max)) + ((0.5 * (x_max - x_min)) * math.sin(plot_tmp_x_vals[i]))
                    elif(j == 5):
                        plot_tmp_x_vals[i] = math.exp(plot_tmp_x_vals[i])
                    elif(j == 6):
                        plot_tmp_x_vals[i] = (0.5 * (x_min + x_max)) + ((0.5 * (x_max - x_min)) * math.sin(plot_tmp_x_vals[i]))
                    elif(j == 7):
                        plot_tmp_x_vals[i] = 4.5 + (3.5 * math.sin(plot_tmp_x_vals[i]))
                    if(k == 0):
                        plot_tmp_vals[i] = math.exp(plot_tmp_vals[i])
                    elif(k == 1):
                        plot_tmp_vals[i] = math.exp(plot_tmp_vals[i])
                    elif(k == 2):
                        plot_tmp_vals[i] = (0.5 * (x_min + x_max)) + ((0.5 * (x_max - x_min)) * math.sin(plot_tmp_vals[i]))
                    elif(k == 3):
                        plot_tmp_vals[i] = math.exp(plot_tmp_vals[i])
                    elif(k == 4):
                        plot_tmp_vals[i] = (0.5 * (x_min + x_max)) + ((0.5 * (x_max - x_min)) * math.sin(plot_tmp_vals[i]))
                    elif(k == 5):
                        plot_tmp_vals[i] = math.exp(plot_tmp_vals[i])
                    elif(k == 6):
                        plot_tmp_vals[i] = (0.5 * (x_min + x_max)) + ((0.5 * (x_max - x_min)) * math.sin(plot_tmp_vals[i]))
                    elif(k == 7):
                        plot_tmp_vals[i] = 4.5 + (3.5 * math.sin(plot_tmp_vals[i]))
                    if(math.isnan(plot_tmp_x_vals[i])):
                        plot_tmp_x_vals[i] = fit_params[(2 * j)]
                    if(math.isinf(plot_tmp_x_vals[i])):
                        plot_tmp_x_vals[i] = 9E30 if (plot_tmp_x_vals[i] > 0.0) else -9E30
                    if(math.isnan(plot_tmp_vals[i])):
                        plot_tmp_vals[i] = fit_params[(2 * k)]
                    if(math.isinf(plot_tmp_vals[i])):
                        plot_tmp_vals[i] = 9E30 if (plot_tmp_vals[i] > 0.0) else -9E30
      
                plot_tmp_x_vals[(NOa - 1)] = plot_tmp_x_vals[0]
                plot_tmp_vals[(NOa - 1)] = plot_tmp_vals[0]
                sub_plt.plot(plot_tmp_x_vals,plot_tmp_vals,'r')
      
                # plot 3-sigma error ellipses
                for i in range(NOa - 1):
              
                    plot_angle = 6.283185307 * (float(i)) / (float((NOa - 1)))
                    plot_radius = float(((inv_covar_proj[1][1] * math.sin(plot_angle) * math.sin(plot_angle)) + (inv_covar_proj[0][0] * math.cos(plot_angle) * math.cos(plot_angle)) + ((inv_covar_proj[0][1] + inv_covar_proj[1][0]) * math.cos(plot_angle) * math.sin(plot_angle))))
                    if(plot_radius > 0.0):
                        plot_radius = math.sqrt((11.8 / plot_radius))
                    else:
                        plot_radius = 0.0
                    plot_tmp_x_vals[i] = mapped_fit[j] + (plot_radius * math.cos(plot_angle))
                    plot_tmp_vals[i] = mapped_fit[k] + (plot_radius * math.sin(plot_angle))
                    if(j == 0):
                        plot_tmp_x_vals[i] = math.exp(plot_tmp_x_vals[i])
                    elif(j == 1):
                        plot_tmp_x_vals[i] = math.exp(plot_tmp_x_vals[i])
                    elif(j == 2):
                        plot_tmp_x_vals[i] = (0.5 * (x_min + x_max)) + ((0.5 * (x_max - x_min)) * math.sin(plot_tmp_x_vals[i]))
                    elif(j == 3):
                        plot_tmp_x_vals[i] = math.exp(plot_tmp_x_vals[i])
                    elif(j == 4):
                        plot_tmp_x_vals[i] = (0.5 * (x_min + x_max)) + ((0.5 * (x_max - x_min)) * math.sin(plot_tmp_x_vals[i]))
                    elif(j == 5):
                        plot_tmp_x_vals[i] = math.exp(plot_tmp_x_vals[i])
                    elif(j == 6):
                        plot_tmp_x_vals[i] = (0.5 * (x_min + x_max)) + ((0.5 * (x_max - x_min)) * math.sin(plot_tmp_x_vals[i]))
                    elif(j == 7):
                        plot_tmp_x_vals[i] = 4.5 + (3.5 * math.sin(plot_tmp_x_vals[i]))
                    if(k == 0):
                        plot_tmp_vals[i] = math.exp(plot_tmp_vals[i])
                    elif(k == 1):
                        plot_tmp_vals[i] = math.exp(plot_tmp_vals[i])
                    elif(k == 2):
                        plot_tmp_vals[i] = (0.5 * (x_min + x_max)) + ((0.5 * (x_max - x_min)) * math.sin(plot_tmp_vals[i]))
                    elif(k == 3):
                        plot_tmp_vals[i] = math.exp(plot_tmp_vals[i])
                    elif(k == 4):
                        plot_tmp_vals[i] = (0.5 * (x_min + x_max)) + ((0.5 * (x_max - x_min)) * math.sin(plot_tmp_vals[i]))
                    elif(k == 5):
                        plot_tmp_vals[i] = math.exp(plot_tmp_vals[i])
                    elif(k == 6):
                        plot_tmp_vals[i] = (0.5 * (x_min + x_max)) + ((0.5 * (x_max - x_min)) * math.sin(plot_tmp_vals[i]))
                    elif(k == 7):
                        plot_tmp_vals[i] = 4.5 + (3.5 * math.sin(plot_tmp_vals[i]))
                    if(math.isnan(plot_tmp_x_vals[i])):
                        plot_tmp_x_vals[i] = fit_params[(2 * j)]
                    if(math.isinf(plot_tmp_x_vals[i])):
                        plot_tmp_x_vals[i] = 9E30 if (plot_tmp_x_vals[i] > 0.0) else -9E30
                    if(math.isnan(plot_tmp_vals[i])):
                        plot_tmp_vals[i] = fit_params[(2 * k)]
                    if(math.isinf(plot_tmp_vals[i])):
                        plot_tmp_vals[i] = 9E30 if (plot_tmp_vals[i] > 0.0) else -9E30
        
                plot_tmp_x_vals[(NOa - 1)] = plot_tmp_x_vals[0]
                plot_tmp_vals[(NOa - 1)] = plot_tmp_vals[0]
                sub_plt.plot(plot_tmp_x_vals,plot_tmp_vals,'g')

            # if(fabs(det_covar_proj) >= 1.00000E-30)
            else:
                print("Ill-conditioned matrix. Not plotting contours for combination ",j,", ",k)
                if(math.fabs(det_covar_proj) < 1.00000E-30):
                    print("Determinant is too small!",det_covar_proj," < 1.00000E-30. Not plotting contours.")
    del(plot_tmp_vals)
            
    # plot histograms of observational parameters
    plot_tmp_vals = []
    for i in range(100):
        plot_tmp_vals.append(0.0)
    for j in range(7):

        # determine 1D distributions
        for i in range(10):
            hist_vals[i] = 0.0
        for i in range(100):
            hist_HD_vals[i] = 0.0
        SD_step = 0.1 * (obs_stats[j][3] - obs_stats[j][2])
        HD_step = 0.01 * (obs_stats[j][3] - obs_stats[j][2])
        y_max = -9E30

        for i in range(10000):

            k = int(math.floor(((obs_vals[i][j] - obs_stats[j][2])/SD_step)))
            if((k >= 0) and (k < 10)): 
                hist_vals[k]+=(1.0/(10.0 * 10000.0)) 
                y_max = y_max if (y_max > hist_vals[k]) else hist_vals[k]

            k = int(math.floor(((obs_vals[i][j] - obs_stats[j][2])/HD_step)))
            if((k >= 0) and (k < 100)): 
                hist_HD_vals[k]+=(1.0/10000.0); 
                y_max = y_max if (y_max > hist_HD_vals[k]) else hist_HD_vals[k]

            # plot 1D distributions
            if(y_max <= 0.0):
                y_max = 0.1;

        plt.figure(3 + j)
        for i in range(100):
            plot_tmp_vals[i] = obs_stats[j][2] + ((float(i) + 0.5) * HD_step)
        plt.plot(plot_tmp_vals,hist_HD_vals,'k')
        for i in range(10):
            plot_tmp_vals[i] = obs_stats[j][2] + ((float(i) + 0.5) * SD_step)
        plt.plot(plot_tmp_vals[:10],hist_vals,'r')

        if(j == 0):
            plt.xlabel("total flux")
            plt.ylabel("relative distribution")
        elif(j == 1):
            plt.xlabel("peak flux")
            plt.ylabel("relative distribution")
        elif(j == 2):
            plt.xlabel("peak flux position")
            plt.ylabel("relative distribution")
        elif(j == 3):
            plt.xlabel(r"W$_{50}$ width")
            plt.ylabel("relative distribution")
        elif(j == 4):
            plt.xlabel(r"W$_{50}$ position")
            plt.ylabel("relative distribution")
        elif(j == 5):
            plt.xlabel(r"W$_{20}$ width")
            plt.ylabel("relative distribution")
        elif(j == 6):
            plt.xlabel(r"W$_{20}$ position")
            plt.ylabel("relative distribution")
    
    del(plot_tmp_vals)

    # plot 2-D histograms of observational parameters
    plot_tmp_x_vals = []
    for i in range(NOa):
        plot_tmp_x_vals.append(0.0)
    plot_tmp_vals = []
    for i in range(NOa):
        plot_tmp_vals.append(0.0)
    plt.figure(10)

    for j in range(7):

      for k in range(j,7):
      
        # initialise 2D distribution peak
        y_max = -9E30
    
        # determine 2D distributions
        for v in range(10):
            for m in range(10):
                hist2D_vals[v][m] = 0.0
        for v in range(100):
            for m  in range(100):
                hist2D_HD_vals[v][m] = 0.0
        SD_step = 0.01 * (obs_stats[j][3] - obs_stats[j][2]) * (obs_stats[k][3] - obs_stats[k][2])
        HD_step = 0.01 * SD_step
        for i in range(10000):
	  
            m = int(math.floor(((obs_vals[i][j] - obs_stats[j][2])/(0.1 * (obs_stats[j][3] - obs_stats[j][2])))))
            v = int(math.floor(((obs_vals[i][k] - obs_stats[k][2])/(0.1 * (obs_stats[k][3] - obs_stats[k][2])))))
            if((m >= 0) and (m < 10) and (v >= 0) and (v < 10)):
                hist2D_vals[v][m]+=(0.01/10000)
                y_max = y_max if (y_max > hist2D_vals[v][m]) else hist2D_vals[v][m]
	    
            m = int(math.floor(((obs_vals[i][j] - obs_stats[j][2])/(0.01 * (obs_stats[j][3] - obs_stats[j][2])))))
            v = int(math.floor(((obs_vals[i][k] - obs_stats[k][2])/(0.01 * (obs_stats[k][3] - obs_stats[k][2])))))
            if((m >= 0) and (m < 100) and (v >= 0) and (v < 100)):
	    
                hist2D_HD_vals[m][v]+=(1.0/10000)
                y_max = y_max if (y_max > hist2D_HD_vals[m][v]) else hist2D_HD_vals[m][v]
	    	
	# convert 2D histrograms to logarithmic counts
        for v in range(10):
            for m in range(10):
                if(hist2D_vals[v][m] > 0.0):
                    hist2D_vals[v][m] = math.log(hist2D_vals[v][m])/math.log(10.0)
                else:
                    hist2D_vals[v][m] = -1000.0
        for m in range(100):
            for v in range(100):
                if(hist2D_HD_vals[m][v] > 0.0):
                    hist2D_HD_vals[m][v] = math.log(hist2D_HD_vals[m][v])/math.log(10.0)
                else:
                    hist2D_HD_vals[m][v] = -1000.0
        if(y_max > 0.0):
            y_max = math.log(y_max)/math.log(10.0)
        else:
            y_max = -1000.0
        y_min = -5.0
        if(y_min >= y_max):
            y_min = y_max - 0.1

	# plot SD 2D histogram
        if(j != k):

            sub_plt = plt.axes([(0.1 + (0.125 * float(j))),(0.1 + (0.125 * float(k))),0.125,0.125])
            sub_plt.axis([(obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2]))])
            sub_plt.imshow(hist2D_vals,interpolation='nearest',cmap='Greys',origin='lower',extent=[obs_stats[j][2],obs_stats[j][3],obs_stats[k][2],obs_stats[k][3]],vmin=y_min,vmax=y_max,aspect='auto')

            if(j == 0):
                if(k == 0):
                    plt.ylabel(r"T$_{flux}$")
                elif(k == 1):
                    plt.ylabel(r"P$_{flux}$")
                elif(k == 2):
                    plt.ylabel(r"P$_{f}$ pos.")
                elif(k == 3):
                    plt.ylabel(r"W$_{50}$ width")
                elif(k == 4):
                    plt.ylabel(r"W$_{50}$ position")
                elif(k == 5):
                    plt.ylabel(r"W$_{20}$ width")
                elif(k == 6):
                    plt.ylabel(r"W$_{20}$ position")
                if(k != 0):
                    sub_plt.tick_params(labelbottom=False)
            else:
                if(k == 0):
                    sub_plt.tick_params(labelleft=False)
                else: 
                    sub_plt.tick_params(labelleft=False,labelbottom=False)

            # plot median values
            sub_plt.plot(obs_stats[j][0],obs_stats[k][0],'+r')

	# plot HD 2D histogram
        sub_plt = plt.axes([(0.1 + (0.125 * float(k))),(0.1 + (0.125 * float(j))),0.125,0.125])
        sub_plt.axis([(obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2]))])
        sub_plt.imshow(hist2D_HD_vals,interpolation='nearest',cmap='Greys',origin='lower',extent=[obs_stats[k][2],obs_stats[k][3],obs_stats[j][2],obs_stats[j][3]],vmin=y_min,vmax=y_max,aspect='auto')

        if(j == 0):
            if(k == 0):
                plt.xlabel(r"T$_{flux}$")
                plt.ylabel(r"T$_{flux}$")
            else:
                sub_plt.tick_params(labelleft=False)
                if(k == 0):
                    plt.xlabel(r"T$_{flux}$")
                if(k == 1):
                    plt.xlabel(r"P$_{flux}$")
                if(k == 2):
                    plt.xlabel(r"P$_{f}$ pos.")
                if(k == 3):
                    plt.xlabel(r"W$_{50}$ width")
                if(k == 4):
                    plt.xlabel(r"W$_{50}$ position")
                if(k == 5):
                    plt.xlabel(r"W$_{20}$ width")
                if(k == 6):
                    plt.xlabel(r"W$_{20}$ position")
            
        else: 
            sub_plt.tick_params(labelleft=False,labelbottom=False)
	
	# plot median values
        sub_plt.plot(obs_stats[k][0],obs_stats[j][0],'+r')

	# plot error ellipses or error intervals for a single parameter
       	if(j != k):
            
            # calculate inverse of covariance matrix projection for this parameter combination	
            det_covar_proj = (approx_obs_covar[j][j] * approx_obs_covar[k][k]) - (approx_obs_covar[j][k] * approx_obs_covar[k][j])
            if((abs(det_covar_proj) >= 1.00000E-30) and (abs(approx_obs_covar[j][j]) >= 1.00000E-30) and (abs(approx_obs_covar[j][k]) >= 1.00000E-30) and (abs(approx_obs_covar[k][j]) >= 1.00000E-30) and (abs(approx_obs_covar[k][k]) >= 1.00000E-30)):
                
                inv_covar_proj[0][0] = approx_obs_covar[k][k] / det_covar_proj
                if(math.isnan(inv_covar_proj[0][0])):
                    inv_covar_proj[0][0] = 0.0
                if(math.isinf(inv_covar_proj[0][0])):
                    inv_covar_proj[0][0] = 9E30 if (inv_covar_proj[0][0] > 0.0) else -9E30
                inv_covar_proj[1][0] = -1.0 * approx_obs_covar[j][k] / det_covar_proj
                if(math.isnan(inv_covar_proj[1][0])):
                    inv_covar_proj[1][0] = 0.0
                if(math.isinf(inv_covar_proj[1][0])):
                    inv_covar_proj[1][0] = 9E30 if (inv_covar_proj[1][0] > 0.0) else -9E30
                inv_covar_proj[0][1] = -1.0 * approx_obs_covar[k][j] / det_covar_proj
                if(math.isnan(inv_covar_proj[0][1])):
                    inv_covar_proj[0][1] = 0.0
                if(math.isinf(inv_covar_proj[0][1])):
                    inv_covar_proj[0][1] = 9E30 if (inv_covar_proj[0][1] > 0.0) else -9E30
                inv_covar_proj[1][1] = approx_obs_covar[j][j] / det_covar_proj
                if(math.isnan(inv_covar_proj[1][1])):
                    inv_covar_proj[1][1] = 0.0
                if(math.isinf(inv_covar_proj[1][1])):
                    inv_covar_proj[1][1] = 9E30 if (inv_covar_proj[1][1] > 0.0) else -9E30
	    
                # plot 1-sigma error ellipses
                for i in range(NOa - 1):
	      
                    plot_angle = 6.283185307 * (float(i)) / (float((NOa - 1)))
                    plot_radius = float(((inv_covar_proj[1][1] * math.sin(plot_angle) * math.sin(plot_angle)) + (inv_covar_proj[0][0] * math.cos(plot_angle) * math.cos(plot_angle)) + ((inv_covar_proj[0][1] + inv_covar_proj[1][0]) * math.cos(plot_angle) * math.sin(plot_angle))))
                    if(plot_radius > 0.0):
                        plot_radius = math.sqrt((2.3 / plot_radius))
                    else:
                        plot_radius = 0.0
	      
                    plot_tmp_x_vals[i] = obs_stats[j][0] + (plot_radius * math.cos(plot_angle))
                    plot_tmp_vals[i] = obs_stats[k][0] + (plot_radius * math.sin(plot_angle))
                    if(math.isnan(plot_tmp_x_vals[i])):
                        plot_tmp_x_vals[i] = fit_params[(2 * j)]
                    if(math.isinf(plot_tmp_x_vals[i])):
                        plot_tmp_x_vals[i] = 9E30 if (plot_tmp_x_vals[i] > 0.0) else -9E30
                    if(math.isnan(plot_tmp_vals[i])):
                        plot_tmp_vals[i] = fit_params[(2 * k)]
                    if(math.isinf(plot_tmp_vals[i])):
                        plot_tmp_vals[i] = 9E30 if (plot_tmp_vals[i] > 0.0) else -9E30
	      
                plot_tmp_x_vals[(NOa - 1)] = plot_tmp_x_vals[0]
                plot_tmp_vals[(NOa - 1)] = plot_tmp_vals[0]
	    
                # re-set viewport to SD 2D distribution
                sub_plt = plt.axes([(0.1 + (0.125 * float(j))),(0.1 + (0.125 * float(k))),0.125,0.125])
                sub_plt.axis([(obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2]))])
                sub_plt.plot(plot_tmp_x_vals,plot_tmp_vals,'r')
                
                # re-set viewport to HD 2D distribution
                for i in range(NOa):
                    plot_angle = plot_tmp_x_vals[i]
                    plot_tmp_x_vals[i] = plot_tmp_vals[i]
                    plot_tmp_vals[i] = plot_angle
                sub_plt = plt.axes([(0.1 + (0.125 * float(k))),(0.1 + (0.125 * float(j))),0.125,0.125])
                sub_plt.axis([(obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2]))])
                sub_plt.plot(plot_tmp_x_vals,plot_tmp_vals,'r')

                # plot 3-sigma error ellipses
                for i in range(NOa - 1):
                        
                    plot_angle = 6.283185307 * (float(i)) / (float((NOa - 1)))
                    plot_radius = float(((inv_covar_proj[1][1] * math.sin(plot_angle) * math.sin(plot_angle)) + (inv_covar_proj[0][0] * math.cos(plot_angle) * math.cos(plot_angle)) + ((inv_covar_proj[0][1] + inv_covar_proj[1][0]) * math.cos(plot_angle) * math.sin(plot_angle))))
                    if(plot_radius > 0.0):
                        plot_radius = math.sqrt((11.8 / plot_radius))
                    else:
                        plot_radius = 0.0
                        
                    plot_tmp_x_vals[i] = obs_stats[j][0] + (plot_radius * math.cos(plot_angle))
                    plot_tmp_vals[i] = obs_stats[k][0] + (plot_radius * math.sin(plot_angle))
                    if(math.isnan(plot_tmp_x_vals[i])):
                        plot_tmp_x_vals[i] = fit_params[(2 * j)]
                    if(math.isinf(plot_tmp_x_vals[i])):
                        plot_tmp_x_vals[i] = 9E30 if (plot_tmp_x_vals[i] > 0.0) else -9E30
                    if(math.isnan(plot_tmp_vals[i])):
                        plot_tmp_vals[i] = fit_params[(2 * k)]
                    if(math.isinf(plot_tmp_vals[i])):
                        plot_tmp_vals[i] = 9E30 if (plot_tmp_vals[i] > 0.0) else -9E30
                        
                plot_tmp_x_vals[(NOa - 1)] = plot_tmp_x_vals[0]
                plot_tmp_vals[(NOa - 1)] = plot_tmp_vals[0]
                
                # re-set viewport to SD 2D distribution
                sub_plt = plt.axes([(0.1 + (0.125 * float(j))),(0.1 + (0.125 * float(k))),0.125,0.125])
                sub_plt.axis([(obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2]))])
                sub_plt.plot(plot_tmp_x_vals,plot_tmp_vals,'g')
                
                # re-set viewport to HD 3D distribution
                for i in range(NOa):
                    plot_angle = plot_tmp_x_vals[i]
                    plot_tmp_x_vals[i] = plot_tmp_vals[i]
                    plot_tmp_vals[i] = plot_angle
                sub_plt = plt.axes([(0.1 + (0.125 * float(k))),(0.1 + (0.125 * float(j))),0.125,0.125])
                sub_plt.axis([(obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2]))])
                sub_plt.plot(plot_tmp_x_vals,plot_tmp_vals,'g')
                

            else:
                print("Ill-conditioned matrix. Not plotting contours for combination ",j,", ",k)
                if(abs(det_covar_proj) < 1.00000E-30):
                    print("Determinant is too small! ",det_covar_proj," < 1.00000E-30. Not plotting contours.")
        else:

            # re-set viewport to SD 2D distribution
            sub_plt = plt.axes([(0.1 + (0.125 * float(j))),(0.1 + (0.125 * float(k))),0.125,0.125])
            sub_plt.axis([(obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2]))])
            sub_plt.plot([(obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2]))],[(-1.0 * (obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] + obs_stats[k][1] + obs_stats[j][0] + obs_stats[j][1]),(-1.0 * (obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] + obs_stats[k][1] + obs_stats[j][0] + obs_stats[j][1])],'r')
            sub_plt.plot([(obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2]))],[(-1.0 * (obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] - obs_stats[k][1] + obs_stats[j][0] - obs_stats[j][1]),(-1.0 * (obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] - obs_stats[k][1] + obs_stats[j][0] - obs_stats[j][1])],'r')
            sub_plt.plot([(obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2]))],[(-1.0 * (obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] + obs_stats[j][0] + (3.0 * obs_stats[k][1] + obs_stats[j][1])),(-1.0 * (obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] + obs_stats[j][0] + (3.0 * obs_stats[k][1] + obs_stats[j][1]))],'g')
            sub_plt.plot([(obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2]))],[(-1.0 * (obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] + obs_stats[j][0] - (3.0 * obs_stats[k][1] + obs_stats[j][1])),(-1.0 * (obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] + obs_stats[j][0] - (3.0 * obs_stats[k][1] + obs_stats[j][1]))],'g')
                         
            # re-set viewport to HD 3D distribution
            sub_plt = plt.axes([(0.1 + (0.125 * float(k))),(0.1 + (0.125 * float(j))),0.125,0.125])
            sub_plt.axis([(obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2]))])
            sub_plt.plot([(obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2]))],[(-1.0 * (obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] + obs_stats[j][1] + obs_stats[k][0] + obs_stats[k][1]),(-1.0 * (obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] + obs_stats[j][1] + obs_stats[k][0] + obs_stats[k][1])],'r')
            sub_plt.plot([(obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2]))],[(-1.0 * (obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] - obs_stats[j][1] + obs_stats[k][0] - obs_stats[k][1]),(-1.0 * (obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] - obs_stats[j][1] + obs_stats[k][0] - obs_stats[k][1])],'r')
            sub_plt.plot([(obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2]))],[(-1.0 * (obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] + obs_stats[k][0] + (3.0 * obs_stats[j][1] + obs_stats[k][1])),(-1.0 * (obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] + obs_stats[k][0] + (3.0 * obs_stats[j][1] + obs_stats[k][1]))],'g')
            sub_plt.plot([(obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2]))],[(-1.0 * (obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] + obs_stats[k][0] - (3.0 * obs_stats[j][1] + obs_stats[k][1])),(-1.0 * (obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] + obs_stats[k][0] - (3.0 * obs_stats[j][1] + obs_stats[k][1]))],'g')
            
    del(plot_tmp_vals)
    del(plot_tmp_x_vals)

    # create plots after setting them up
    plt.show()

# call main() if this python script is called directly
if __name__ == '__main__':
    main();

