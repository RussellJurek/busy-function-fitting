/*

This is a demonstration program for  version 1.4 of the C++ BusyFunc library that fits the 
Busy Function to data. See Westmeier, Jurek, Obreschkow, Koribalski & Staveley-Smith (2013) for more details 
about the implementation of this library and the Busy Function.

Created by Russell J. Jurek, 23rd September 2014.
Email: Russell.Jurek@gmail.com

 */

#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<BFfit.h>
#include<iomanip>
extern "C" {
  
#include<cpgplot.h>

}

int main(int argc, char* argv[]){

  std::fstream infile;
  std::string dummy1, infile_name,output_plot_name;
  std::stringstream dummy2;
  int i,j,k,m,length,v,NOvals,fit_type,vb_flag = -1, cols[3] = {0,1,-99}, NOr = 10000, NOs = 1000, iter_max = 30, refine_iter = 3000;
  // use float data
  float * x_vals, * y_vals, * n_vals, * fit_params, ** fit_covar, fit_x_min, fit_x_max, ** rand_fits, ** rand_obs_vals, ** obs_stats, ** obs_covar;
  // use double data
  //double * x_vals, * y_vals, * n_vals, * fit_params, ** fit_covar, fit_x_min, fit_x_max, ** rand_fits, ** rand_obs_vals, ** obs_stats, ** obs_covar;

  // plotting variables
  int NOa = 1501;
  float * hist_vals, * hist_HD_vals, * hist2D_vals, * hist2D_HD_vals, * plot_tmp_vals, * plot_tmp_x_vals,plot_angle,plot_radius;
  float SD_step,y_min,y_max,HD_step,tr[6],p_min[8] = {9E30,9E30,9E30,9E30,9E30,9E30,9E30,9E30},p_max[8] = {-9E30,-9E30,-9E30,-9E30,-9E30,-9E30,-9E30,-9E30};
  float mapped_fit[8],det_covar_proj,inv_covar_proj[2][2];

  // test if insufficient arguments were specified on the command line
  if((argc == 1) || (argc >= 12)){ std::cout << "Incorrect number of arguments. Use `FitSpectrum -h' to view instructions." << std::endl; return 0; }

  // get input file from the command line
  dummy2.str("");
  dummy2.clear();
  dummy2 << argv[1];
  dummy1 = "";
  dummy2 >> infile_name;

  // display instructions if the first entry on the command line was -h or -H
  if((infile_name == "-h") || (infile_name == "-H")){ std::cout << "Instructions for FitSpectrum: \n\nThis program uses the C++ Busy Function fitting library to fit the Busy Function to a single spectra. This program assumes that each line of the input file contains an x and y value, as well as an optional noise value for each (x,y). This program also assumes space delimited input files.\n\nUsage: FitSpectrum input_file [x_col] [y_col] [noise_col] [-v or -vv] [-s NOs iter_max] [-r refine_iter] \n       FitSpectrum -h\n\nThe input_file is the only mandatory input. All other inputs are optional, which is represented by []. The optional inputs are:\nx_col: The column containing the x values. Count from 0. Default is 0.\ny_col: The column containing the y values. Count from 0. Default is 1.\nnoise_col: The column containing the noise values. Default is -99, which assigns a value of 1 for every x.\n-v: Turn verbosity to medium (default is none).\n-vv: Turn verbosity to high (default is none).\n-s NOs iter_max: These 3 values specify a non-default number of LVM seeds and LVM iterations per seed (defaults are 1000 and 30).\n-r refine_iter: These 2 values specify the number of iterations to use to refine the best fit by re-fitting (default is 3000).\n\nThe fitting results are written to the terminal. The first value is the dimensionality of the best fitting BF model. The next 16 values are the BF fit parameters and their uncertainties (listed in value, error pairs). The next value is chi^2. The remaining 64 values are the chi^2 covariance matrix.\nThe values are written out in scientific notation to accommodate especially large or small values.\n" << std::endl; return 0; }

  // process command line arguments
  j = 0;
  for(i = 2; ((i < argc) && (i < 11)); i++){

    dummy2.str("");
    dummy2.clear();
    dummy2 << argv[i];
    dummy1 = "";
    dummy2 >> dummy1;
    
    // process a verbose flag
    if((dummy1 == "-v") || (dummy1 == "-V")){ 
      vb_flag = 0; 
      continue;
    } 
    if((dummy1 == "-vv") || (dummy1 == "-VV") || (dummy1 == "-Vv") || (dummy1 == "-vV")){ 
      vb_flag = 1; 
      continue;
    }

    // process a LVM seed number and iteration maximum specification
    if((dummy1 == "-s") || (dummy1 == "-S")){
      dummy2.str("");
      dummy2.clear();
      dummy2 << argv[(i + 1)];
      dummy2 >> NOs;
      dummy2.str("");
      dummy2.clear();
      dummy2 << argv[(i + 2)];
      dummy2 >> iter_max;
      i+=2;
      continue;
    }

    // process a refinement iteration specification
    if((dummy1 == "-r") || (dummy1 == "-R")){
      dummy2.str("");
      dummy2.clear();
      dummy2 << argv[(i + 1)];
      dummy2 >> refine_iter;
      i++;
      continue;
    }

    // process a column number
    dummy2.str("");
    dummy2.clear();
    dummy2 << dummy1;
    dummy2 >> cols[j];
    j++;

  }
  if(refine_iter < iter_max){ refine_iter = iter_max; }

  // display columns to be used
  if(vb_flag >= 0){ std::cout << "Using x_col = " << cols[0] << ", y_col = " << cols[1] << " & noise_col = " << cols[2] << std::endl; }

  // display seeds and iterations
  if(vb_flag >= 0){ std::cout << "Using " << NOs << " LVM seeds, with a maximum of " << iter_max << " iterations per seed. Refining fit with " << refine_iter << " iterations." << std::endl; }

  // open input file
  if(vb_flag >= 0){ std::cout << "Opening input file: " << infile_name << std::endl; }
  infile.open(infile_name.c_str(),std::ios::in);

  // check that the input file is open
  if(infile.is_open()){

    // create arrays used by BusyFunc fitting routines
    // use float data
    fit_params = new float[17];
    fit_covar =  new float * [8];
    rand_fits = new float * [NOr];
    for(i = 0; i < 8; i++){ 
      fit_covar[i] = new float[8]; 
    }
    rand_obs_vals = new float * [NOr];
    for(i = 0; i < NOr; i++){ 
      rand_obs_vals[i] = new float[7]; 
      rand_fits[i] = new float[8];
    }
    obs_stats = new float * [7];
    for(i = 0; i < 7; i++){ obs_stats[i] = new float[8]; }
    obs_covar = new float * [7];
    for(i = 0; i < 7; i++){ obs_covar[i] = new float[7]; }
    // use double data
    /*fit_params = new double[17];
    fit_covar =  new double * [8];
    rand_fits = new double * [NOr];
    for(i = 0; i < 8; i++){ 
      fit_covar[i] = new double[8]; 
    }
    rand_obs_vals = new double * [NOr];
    for(i = 0; i < NOr; i++){ 
      rand_obs_vals[i] = new double[7]; 
      rand_fits[i] = new double[8];
    }
    obs_stats = new double * [7];
    for(i = 0; i < 7; i++){ obs_stats[i] = new double[8]; }
    obs_covar = new double * [7];
    for(i = 0; i < 7; i++){ obs_covar[i] = new double[7]; }*/

    // count the number of entries in the input file
    NOvals = 0;
    while(!(infile.eof())){
      
      dummy1 = "";
      getline(infile,dummy1);
      if ((dummy1 != "") && (dummy1.find("#",0) == std::string::npos)){ NOvals++;  }
      
    }
    infile.clear();
    infile.seekg(0,std::ios::beg);
    if(vb_flag >= 0){ std::cout << NOvals << " entries in the source+noise catalogue." << std::endl; }
    
    // allocate memory to store input file
    // use float data
    x_vals = new float[NOvals];
    y_vals = new float[NOvals];
    n_vals = new float[NOvals];
    // use double data
    /*x_vals = new double[NOvals];
    y_vals = new double[NOvals];
    n_vals = new double[NOvals];*/
    
    // read input file into memory
    if(vb_flag >= 0){ std::cout << "Reading source+noise objects into arrays . . . " << std::endl; }
    v = 0;
    while((!(infile.eof())) && (v < NOvals)){
      dummy1 = "";
      getline(infile,dummy1);
      if ((dummy1.find("#",0) != std::string::npos) || (dummy1 == "")){ continue; }
      m = 0;
      i = 0;
      while(i > -1){
	j = dummy1.find_first_not_of(" ",m);
	if (j == (int) std::string::npos) { i = -99; continue; }
	k = dummy1.find_first_of(" ",j+1);
	if (k == (int) std::string::npos) { k = dummy1.length(); }
	m = k + 1;
	length = k - j;
	dummy2.str("");
	dummy2.clear();
	dummy2.str(dummy1.substr(j,length));
	if(i == cols[0]){ dummy2 >> x_vals[v]; }
	if(i == cols[1]){ dummy2 >> y_vals[v]; }
	if(i == cols[2]){ dummy2 >> n_vals[v]; }
	
	// increment column index
	i++;
	
	// close while loop that loads data into variables
      }      
      
      // specify constant noise = 1.0 if cols[2] < 0
      if(cols[2] < 0){ n_vals[v] = 1.0; }
      
      // increment array index
      v++;
      
      // close while loop loading infile into arrays
    }
    if(vb_flag >= 0){ std::cout << "done." << std::endl; }
    
    // close input file
    infile.close();
    
    // specify initial roll-off range
    fit_x_min = fit_params[4] = x_vals[0] + (0.05 * (x_vals[(NOvals - 1)] - x_vals[0]));
    fit_x_max = fit_params[8] = x_vals[0] + (0.95 * (x_vals[(NOvals - 1)] - x_vals[0]));
    
    // call busy function fitting routine
    fit_type = FitBusyFunc(NOvals,x_vals,y_vals,n_vals,fit_params,fit_covar,k,NOs,iter_max,vb_flag);   

    // refine BF fit - call busy function fitting routine with NOs = -1
    fit_type = FitBusyFunc(NOvals,x_vals,y_vals,n_vals,fit_params,fit_covar,k,-1,refine_iter,vb_flag);

    // display BF fitting result
    std::cout << "BF fit . . . " << std::endl;
    std::cout << k << std::scientific << " ";
    for(i = 0; i < 17; i++){ std::cout << fit_params[i] << " "; }
    for(i = 0; i < 8; i++){
      for(j = 0; j < 8; j++){
	std::cout << fit_covar[i][j] << " ";
      }
    }
    std::cout << std::fixed << std::endl;

    // call functions that generate N random BF fit variants, calculates observational parameters for them
    // and measures basic statistical properties 
    CreateRandFits(NOr,rand_fits,fit_type,fit_params,fit_covar,fit_x_min,fit_x_max,vb_flag);
    CalcObsParams(NOr,rand_fits,NOvals,x_vals,rand_obs_vals,vb_flag);
    AnalyseObsVals(NOr,7,rand_obs_vals,obs_stats,vb_flag);

    // display statistical properties of observational parameters
    std::cout << "statistical properties of observational parameters . . . " << std::endl;
    for(j = 0; j < 7; j++){
      switch (j) {
      case 0:
	std::cout << "Total intensity --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis " << std::endl;
	break;
      case 1:
	std::cout << "Peak intensity --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis " << std::endl;
	break;	
      case 2:
	std::cout << "Peak intensity position --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis  " << std::endl;
	break;
      case 3:
	std::cout << "W_50 width --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis  " << std::endl;
	break;
      case 4:
	std::cout << "W_50 position --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis  " << std::endl;
	break;
      case 5:
	std::cout << "W_20 width --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis  " << std::endl;
	break;
      case 6:
	std::cout << "W_20 position --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis  " << std::endl;
	break;
      default:
	break;
      }
      for(i = 0; i < 8; i++){
	std::cout << obs_stats[j][i] << " " << std::flush;
      }
      std::cout << std::endl;
    }

    // calculate and display observational parameter covariance
    ApproxObsCovar(fit_type,NOvals,x_vals,fit_params,fit_covar,obs_covar,fit_x_min,fit_x_max);
    std::cout << "Observational parameter covariance matrix . . . " << std::endl;
    for(j = 0; j < 7; j++){
      for(i = 0; i < 7; i++){
	std::cout << obs_covar[j][i] << " ";
      }
      std::cout << std::endl;
    }
    std::cout << "Resultant errors . . . " << std::endl;
    for(i = 0; i < 7; i++){ std::cout << sqrtf(obs_covar[i][i]) << " "; }
    std::cout << std::endl;

    // allocate memory used for plotting
    hist_vals = new float[10];
    hist_HD_vals = new float[100];
    hist2D_vals = new float[100];
    hist2D_HD_vals = new float[10000];

    // open output plot
    i = infile_name.find(".",0);
    output_plot_name = infile_name.substr(0,i) + "_BFplots.ps";
    std::cout << "Creating output plots in " << output_plot_name << " . . . " << std::endl;
    output_plot_name = output_plot_name + "/cps";
    cpgopen(output_plot_name.c_str());

    // determine range of BF fit random variants
    for(i = 0; i < NOr; i++){
      
      for(j = 0; j < 8; j++){

	p_max[j] = (p_max[j] > rand_fits[i][j]) ? p_max[j] : rand_fits[i][j];
	p_min[j] = (p_min[j] < rand_fits[i][j]) ? p_min[j] : rand_fits[i][j];

      }

    }
    for(i = 0; i < 8; i++){ 
      if(fabs(p_max[i] - p_min[i]) <= 1.00000E-30){ 
	p_min[i]-=0.05; 
	p_max[i]+=0.05;
      }
    }

    // plot data and best fit
    if(vb_flag >= 0){ std::cout << "Plotting data, BF fit and residuals . . . " << std::endl; }
    plot_tmp_vals = new float[NOvals];
    y_min = 9E30;
    y_max = -9E30;
    for(i = 0; i < NOvals; i++){ 

      plot_tmp_vals[i] = 0.25 * fit_params[0] * (1.0 + erff((fit_params[2] * (x_vals[i] - fit_params[4])))) * (1.0 + erff((fit_params[6] * (fit_params[8] - x_vals[i])))) * (1.0 + (fit_params[10] * (powf((fabs((fit_params[12] - x_vals[i]))),fit_params[14]))));
      if(isnan(plot_tmp_vals[i])){ plot_tmp_vals[i] = 0.0; }
      if(isinf(plot_tmp_vals[i])){ plot_tmp_vals[i] = (plot_tmp_vals[i] > 0.0) ? 9E30 : -9E30; }
      y_min = (y_min < plot_tmp_vals[i]) ? y_min : plot_tmp_vals[i];
      y_min = (y_min < y_vals[i]) ? y_min : y_vals[i];
      y_max = (y_max > plot_tmp_vals[i]) ? y_max : plot_tmp_vals[i];
      y_max = (y_max > y_vals[i]) ? y_max : y_vals[i];

    }
    if(vb_flag >= 0){ std::cout << std::endl; }
    if(y_min == y_max){ y_min-=0.1; y_max+=0.1; }
    cpgenv(x_vals[0],x_vals[(NOvals - 1)],(y_min - 0.05 * (y_max - y_min)),(y_max + 0.05 * (y_max - y_min)),0,0);
    cpgline(NOvals,x_vals,y_vals);
    cpgsci(2);
    cpgline(NOvals,x_vals,plot_tmp_vals);
    cpgsci(1);
    for(i = 0; i < NOvals; i++){ plot_tmp_vals[i] = y_vals[i] - plot_tmp_vals[i]; }
    cpgsci(4);
    cpgline(NOvals,x_vals,plot_tmp_vals);
    cpgsci(1);
    cpglab("channel/frequency/km s\\u-1\\d","intensity","data with fit overplotted");
    delete [] plot_tmp_vals;
    
    // plot parameter fits and correlated errors --- error ellipses overlaid on HD distributions
    if(vb_flag >= 0){ std::cout << "Plotting parameter error ellipses overlaid on distributions . . . " << std::endl; }
    plot_tmp_x_vals = new float[NOa];
    plot_tmp_vals = new float[NOa];
    if(fit_params[0] > 0.0){ mapped_fit[0] = log(fit_params[0]); } else { mapped_fit[0] = -1000.0; }
    if(isnan(mapped_fit[0])){ mapped_fit[0] = 0.0; }
    if(isinf(mapped_fit[0])){ mapped_fit[0] = (mapped_fit[0] > 0.0) ? 9E30 : -9E30; }
    if(fit_params[2] > 0.0){ mapped_fit[1] = log(fit_params[2]); } else { mapped_fit[1] = -1000.0; }
    if(isnan(mapped_fit[1])){ mapped_fit[1] = 0.0; }
    if(isinf(mapped_fit[1])){ mapped_fit[1] = (mapped_fit[1] > 0.0) ? 9E30 : -9E30; }
    mapped_fit[2] = asin((fit_params[4] - (0.5 * (fit_x_min + fit_x_max)))/(0.5 * (fit_x_max - fit_x_min)));
    if(isnan(mapped_fit[2])){ mapped_fit[2] = 0.0; }
    if(isinf(mapped_fit[2])){ mapped_fit[2] = (mapped_fit[2] > 0.0) ? 9E30 : -9E30; }
    if(fit_params[6] > 0.0){ mapped_fit[3] = log(fit_params[6]); } else { mapped_fit[3] = -1000.0; }
    if(isnan(mapped_fit[3])){ mapped_fit[3] = 0.0; }
    if(isinf(mapped_fit[3])){ mapped_fit[3] = (mapped_fit[3] > 0.0) ? 9E30 : -9E30; }
    mapped_fit[4] = asin((fit_params[8] - (0.5 * (fit_x_min + fit_x_max)))/(0.5 * (fit_x_max - fit_x_min)));
    if(isnan(mapped_fit[4])){ mapped_fit[4] = 0.0; }
    if(isinf(mapped_fit[4])){ mapped_fit[4] = (mapped_fit[4] > 0.0) ? 9E30 : -9E30; }
    //if(fit_params[10] > 0.0){ mapped_fit[5] = log(fit_params[10]); } else { mapped_fit[5] = -1000.0; }
    mapped_fit[5] = fit_params[10];
    if(isnan(mapped_fit[5])){ mapped_fit[5] = 0.0; }
    if(isinf(mapped_fit[5])){ mapped_fit[5] = (mapped_fit[5] > 0.0) ? 9E30 : -9E30; }
    mapped_fit[6] = asin((fit_params[12] - (0.5 * (fit_x_min + fit_x_max)))/(0.5 * (fit_x_max - fit_x_min)));
    if(isnan(mapped_fit[6])){ mapped_fit[6] = 0.0; }
    if(isinf(mapped_fit[6])){ mapped_fit[6] = (mapped_fit[6] > 0.0) ? 9E30 : -9E30; }
    mapped_fit[7] = asin((fit_params[14] - 4.5)/3.5);
    if(isnan(mapped_fit[7])){ mapped_fit[7] = 0.0; }
    if(isinf(mapped_fit[7])){ mapped_fit[7] = (mapped_fit[7] > 0.0) ? 9E30 : -9E30; }

    // over-write covariance matrix according to fit type; erase information about redundant parameters using information from relevant parameters
    switch(fit_type){
    case 1:
      for(i = 0; i < 8; i++){ 
	fit_covar[3][i] = fit_covar[1][i]; 
	fit_covar[i][3] = fit_covar[i][1];
      }
      for(i = 0; i < 8; i++){
	fit_covar[6][i] = 0.5 * (fit_covar[2][i] + fit_covar[4][i]);
	fit_covar[i][6] = 0.5 * (fit_covar[i][2] + fit_covar[i][4]);
      }
      break;
    case 2:
      for(i = 0; i < 8; i++){ 
	fit_covar[3][i] = fit_covar[1][i]; 
	fit_covar[i][3] = fit_covar[i][1];
      }
      for(i = 0; i < 8; i++){
	fit_covar[6][i] = 0.5 * (fit_covar[2][i] + fit_covar[4][i]);
	fit_covar[i][6] = 0.5 * (fit_covar[i][2] + fit_covar[i][4]);
      }
      break;
    case 3:
      for(i = 0; i < 8; i++){ 
	fit_covar[3][i] = fit_covar[1][i]; 
	fit_covar[i][3] = fit_covar[i][1];
      }
      for(i = 0; i < 8; i++){
	fit_covar[6][i] = 0.5 * (fit_covar[2][i] + fit_covar[4][i]);
	fit_covar[i][6] = 0.5 * (fit_covar[i][2] + fit_covar[i][4]);
      }
      break;
    case 4:
      for(i = 0; i < 8; i++){ 
	fit_covar[3][i] = fit_covar[1][i]; 
	fit_covar[i][3] = fit_covar[i][1];
      }
      for(i = 0; i < 8; i++){
	fit_covar[6][i] = 0.5 * (fit_covar[2][i] + fit_covar[4][i]);
	fit_covar[i][6] = 0.5 * (fit_covar[i][2] + fit_covar[i][4]);
      }
      break;
    case 5:
      for(i = 0; i < 8; i++){ 
	fit_covar[3][i] = fit_covar[1][i]; 
	fit_covar[i][3] = fit_covar[i][1];
      }
      break;
    default:
      break;
    }

    // adjust obs_stats[][2] (min) and obs_stats[][3] (max) if they're the same
    for(j = 0; j < 7; j++){
      if(obs_stats[j][2] == obs_stats[j][3]){ obs_stats[j][2]*=0.995; obs_stats[j][3]*=1.005; }
    }
    
    // construct plots of BF fit parameter distributions
    cpgpage();
    for(j = 0; j < 7; j++){

      for(k = j + 1; k < 8; k++){

	// initialise 2D distribution peak
	y_max = -9E30;
	
	// determine 2D distribution
	for(i = 0; i < 10000; i++){ hist2D_HD_vals[i] = 0.0; }
	SD_step = 0.01 * (p_max[j] - p_min[j]) * (p_max[k] - p_min[k]);
	HD_step = 0.01 * SD_step;

	for(i = 0; i < NOr; i++){

	  m = (int) floorf(((rand_fits[i][j] - p_min[j])/(0.01 * (p_max[j] - p_min[j]))));
	  v = (int) floorf(((rand_fits[i][k] - p_min[k])/(0.01 * (p_max[k] - p_min[k]))));
	  if((m >= 0) && (m < 100) && (v >= 0) && (v < 100)){

	    hist2D_HD_vals[(m + (100 * v))]+=(1.0/((float) NOr));
	    y_max = (y_max > hist2D_HD_vals[(m + (100 * v))]) ? y_max : hist2D_HD_vals[(m + (100 * v))];
	    
	  }

	  // for(i = 0; i < NOr; i++)
	}
	
	// convert 2D HD distribution into logarithmic counts
	for(i = 0; i < 10000; i++){
	  if(hist2D_HD_vals[i] > 0.0){ hist2D_HD_vals[i] = log(hist2D_HD_vals[i])/log(10.0); } else { hist2D_HD_vals[i] = -1000.0; }
	}
	y_max = log(y_max)/log(10.0);

	// plot HD 2D distribution
	cpgsvp((0.1 + (0.125 * (float) j)),(0.1 + (0.125 * (float) (j + 1))),(0.1 + (0.125 * (float) (k - 1))),(0.1 + (0.125 * (float) k)));
	cpgswin((p_min[j] - 0.1 * (p_max[j] - p_min[j])),(p_max[j] + 0.1 * (p_max[j] - p_min[j])),(p_min[k] - 0.1 * (p_max[k] - p_min[k])),(p_max[k] + 0.1 * (p_max[k] - p_min[k])));
	tr[0] = p_min[j] - 0.005 * (p_max[j] - p_min[j]);
	tr[1] = 0.01 * (p_max[j] - p_min[j]);
	tr[2] = 0.0;
	tr[3] = p_min[k] - 0.005 * (p_max[k] - p_min[k]);
	tr[4] = 0.0;
	tr[5] = 0.01 * (p_max[k] - p_min[k]);
	cpggray(hist2D_HD_vals,100,100,1,100,1,100,y_max,-5.0,tr);
	if(j == 0){
	  switch(k){
	  case 0:
	    cpglab("","\\(0627)","");
	    break;
	  case 1:
	    cpglab("","\\(0628)\\d1\\u","");
	    break;
	  case 2:
	    cpglab("","\\(0629)\\d1\\u","");
	    break;
	  case 3:
	    cpglab("","\\(0628)\\d2\\u","");
	    break;
	  case 4:
	    cpglab("","\\(0629)\\d2\\u","");
	    break;
	  case 5:
	    cpglab("","\\(0547)","");
	    break;
	  case 6:
	    cpglab("","\\(0534)","");
	    break;
	  case 7:
	    cpglab("","n","");
	    break;
	  default:
	    break;
	  }
	  if(k == 1){
	    cpgbox("BCNST",0,0,"BCNST",0,0);
	    cpglab("\\(0627)","","");
	  } else {
	    cpgbox("BCST",0,0,"BCNST",0,0);
	  }
	} else if((j + 1) == k) {
	  cpgbox("BCNST",0,0,"BCST",0,0);
	  switch(j){
	  case 0:
	    cpglab("\\(0627)","","");
	    break;
	  case 1:
	    cpglab("\\(0628)\\d1\\u","","");
	    break;
	  case 2:
	    cpglab("\\(0629)\\d1\\u","","");
	    break;
	  case 3:
	    cpglab("\\(0628)\\d2\\u","","");
	    break;
	  case 4:
	    cpglab("\\(0629)\\d2\\u","","");
	    break;
	  case 5:
	    cpglab("\\(0547)","","");
	    break;
	  case 6:
	    cpglab("\\(0534)","","");
	    break;
	  case 7:
	    cpglab("n","","");
	    break;
	  default:
	    break;
	  }
	} else {
	  cpgbox("BCST",0,0,"BCST",0,0);
	}
	
	// plot median values
	cpgsci(2);
	cpgsfs(2);
	cpgsch(1.5);
	cpgpt1(fit_params[(2 * j)],fit_params[(2 * k)],2);
	cpgsfs(1);
	cpgsci(1);
	cpgsch(1);
	
	det_covar_proj = (fit_covar[j][j] * fit_covar[k][k]) - (fit_covar[j][k] * fit_covar[k][j]);
	if(fabs(det_covar_proj) >= 1.0000E-30){

	  inv_covar_proj[0][0] = fit_covar[k][k] / det_covar_proj;
	  if(isnan(inv_covar_proj[0][0])){ inv_covar_proj[0][0] = 0.0; }
	  if(isinf(inv_covar_proj[0][0])){ inv_covar_proj[0][0] = (inv_covar_proj[0][0] > 0.0) ? 9E30 : -9E30; }
	  inv_covar_proj[1][0] = -1.0 * fit_covar[j][k] / det_covar_proj;
	  if(isnan(inv_covar_proj[1][0])){ inv_covar_proj[1][0] = 0.0; }
	  if(isinf(inv_covar_proj[1][0])){ inv_covar_proj[1][0] = (inv_covar_proj[1][0] > 0.0) ? 9E30 : -9E30; }
	  inv_covar_proj[0][1] = -1.0 * fit_covar[k][j] / det_covar_proj;
	  if(isnan(inv_covar_proj[0][1])){ inv_covar_proj[0][1] = 0.0; }
	  if(isinf(inv_covar_proj[0][1])){ inv_covar_proj[0][1] = (inv_covar_proj[0][1] > 0.0) ? 9E30 : -9E30; }
	  inv_covar_proj[1][1] = fit_covar[j][j] / det_covar_proj;
	  if(isnan(inv_covar_proj[1][1])){ inv_covar_proj[1][1] = 0.0; }
	  if(isinf(inv_covar_proj[1][1])){ inv_covar_proj[1][1] = (inv_covar_proj[1][1] > 0.0) ? 9E30 : -9E30; }
	  	  
	  // plot 1-sigma error ellipses
	  for(i = 0; i < (NOa - 1); i++){
	    
	    plot_angle = 6.283185307 * ((float) i) / ((float) (NOa - 1));
	    plot_radius = (float)((inv_covar_proj[1][1] * sin(plot_angle) * sin(plot_angle)) + (inv_covar_proj[0][0] * cos(plot_angle) * cos(plot_angle)) + ((inv_covar_proj[0][1] + inv_covar_proj[1][0]) * cos(plot_angle) * sin(plot_angle)));
	    if(plot_radius > 0.0){ plot_radius = sqrt((2.3 / plot_radius)); } else { plot_radius = 0.0; }
	    
	    plot_tmp_x_vals[i] = mapped_fit[j] + (plot_radius * cos(plot_angle));
	    plot_tmp_vals[i] = mapped_fit[k] + (plot_radius * sin(plot_angle));
	    switch(j){
	    case 0:
	      plot_tmp_x_vals[i] = expf(plot_tmp_x_vals[i]);
	      break;
	    case 1:
	      plot_tmp_x_vals[i] = expf(plot_tmp_x_vals[i]);
	      break;
	    case 2:
	      plot_tmp_x_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_x_vals[i]));
	      break;
	    case 3:
	      plot_tmp_x_vals[i] = expf(plot_tmp_x_vals[i]);
	      break;
	    case 4:
	      plot_tmp_x_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_x_vals[i]));
	      break;
	    case 5:
	      plot_tmp_x_vals[i] = expf(plot_tmp_x_vals[i]);
	      break;
	    case 6:
	      plot_tmp_x_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_x_vals[i]));
	      break;
	    case 7:
	      plot_tmp_x_vals[i] = 4.5 + (3.5 * sin(plot_tmp_x_vals[i]));
	      break;
	    default:
	      break;
	    }
	    switch(k){
	    case 0:
	      plot_tmp_vals[i] = expf(plot_tmp_vals[i]);
	      break;
	    case 1:
	      plot_tmp_vals[i] = expf(plot_tmp_vals[i]);
	      break;
	    case 2:
	      plot_tmp_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_vals[i]));
	      break;
	    case 3:
	      plot_tmp_vals[i] = expf(plot_tmp_vals[i]);
	      break;
	    case 4:
	      plot_tmp_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_vals[i]));
	      break;
	    case 5:
	      plot_tmp_vals[i] = expf(plot_tmp_vals[i]);
	      break;
	    case 6:
	      plot_tmp_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_vals[i]));
	      break;
	    case 7:
	      plot_tmp_vals[i] = 4.5 + (3.5 * sin(plot_tmp_vals[i]));
	      break;
	    default:
	      break;
	    }
	    if(isnan(plot_tmp_x_vals[i])){ plot_tmp_x_vals[i] = fit_params[(2 * j)]; }
	    if(isinf(plot_tmp_x_vals[i])){ plot_tmp_x_vals[i] = (plot_tmp_x_vals[i] > 0.0) ? 9E30 : -9E30; }
	    if(isnan(plot_tmp_vals[i])){ plot_tmp_vals[i] = fit_params[(2 * k)]; }
	    if(isinf(plot_tmp_vals[i])){ plot_tmp_vals[i] = (plot_tmp_vals[i] > 0.0) ? 9E30 : -9E30; }
	    	    
	  }
	  plot_tmp_x_vals[(NOa - 1)] = plot_tmp_x_vals[0];
	  plot_tmp_vals[(NOa - 1)] = plot_tmp_vals[0];
	  cpgsci(2);
	  cpgline(NOa,plot_tmp_x_vals,plot_tmp_vals);
	  cpgsci(1);
	  
	  // plot 3-sigma error ellipses
	  for(i = 0; i < (NOa - 1); i++){
	    
	    plot_angle = 6.283185307 * ((float) i) / ((float) (NOa - 1));
	    plot_radius = (float)((inv_covar_proj[1][1] * sin(plot_angle) * sin(plot_angle)) + (inv_covar_proj[0][0] * cos(plot_angle) * cos(plot_angle)) + ((inv_covar_proj[0][1] + inv_covar_proj[1][0]) * cos(plot_angle) * sin(plot_angle)));
	    if(plot_radius > 0.0){ plot_radius = sqrt((11.8 / plot_radius)); } else { plot_radius = 0.0; }
	    
	    plot_tmp_x_vals[i] = mapped_fit[j] + (plot_radius * cos(plot_angle));
	    plot_tmp_vals[i] = mapped_fit[k] + (plot_radius * sin(plot_angle));
	    switch(j){
	    case 0:
	      plot_tmp_x_vals[i] = expf(plot_tmp_x_vals[i]);
	      break;
	    case 1:
	      plot_tmp_x_vals[i] = expf(plot_tmp_x_vals[i]);
	      break;
	    case 2:
	      plot_tmp_x_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_x_vals[i]));
	      break;
	    case 3:
	      plot_tmp_x_vals[i] = expf(plot_tmp_x_vals[i]);
	      break;
	    case 4:
	      plot_tmp_x_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_x_vals[i]));
	      break;
	    case 5:
	      plot_tmp_x_vals[i] = expf(plot_tmp_x_vals[i]);
	      break;
	    case 6:
	      plot_tmp_x_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_x_vals[i]));
	      break;
	    case 7:
	      plot_tmp_x_vals[i] = 4.5 + (3.5 * sin(plot_tmp_x_vals[i]));
	      break;
	    default:
	      break;
	    }
	    switch(k){
	    case 0:
	      plot_tmp_vals[i] = expf(plot_tmp_vals[i]);
	      break;
	    case 1:
	      plot_tmp_vals[i] = expf(plot_tmp_vals[i]);
	      break;
	    case 2:
	      plot_tmp_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_vals[i]));
	      break;
	    case 3:
	      plot_tmp_vals[i] = expf(plot_tmp_vals[i]);
	      break;
	    case 4:
	      plot_tmp_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_vals[i]));
	      break;
	    case 5:
	      plot_tmp_vals[i] = expf(plot_tmp_vals[i]);
	      break;
	    case 6:
	      plot_tmp_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_vals[i]));
	      break;
	    case 7:
	      plot_tmp_vals[i] = 4.5 + (3.5 * sin(plot_tmp_vals[i]));
	      break;
	    default:
	      break;
	    }
	    if(isnan(plot_tmp_x_vals[i])){ plot_tmp_x_vals[i] = fit_params[(2 * j)]; }
	    if(isinf(plot_tmp_x_vals[i])){ plot_tmp_x_vals[i] = (plot_tmp_x_vals[i] > 0.0) ? 9E30 : -9E30; }
	    if(isnan(plot_tmp_vals[i])){ plot_tmp_vals[i] = fit_params[(2 * k)]; }
	    if(isinf(plot_tmp_vals[i])){ plot_tmp_vals[i] = (plot_tmp_vals[i] > 0.0) ? 9E30 : -9E30; }
	    
	  }
	  plot_tmp_x_vals[(NOa - 1)] = plot_tmp_x_vals[0];
	  plot_tmp_vals[(NOa - 1)] = plot_tmp_vals[0];
	  cpgsci(3);
	  cpgline(NOa,plot_tmp_x_vals,plot_tmp_vals);
	  cpgsci(1);
	 
	  // if(fabs(det_covar_proj) >= 1.00000E-30)
	} else {

	  std::cout << "Ill-conditioned matrix. Not plotting contours for combination " << j << "," << k << std::endl;
	  if(fabs(det_covar_proj) < 1.00000E-30){ std::cout << "Determinant is too small! " << det_covar_proj << " < 1.00000E-30. Not plotting contours." << std::endl; }

	}
	
	// for(k = j + 1; k < 8; k++)
      } 
      
      // for(j = 0; j < 7; j++)
    }
    delete [] plot_tmp_x_vals;
    delete [] plot_tmp_vals;
    
    // plot histograms of observational parameters
    if(vb_flag >= 0){ std::cout << "Plotting observational parameter distributions . . . " << std::endl; }
    plot_tmp_vals = new float[100];
    for(j = 0; j < 7; j++){

      // determine 1D distributions
      for(i = 0; i < 10; i++){ hist_vals[i] = 0.0; }
      for(i = 0; i < 100; i++){ hist_HD_vals[i] = 0.0; }
      SD_step = 0.1 * (obs_stats[j][3] - obs_stats[j][2]);
      HD_step = 0.01 * (obs_stats[j][3] - obs_stats[j][2]);
      y_max = -9E30;

      for(i = 0; i < NOr; i++){

	k = (int) floorf(((rand_obs_vals[i][j] - obs_stats[j][2])/SD_step));
	if((k >= 0) && (k < 10)){ 

	  hist_vals[k]+=(1.0/(10.0 * (float) NOr)); 
	  y_max = (y_max > hist_vals[k]) ? y_max : hist_vals[k];

	}
	k = (int) floorf(((rand_obs_vals[i][j] - obs_stats[j][2])/HD_step));
	if((k >= 0) && (k < 100)){ 

	  hist_HD_vals[k]+=(1.0/((float) NOr)); 
	  y_max = (y_max > hist_HD_vals[k]) ? y_max : hist_HD_vals[k];

	}

	// for(i = 0; i < NOr; i++)
      }

      // plot 1D distributions
      if(y_max <= 0.0){ y_max = 0.1; }
      cpgenv(obs_stats[j][2],obs_stats[j][3],(-0.025 * y_max),(1.025 * y_max),0,0);
      for(i = 0; i < 100; i++){ plot_tmp_vals[i] = obs_stats[j][2] + (((float) i + 0.5) * HD_step); }
      cpgline(100,plot_tmp_vals,hist_HD_vals);
      cpgsci(2);
      for(i = 0; i < 10; i++){ plot_tmp_vals[i] = obs_stats[j][2] + (((float) i + 0.5) * SD_step); }
      cpgline(10,plot_tmp_vals,hist_vals);
      cpgsci(1);
      switch (j){
      case 0:
	cpglab("total flux","relative distribution","");
	break;
      case 1:
	cpglab("peak flux","relative distribution","");
	break;
      case 2:
	cpglab("peak flux position","relative distribution","");
	break;
      case 3:
	cpglab("W\\d50\\u width","realative distribution","");
	break;
      case 4:
	cpglab("W\\d50\\u position","relative distribution","");
	break;
      case 5:
	cpglab("W\\d20\\u width","relative distribution","");
	break;
      case 6:
	cpglab("W\\d20\\u position","relative distribution","");
	break;
      default:
	break;
      }

      // for(j = 0; j < 7; j++)
    }
    delete [] plot_tmp_vals;
    
    // plot 2-D histograms of observational parameters
    plot_tmp_x_vals = new float[NOa];
    plot_tmp_vals = new float[NOa];
    cpgpage();
    for(j = 0; j < 7; j++){

      for(k = j; k < 7; k++){
	  
	// initialise 2D distribution peak
	y_max = -9E30;
	
	// determine 2D distributions
	for(i = 0; i < 100; i++){ hist2D_vals[i] = 0.0; }
	for(i = 0; i < 10000; i++){ hist2D_HD_vals[i] = 0.0; }
	SD_step = 0.01 * (obs_stats[j][3] - obs_stats[j][2]) * (obs_stats[k][3] - obs_stats[k][2]);
	HD_step = 0.01 * SD_step;
	for(i = 0; i < NOr; i++){
	  
	  m = (int) floorf(((rand_obs_vals[i][j] - obs_stats[j][2])/(0.1 * (obs_stats[j][3] - obs_stats[j][2]))));
	  v = (int) floorf(((rand_obs_vals[i][k] - obs_stats[k][2])/(0.1 * (obs_stats[k][3] - obs_stats[k][2]))));
	  if((m >= 0) && (m < 10) && (v >= 0) && (v < 10)){
	    
	    hist2D_vals[(m + (10 * v))]+=(0.01/((float) NOr));
	    y_max = (y_max > hist2D_vals[(m + (10 * v))]) ? y_max : hist2D_vals[(m + (10 * v))];
	    
	  }
	  m = (int) floorf(((rand_obs_vals[i][j] - obs_stats[j][2])/(0.01 * (obs_stats[j][3] - obs_stats[j][2]))));
	  v = (int) floorf(((rand_obs_vals[i][k] - obs_stats[k][2])/(0.01 * (obs_stats[k][3] - obs_stats[k][2]))));
	  if((m >= 0) && (m < 100) && (v >= 0) && (v < 100)){
	    
	    hist2D_HD_vals[(v + (100 * m))]+=(1.0/((float) NOr));
	    y_max = (y_max > hist2D_HD_vals[(v + (100 * m))]) ? y_max : hist2D_HD_vals[(v + (100 * m))];
	    
	  }
	  
	  // for(i = 0; i < NOr; i++)
	}
	
	// convert 2D histrograms to logarithmic counts
	for(i = 0; i < 100; i++){ 
	  if(hist2D_vals[i] > 0.0){ hist2D_vals[i] = log(hist2D_vals[i])/log(10.0); } else { hist2D_vals[i] = -1000.0; }
	}
	for(i = 0; i < 10000; i++){
	  if(hist2D_HD_vals[i] > 0.0){ hist2D_HD_vals[i] = log(hist2D_HD_vals[i])/log(10.0); } else { hist2D_HD_vals[i] = -1000.0; }
	}

	// plot SD 2D histogram
	if(y_max > 0.0){ y_max = log(y_max)/log(10.0); } else { y_max = -1000.0; }
	if(j != k){

	  cpgsvp((0.10 + (0.125 * (float) j)),(0.1 + (0.125 * (float) (j + 1))),(0.10 + (0.125 * (float) k)),(0.1 + (0.125 * (float) (k + 1))));
	  cpgswin((obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])));
	  tr[0] = obs_stats[j][2] - 0.05 * (obs_stats[j][3] - obs_stats[j][2]);
	  tr[1] = 0.1 * (obs_stats[j][3] - obs_stats[j][2]);
	  tr[2] = 0.0;
	  tr[3] = obs_stats[k][2] - 0.05 * (obs_stats[k][3] - obs_stats[k][2]);
	  tr[4] = 0.0;
	  tr[5] = 0.1 * (obs_stats[k][3] - obs_stats[k][2]);
	  cpggray(hist2D_vals,10,10,1,10,1,10,y_max,-5.0,tr);
	  if(j == 0){
	    switch(k){
	    case 0:
	      cpglab("","T\\dflux\\u","");
	      break;
	    case 1:
	      cpglab("","P\\dflux\\u","");
	      break;
	    case 2:
	      cpglab("","P\\df\\u pos.","");
	      break;
	    case 3:
	      cpglab("","W\\d50\\u width","");
	      break;
	    case 4:
	      cpglab("","W\\d50\\u position","");
	      break;
	    case 5:
	      cpglab("","W\\d20\\u width","");
	      break;
	    case 6:
	      cpglab("","W\\d20\\u position","");
	      break;
	    default:
	      break;
	    }
	    if(k == 0){
	      cpgbox("BCNST",0,0,"BCNST",0,0);
	    } else {
	      cpgbox("BCST",0,0,"BCNST",0,0);
	    }
	  } else {
	    if(k == 0){
	      cpgbox("BCNST",0,0,"BCST",0,0);
	    } else {
	      cpgbox("BCST",0,0,"BCST",0,0);
	    }
	  }

	  // plot median values
	  cpgsci(2);
	  cpgsfs(2);
	  cpgsch(1.5);
	  cpgpt1(obs_stats[j][0],obs_stats[k][0],2);
	  cpgsfs(1);
	  cpgsci(1);
	  cpgsch(1);

	  // if(j != k)
	}

	// plot HD 2D histogram
	cpgsvp((0.1 + (0.125 * (float) k)),(0.1 + (0.125 * (float) (k + 1))),(0.1 + (0.125 * (float) j)),(0.1 + (0.125 * (float) (j + 1))));
	cpgswin((obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])));
	tr[0] = obs_stats[k][2] - 0.005 * (obs_stats[k][3] - obs_stats[k][2]);
	tr[1] = 0.01 * (obs_stats[k][3] - obs_stats[k][2]);
	tr[2] = 0.0;
	tr[3] = obs_stats[j][2] - 0.005 * (obs_stats[j][3] - obs_stats[j][2]);
	tr[4] = 0.0;
	tr[5] = 0.01 * (obs_stats[j][3] - obs_stats[j][2]);
	cpggray(hist2D_HD_vals,100,100,1,100,1,100,y_max,-5.0,tr);
	if(j == 0){
	  if(k == 0){
	    cpgbox("BCNST",0,0,"BCNST",0,0);
	    cpglab("T\\dflux\\u","T\\dflux\\u","");
	  } else {
	    cpgbox("BCNST",0,0,"BCST",0,0);
	    switch(k){
	    case 0:
	      cpglab("T\\dflux\\u","","");
	      break;
	    case 1:
	      cpglab("P\\dflux\\u","","");
	      break;
	    case 2:
	      cpglab("P\\df\\u pos.","","");
	      break;
	    case 3:
	      cpglab("W\\d50\\u width","","");
	      break;
	    case 4:
	      cpglab("W\\d50\\u position","","");
	      break;
	    case 5:
	      cpglab("W\\d20\\u width","","");
	      break;
	    case 6:
	      cpglab("W\\d20\\u position","","");
	      break;
	    default:
	      break;
	    }
	  }
	} else {
	  cpgbox("BCST",0,0,"BCST",0,0);
	}
	
	// plot median values
	cpgsci(2);
	cpgsfs(2);
	cpgsch(1.5);
	cpgpt1(obs_stats[k][0],obs_stats[j][0],2);
	cpgsfs(1);
	cpgsci(1);
	cpgsch(1);

	// plot error ellipses or error intervals for a single parameter
       	if(j != k){

	  // calculate inverse of covariance matrix projection for this parameter combination	
	  det_covar_proj = (obs_covar[j][j] * obs_covar[k][k]) - (obs_covar[j][k] * obs_covar[k][j]);
	  if((fabs(det_covar_proj) >= 1.00000E-30) && (fabs(obs_covar[j][j]) >= 1.00000E-30) && (fabs(obs_covar[j][k]) >= 1.00000E-30) && (fabs(obs_covar[k][j]) >= 1.00000E-30) && (fabs(obs_covar[k][k]) >= 1.00000E-30)){
	    
	    inv_covar_proj[0][0] = obs_covar[k][k] / det_covar_proj;
	    if(isnan(inv_covar_proj[0][0])){ inv_covar_proj[0][0] = 0.0; }
	    if(isinf(inv_covar_proj[0][0])){ inv_covar_proj[0][0] = (inv_covar_proj[0][0] > 0.0) ? 9E30 : -9E30; }
	    inv_covar_proj[1][0] = -1.0 * obs_covar[j][k] / det_covar_proj;
	    if(isnan(inv_covar_proj[1][0])){ inv_covar_proj[1][0] = 0.0; }
	    if(isinf(inv_covar_proj[1][0])){ inv_covar_proj[1][0] = (inv_covar_proj[1][0] > 0.0) ? 9E30 : -9E30; }
	    inv_covar_proj[0][1] = -1.0 * obs_covar[k][j] / det_covar_proj;
	    if(isnan(inv_covar_proj[0][1])){ inv_covar_proj[0][1] = 0.0; }
	    if(isinf(inv_covar_proj[0][1])){ inv_covar_proj[0][1] = (inv_covar_proj[0][1] > 0.0) ? 9E30 : -9E30; }
	    inv_covar_proj[1][1] = obs_covar[j][j] / det_covar_proj;
	    if(isnan(inv_covar_proj[1][1])){ inv_covar_proj[1][1] = 0.0; }
	    if(isinf(inv_covar_proj[1][1])){ inv_covar_proj[1][1] = (inv_covar_proj[1][1] > 0.0) ? 9E30 : -9E30; }
	    
	    // plot 1-sigma error ellipses
	    for(i = 0; i < (NOa - 1); i++){
	      
	      plot_angle = 6.283185307 * ((float) i) / ((float) (NOa - 1));
	      plot_radius = (float)((inv_covar_proj[1][1] * sin(plot_angle) * sin(plot_angle)) + (inv_covar_proj[0][0] * cos(plot_angle) * cos(plot_angle)) + ((inv_covar_proj[0][1] + inv_covar_proj[1][0]) * cos(plot_angle) * sin(plot_angle)));
	      if(plot_radius > 0.0){ plot_radius = sqrt((2.3 / plot_radius)); } else { plot_radius = 0.0; }
	      
	      plot_tmp_x_vals[i] = obs_stats[j][0] + (plot_radius * cos(plot_angle));
	      plot_tmp_vals[i] = obs_stats[k][0] + (plot_radius * sin(plot_angle));
	      if(isnan(plot_tmp_x_vals[i])){ plot_tmp_x_vals[i] = fit_params[(2 * j)]; }
	      if(isinf(plot_tmp_x_vals[i])){ plot_tmp_x_vals[i] = (plot_tmp_x_vals[i] > 0.0) ? 9E30 : -9E30; }
	      if(isnan(plot_tmp_vals[i])){ plot_tmp_vals[i] = fit_params[(2 * k)]; }
	      if(isinf(plot_tmp_vals[i])){ plot_tmp_vals[i] = (plot_tmp_vals[i] > 0.0) ? 9E30 : -9E30; }
	      
	    }
	    plot_tmp_x_vals[(NOa - 1)] = plot_tmp_x_vals[0];
	    plot_tmp_vals[(NOa - 1)] = plot_tmp_vals[0];
	    
	    // re-set viewport to SD 2D distribution
	    cpgsvp((0.10 + (0.125 * (float) j)),(0.1 + (0.125 * (float) (j + 1))),(0.10 + (0.125 * (float) k)),(0.1 + (0.125 * (float) (k + 1))));
	    cpgswin((obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])));
	    cpgsci(2);
	    cpgline(NOa,plot_tmp_x_vals,plot_tmp_vals);
	    cpgsci(1);
	    
	    // re-set viewport to HD 3D distribution
	    cpgsvp((0.1 + (0.125 * (float) k)),(0.1 + (0.125 * (float) (k + 1))),(0.1 + (0.125 * (float) j)),(0.1 + (0.125 * (float) (j + 1))));
	    cpgswin((obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])));
	    for(i = 0; i < NOa; i++){
	      plot_angle = plot_tmp_x_vals[i];
	      plot_tmp_x_vals[i] = plot_tmp_vals[i];
	      plot_tmp_vals[i] = plot_angle;
	    }
	    cpgsci(2);
	    cpgline(NOa,plot_tmp_x_vals,plot_tmp_vals);
	    cpgsci(1);
	    
	    // plot 3-sigma error ellipses
	    for(i = 0; i < (NOa - 1); i++){
	      
	      plot_angle = 6.283185307 * ((float) i) / ((float) (NOa - 1));
	      plot_radius = (float)((inv_covar_proj[1][1] * sin(plot_angle) * sin(plot_angle)) + (inv_covar_proj[0][0] * cos(plot_angle) * cos(plot_angle)) + ((inv_covar_proj[0][1] + inv_covar_proj[1][0]) * cos(plot_angle) * sin(plot_angle)));
	      if(plot_radius > 0.0){ plot_radius = sqrt((11.8 / plot_radius)); } else { plot_radius = 0.0; }
	      
	      plot_tmp_x_vals[i] = obs_stats[j][0] + (plot_radius * cos(plot_angle));
	      plot_tmp_vals[i] = obs_stats[k][0] + (plot_radius * sin(plot_angle));
	      if(isnan(plot_tmp_x_vals[i])){ plot_tmp_x_vals[i] = fit_params[(2 * j)]; }
	      if(isinf(plot_tmp_x_vals[i])){ plot_tmp_x_vals[i] = (plot_tmp_x_vals[i] > 0.0) ? 9E30 : -9E30; }
	      if(isnan(plot_tmp_vals[i])){ plot_tmp_vals[i] = fit_params[(2 * k)]; }
	      if(isinf(plot_tmp_vals[i])){ plot_tmp_vals[i] = (plot_tmp_vals[i] > 0.0) ? 9E30 : -9E30; }
	      
	    }
	    plot_tmp_x_vals[(NOa - 1)] = plot_tmp_x_vals[0];
	    plot_tmp_vals[(NOa - 1)] = plot_tmp_vals[0];
	    
	    // re-set viewport to SD 2D distribution
	    cpgsvp((0.10 + (0.125 * (float) j)),(0.1 + (0.125 * (float) (j + 1))),(0.10 + (0.125 * (float) k)),(0.1 + (0.125 * (float) (k + 1))));
	    cpgswin((obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])));
	    cpgsci(3);
	    cpgline(NOa,plot_tmp_x_vals,plot_tmp_vals);
	    cpgsci(1);
	    
	    // re-set viewport to HD 3D distribution
	    cpgsvp((0.1 + (0.125 * (float) k)),(0.1 + (0.125 * (float) (k + 1))),(0.1 + (0.125 * (float) j)),(0.1 + (0.125 * (float) (j + 1))));
	    cpgswin((obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])));
	    for(i = 0; i < NOa; i++){
	      plot_angle = plot_tmp_x_vals[i];
	      plot_tmp_x_vals[i] = plot_tmp_vals[i];
	      plot_tmp_vals[i] = plot_angle;
	    }
	    cpgsci(3);
	    cpgline(NOa,plot_tmp_x_vals,plot_tmp_vals);
	    cpgsci(1);
	    
	    // if(fabs(det_covar_proj) >= 1.00000E-30)
	  } else {
	    
	    std::cout << "Ill-conditioned matrix. Not plotting contours for combination " << j << "," << k << std::endl;
	    if(fabs(det_covar_proj) < 1.00000E-30){ std::cout << "Determinant is too small! " << det_covar_proj << " < 1.00000E-30. Not plotting contours." << std::endl; }
	    
	  }

	} else {

	  // re-set viewport to SD 2D distribution
	  cpgsvp((0.10 + (0.125 * (float) j)),(0.1 + (0.125 * (float) (j + 1))),(0.10 + (0.125 * (float) k)),(0.1 + (0.125 * (float) (k + 1))));
	  cpgswin((obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])));
	  cpgsci(2);
	  cpgmove((obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(-1.0 * (obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] + obs_stats[k][1] + obs_stats[j][0] + obs_stats[j][1]));
	  cpgdraw((obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(-1.0 * (obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] + obs_stats[k][1] + obs_stats[j][0] + obs_stats[j][1]));
	  cpgmove((obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(-1.0 * (obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] - obs_stats[k][1] + obs_stats[j][0] - obs_stats[j][1]));
	  cpgdraw((obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(-1.0 * (obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] - obs_stats[k][1] + obs_stats[j][0] - obs_stats[j][1]));
	  cpgsci(3);
	  cpgmove((obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(-1.0 * (obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] + obs_stats[j][0] + (3.0 * obs_stats[k][1] + obs_stats[j][1])));
	  cpgdraw((obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(-1.0 * (obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] + obs_stats[j][0] + (3.0 * obs_stats[k][1] + obs_stats[j][1])));
	  cpgmove((obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(-1.0 * (obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] + obs_stats[j][0] - (3.0 * obs_stats[k][1] + obs_stats[j][1])));
	  cpgdraw((obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(-1.0 * (obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] + obs_stats[j][0] - (3.0 * obs_stats[k][1] + obs_stats[j][1])));
	  cpgsci(1);
	  
	  // re-set viewport to HD 3D distribution
	  cpgsvp((0.1 + (0.125 * (float) k)),(0.1 + (0.125 * (float) (k + 1))),(0.1 + (0.125 * (float) j)),(0.1 + (0.125 * (float) (j + 1))));
	  cpgswin((obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])));
	  cpgsci(2);
	  cpgmove((obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(-1.0 * (obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] + obs_stats[j][1] + obs_stats[k][0] + obs_stats[k][1]));
	  cpgdraw((obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(-1.0 * (obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] + obs_stats[j][1] + obs_stats[k][0] + obs_stats[k][1]));
	  cpgmove((obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(-1.0 * (obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] - obs_stats[j][1] + obs_stats[k][0] - obs_stats[k][1]));
	  cpgdraw((obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(-1.0 * (obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] - obs_stats[j][1] + obs_stats[k][0] - obs_stats[k][1]));
	  cpgsci(3);
	  cpgmove((obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(-1.0 * (obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] + obs_stats[k][0] - (3.0 * obs_stats[j][1] + obs_stats[k][1])));
	  cpgdraw((obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(-1.0 * (obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] + obs_stats[k][0] - (3.0 * obs_stats[j][1] + obs_stats[k][1])));
	  cpgmove((obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(-1.0 * (obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] + obs_stats[k][0] - (3.0 * obs_stats[j][1] + obs_stats[k][1])));
	  cpgdraw((obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(-1.0 * (obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] + obs_stats[k][0] - (3.0 * obs_stats[j][1] + obs_stats[k][1])));
	  cpgsci(1);
	  	  
	  // if(j == k)
	}

	// for(k = j + 1; k < 7; k++)
      }

      // for(j = 0; j < 7; j++)
    }
    delete [] plot_tmp_vals;
    delete [] plot_tmp_x_vals;
    
    // close output plot
    cpgclos();

    // free up memory
    delete [] x_vals;
    delete [] y_vals;
    delete [] n_vals;
    delete [] fit_params;
    for(i = 0; i < 8; i++){ delete [] fit_covar[i]; }
    delete [] fit_covar;
    for(i = 0; i < NOr; i++){ 
      delete [] rand_fits[i];
      delete [] rand_obs_vals[i];
    }
    delete [] rand_fits;
    delete [] rand_obs_vals;
    for(i = 0; i < 7; i++){ 
      delete [] obs_stats[i]; 
      delete [] obs_covar[i];
    }
    delete [] obs_stats;
    delete [] obs_covar;

    // free up plotting memory
    delete [] hist_vals;
    delete [] hist_HD_vals;
    delete [] hist2D_vals;
    delete [] hist2D_HD_vals;
 
    // if(infile.is_open())
  } else {

    std::cout << "ERROR!!! Couldn't open input file: " << infile_name << "\nExiting program . . . " << std::endl;
    
  }
  
  // int main(int argc, char* argv[])
}






