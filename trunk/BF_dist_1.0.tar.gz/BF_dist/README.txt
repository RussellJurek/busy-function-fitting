V1.0 --- Created by Russell J. Jurek, 30th June 2013. Email: Russell.Jurek@gmail.com 


===============================================================================================================================
OVERVIEW
===============================================================================================================================
This package fits the Busy Function (see Westmeier, Jurek, Obreschkow & Koribalski 2013) to user supplied data. This package 
uses the implementation described in Westemeier et al. (2013). Please cite this paper in any published works that utilise this 
package. 

This package fits the following forumulation of the Busy Function,

y(x) = 0.25 * alpha * {1 + erf[beta_1 * (x - gamma_1)]} * {1 + erf[beta_2 * (gamma_2 - x)]} * {1 + phi * [x - theta]^N},

where the following constraints are applied using variable re-mapping: alpha >= 0.0, beta_1 >= 0.0, beta_2 >= 0.0, 
phi >= 0.0, 2 <= N <= 8, x_min <= gamma_1 <= x_max, x_min <= gamma_2 <= x_max and x_min <= theta <= x_max. Note 
that the beta_1 and beta_2 constraints implicitly imposes a weak constraint, gamma_1 (almost always) <= gamma_2. 

This package consists of a C library, C++ library and a Python module. It does *NOT* require any other libraries. It is 
self contained and *FREE* for academic (research & teaching) purposes. 

This package is structured in the following way:

sub-directory C: Contains the source code for the C library. After installation, this will contain the C library
                 libcBFfit_OMP.a. This *MUST* be installed before attempting to install the Python module. You will also 
                 find an example C program (cFitSpectrum.c) demonstrating how to use the C library. This example program can
		 be used to fit the Busy Function to a text file containing x, y and noise values --- each line is a 
		 frequency/wavelength.

sub-directory CPP: Contains the source code for the C++ library. After installation, this will contain the C++ library
                   libBFfit_OMP.a. You will also find an example C++ program (FitSpectrum.cpp) demonstrating how to use the 
		   C++ library. This example program can be used to fit the Busy Function to a text file containing x, y and 
		   noise values --- each line is a frequency/wavelength.

sub-directory python: Contains the python wrapper required to build the python module, BusyFunc, from the C library, 
	      	      libcBFfit_OMP.a. CAUTION: The C library *MUST* be built before attempting to create this python module.
		      After installation this directory will contain a build of the BusyFunc module. You will also find an 
		      example python script (FitSpectrum.py) demonstrating how to use the module. This example program can 
		      be used to fit the Busy Function to a text file containing x, y and noise values --- each line is a 
		      frequency/wavelength.

sub-directory bin: After installation, this directory will contain the FitSpectrum and cFitSpectrum programs.

sub-directory test_data: This directory contains 19 test files that can be used with any of the test programs to verify your
	      		 installation. The first line in each file contains the input parameters used to generate this data 
			 file. The order of these parameters matches the output structure of this package (see below).

===============================================================================================================================
INSTALLATION
===============================================================================================================================

---------------------------------------
C/C++
---------------------------------------
Follow these instructions to compile and install the C & C++ libraries. 
1. At the terminal, navigate to the top level directory where you found this README.
2. Execute the command,
   
   make all
   
   The C & C++ libraries will now be built and the C & C++ example programs will be in the bin sub-directory.
3. An optional command is,
   
   make install

   This will copy the C & C++ libraries and headers to the standard places on Unix/OS X (Mac) systems, 
   /usr/local/lib & /usr/local/include.

If something goes wrong, make sure to execute the command,

   make clean

before trying again. On OS X (Mac), the ranlib tool will sometimes fail if it finds a previous, failed attempt to create a 
library. It's part of the Mac OS X setup. There's nothing I can do about it.

In summary,

   make all
   make install

You're done.

---------------------------------------
Python
---------------------------------------
Follow these instructions to build the python module, BusyFunc.
1. Create the C library first. This is a NECESSITY!
2. Navigate to the BF_dist/python sub-directory in the terminal.
3. Build the BusyFunc module with the command,

   python setup.py build

   This will create a BF_dist/python/build sub-directory containg a local copy of the BusyFunc module. 

4. Integrate the BusyFunc module into your python installation,

   python setup.py install

If you need to start over, you can use the following command,

   python setup.py clean

WARNING!!! On some systems, your C/C++ compiler might build a library for a different architecture than the target 
	   architecture used by your python installation. This can happen if you use multiple compilers/python installations.
	   The simplest solution is to specify a target architecture for either the C library or the python module. Option 1 
	   is to recreate the C library with the appropriate value of the "-arch" flag, "-arch i386" or "-arch x86_64". 
	   Option 2 is to specify the python architecture, for example,
	   
	   ARCHFLAGS="-arch x86_64" python setup.py build
	   ARCHFLAGS="-arch x86_64" python setup.py install

===============================================================================================================================
USAGE
===============================================================================================================================

---------------------------------------
C
---------------------------------------

Usage:

int FitBusyFunc_flt(int NOvals, float * x_vals, float * y_vals, float * n_vals, float * fit_params, float ** fit_covar, int vb_flag);

    or

int FitBusyFunc_dbl(int NOvals, double * x_vals, double * y_vals, double * n_vals, double * fit_params, double ** fit_covar, int vb_flag);

Two versions of the Busy Function fitting routine are provided for processing either single-precision (float) or 
double-precision (double) data.

Input:
This function takes 7 iputs. The first is the number of data points. The next three are pointers/arrays containing the 
x values, y values and errors in the y values. A list of "1"s should be used when you don't have/want to use uncertainties 
in the y values. Alternatively, spuriously large uncertainties can be assigned to y values that you want the fitting program 
to ignore eg. channels dominated by RFI in integrated HI spectra.

The next two arguments, fit_params and fit_covar, are pointers/arrays that will contain the fitting results.

WARNING!!! fit_params[4] and fit_params[8] *MUST* be populated with x_min and x_max limits. These x_min and x_max limits are
applied to the error function positions. Note that these values will be range tested against the limits of the x_vals array.

The verbose_flag is an integer that specifies the amount of diagnostic output displayed on the terminal. Values of -1, 0 and 1 
generate none, minimal, and maximal diagnostic output.

Output:
This function's return value is the dimensionality of the Busy Function fit.

The input arguments, fit_params and fit_covar, contain the fitting results. The structure is described at the end.


---------------------------------------
C++
---------------------------------------

Usage:

template <class T_count, class T_xvals, class T_data, class T_result>
  int FitBusyFunc(T_count NOvals, T_xvals * x_vals, T_data * y_vals, T_data * n_vals, T_result * fit_params, T_result ** fit_covar, int vb_flag){ . . .}

This C++ library utilises templated functions to allow flexible data types for both input and output.

Input:
This function takes 7 iputs. The first is the number of data points. The next three are pointers/arrays containing the 
x values, y values and errors in the y values. A list of "1"s should be used when you don't have/want to use uncertainties 
in the y values. Alternatively, spuriously large uncertainties can be assigned to y values that you want the fitting program 
to ignore eg. channels dominated by RFI in integrated HI spectra.

The next two arguments, fit_params and fit_covar, are pointers/arrays that will contain the fitting results. 

WARNING!!! fit_params[4] and fit_params[8] *MUST* be populated with x_min and x_max limits. These x_min and x_max limits are
applied to the error function positions. Note that these values will be range tested against the limits of the x_vals array.

The verbose_flag is an integer that specifies the amount of diagnostic output displayed on the terminal. Values of -1, 0 and 1 
generate none, minimal, and maximal diagnostic output.

Output:
This function's return value is the dimensionality of the Busy Function fit.

The input arguments, fit_params and fit_covar, contain the fitting results. The structure is described at the end.


---------------------------------------
Python
---------------------------------------

Usage: 

dims, fit_params, fit_covar = BusyFunc.fit(x_vals,y_vals,y_err_vals,verbose_flag,x_min,x_max) 

Input: 
This package takes six arguments. The first three are lists containing the x values, y values and errors in the y values. A 
list of "1"s should be used when you don't have/want to use uncertainties in the y values. Alternatively, spuriously large 
uncertainties can be assigned to y values that you want the fitting program to ignore eg. channels dominated by RFI in 
integrated HI spectra.

The verbose_flag specifies the amount of diagnostic output displayed on the terminal. Values of -1, 0 and 1 generate none, 
minimal, and maximal diagnostic output.

The x_min and x_max values specifies the region within the data believed to contain signal. This can be set to x_vals[0] and 
x_vals[len(x_vals) - 1] without causing any problems. If you know that the first 10 and last 20 values are noise however, 
setting x_min and x_max accordingly will improve your fitting results. 

Output:
This package returns a 3-tuple containg an integer and two lists. The first tuple value is an integer value. It is the 
dimensionality of the Busy Function fit. Possible values are 4 through 8. The second tuple is a list. This list contains 17 
float values. The first 16 are the Busy Function fit values and their uncertainties. The final value is the chi-squared value 
of the Busy Function fit. The second list is 64 float values. This second list contains the covariance matrix of the Busy 
Function fit. The covariance matrix can be used to check for degeneracies in the Busy Function fit.

Common to C/C++ & Python
---------------------------------------

Output structure:

fit_params = 
	     (alpha, alpha error,
	     beta_1, beta_1 error,
	     gamma_1, gamma_1 error,
	     beta_2, beta_2 error,
	     gamma_2, gamma_2 error
	     phi, phi error,
	     theta, theta error,
	     N, N error)

fit_covar = (alpha x alpha, alpha x beta_1, alpha x gamma_1, alpha x beta_2, alpha x gamma_2, alpha x phi, alpha x theta, alpha x N
	    beta_1 x alpha, beta_1 x beta_1, beta_1 x gamma_1, beta_1 x beta_2, beta_1 x gamma_2, beta_1 x phi, beta_1 x theta, beta_1 x N
	    gamma_1 x alpha, gamma_1 x beta_1, gamma_1 x gamma_1, gamma_1 x beta_2, gamma_1 x gamma_2, gamma_1 x phi, gamma_1 x theta, gamma_1 x N
	    beta_2 x alpha, beta_2 x beta_1, beta_2 x gamma_1, beta_2 x beta_2, beta_2 x gamma_2, beta_2 x phi, beta_2 x theta, beta_2 x N
	    gamma_2 x alpha, gamma_2 x beta_1, gamma_2 x gamma_1, gamma_2 x beta_2, gamma_2 x gamma_2, gamma_2 x phi, gamma_2 x theta, gamma_2 x N
	    phi x alpha, phi x beta_1, phi x gamma_1, phi x beta_2, phi x gamma_2, phi x phi, phi x theta, phi x N
	    theta x alpha, theta x beta_1, theta x gamma_1, theta x beta_2, theta x gamma_2, theta x phi, theta x theta, theta x N
	    N x alpha, N x beta_1, N x gamma_1, N x beta_2, N x gamma_2, N x phi, N x theta, N x N)

