/*

This is a demonstration program for  version 1.0 of the C++ BusyFunc library that fits the 
Busy Function to data. See Westmeier, Jurek, Obreschkow & Koribalski (2013) for more details 
about the implementation of this library and the Busy Function.

Created by Russell J. Jurek, 30th June 2013.
Email: Russell.Jurek@gmail.com

 */

#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<BFfit_OMP.h>
#include<iomanip>

int main(int argc, char* argv[]){

  std::fstream infile;
  std::string dummy1, infile_name;
  std::stringstream dummy2;
  int i,j,k,m,length,v,NOvals,vb_flag = -1, cols[3] = {0,1,-99};
  float * x_vals, * y_vals, * n_vals, * fit_params, ** fit_covar;

  // test if insufficient arguments were specified on the command line
  if((argc == 1) || (argc >= 7)){ std::cout << "Incorrect number of arguments. Use `FitSpectrum -h' to view instructions." << std::endl; return 0; }

  // get input file from the command line
  dummy2.str("");
  dummy2.clear();
  dummy2 << argv[1];
  dummy1 = "";
  dummy2 >> infile_name;

  // display instructions if the first entry on the command line was -h or -H
  if((infile_name == "-h") || (infile_name == "-H")){ std::cout << "Instructions for FitSpectrum: \n\nThis program uses the C++ Busy Function fitting library to fit the Busy Function to a single spectra. This program assumes that each line of the input file contains an x and y value, as well as an optional noise value for each (x,y). This program also assumes space delimited input files.\n\nUsage: FitSpectrum input_file [x_col] [y_col] [noise_col] [-v or -vv] \n       FitSpectrum -h\n\nThe input_file is the only mandatory input. All other inputs are optional, which is represented by []. The optional inputs are:\nx_col: The column containing the x values. Count from 0. Default is 0.\ny_col: The column containing the y values. Count from 0. Default is 1.\nnoise_col: The column containing the noise values. Default is -99, which assigns a value of 1 for every x.\n-v: Turn verbosity to medium (default is none).\n-vv: Turn verbosity to high (default is none).\n\nThe fitting results are written to the terminal. The first value is the dimensionality of the best fitting BF model. The next 16 values are the BF fit parameters and their uncertainties (listed in value, error pairs). The next value is chi^2. The remaining 64 values are the chi^2 covariance matrix.\nThe values are written out in scientific notation to accommodate especially large or small values.\n" << std::endl; return 0; }

  // get input columns and -v/-vv from the command line --- if specified
  for(i = 2; ((i < argc) && (i < 6)); i++){

    dummy2.str("");
    dummy2.clear();
    dummy2 << argv[i];
    dummy1 = "";
    dummy2 >> dummy1;
    if((dummy1 == "-v") || (dummy1 == "-V")){ 
      vb_flag = 0; 
      break;
    } else if((dummy1 == "-vv") || (dummy1 == "-VV") || (dummy1 == "-Vv") || (dummy1 == "-vV")){ 
      vb_flag = 1; 
      break;
    } else {
      dummy2.str("");
      dummy2.clear();
      dummy2 << dummy1;
      dummy2 >> cols[(i - 2)];
    }

  }

  // display columns to be used
  if(vb_flag >= 0){ std::cout << "Using x_col = " << cols[0] << ", y_col = " << cols[1] << " & noise_col = " << cols[2] << std::endl; }

  // open input file
  if(vb_flag >= 0){ std::cout << "Opening input file: " << infile_name << std::endl; }
  infile.open(infile_name.c_str(),std::ios::in);

  // check that the input file is open
  if(infile.is_open()){

    // create arrays used by BusyFunc
    fit_params = new float[17];
    fit_covar =  new float * [8];
    for(i = 0; i < 8; i++){ fit_covar[i] = new float[8]; }

    // count the number of entries in the input file
    NOvals = 0;
    while(!(infile.eof())){
      
      dummy1 = "";
      getline(infile,dummy1);
      if ((dummy1 != "") && (dummy1.find("#",0) == std::string::npos)){ NOvals++;  }
      
    }
    infile.clear();
    infile.seekg(0,std::ios::beg);
    if(vb_flag >= 0){ std::cout << NOvals << " entries in the source+noise catalogue." << std::endl; }
    
    // allocate memory to store input file
    x_vals = new float[NOvals];
    y_vals = new float[NOvals];
    n_vals = new float[NOvals];
    
    // read input file into memory
    if(vb_flag >= 0){ std::cout << "Reading source+noise objects into arrays . . . " << std::endl; }
    v = 0;
    while((!(infile.eof())) && (v < NOvals)){
      dummy1 = "";
      getline(infile,dummy1);
      if ((dummy1.find("#",0) != std::string::npos) || (dummy1 == "")){ continue; }
      m = 0;
      i = 0;
      while(i > -1){
	j = dummy1.find_first_not_of(" ",m);
	if (j == std::string::npos) { i = -99; continue; }
	k = dummy1.find_first_of(" ",j+1);
	if (k == std::string::npos) { k = dummy1.length(); }
	m = k + 1;
	length = k - j;
	dummy2.str("");
	dummy2.clear();
	dummy2.str(dummy1.substr(j,length));
	if(i == cols[0]){ dummy2 >> x_vals[v]; }
	if(i == cols[1]){ dummy2 >> y_vals[v]; }
	if(i == cols[2]){ dummy2 >> n_vals[v]; }
	
	// increment column index
	i++;
	
	// close while loop that loads data into variables
      }      
      
      // specify constant noise = 1.0 if cols[2] < 0
      if(cols[2] < 0){ n_vals[v] = 1.0; }
      
      // increment array index
      v++;
      
      // close while loop loading infile into arrays
    }
    if(vb_flag >= 0){ std::cout << "done." << std::endl; }
    
    // close input file
    infile.close();
    
    // specify initial roll-off range
    fit_params[4] = x_vals[0] + (0.05 * (x_vals[(NOvals - 1)] - x_vals[0]));
    fit_params[8] = x_vals[0] + (0.95 * (x_vals[(NOvals - 1)] - x_vals[0]));
    
    // call busy function fitting routine
    k = FitBusyFunc(NOvals,x_vals,y_vals,n_vals,fit_params,fit_covar,vb_flag);
    
    // display BF fitting result
    std::cout << k << std::scientific << " ";
    for(i = 0; i < 17; i++){ std::cout << fit_params[i] << " "; }
    for(i = 0; i < 8; i++){
      for(j = 0; j < 8; j++){
	std::cout << fit_covar[i][j] << " ";
      }
    }
    std::cout << std::endl;

    // free up memory
    delete [] x_vals;
    delete [] y_vals;
    delete [] n_vals;
    delete [] fit_params;
    for(i = 0; i < 8; i++){ delete [] fit_covar[i]; }
    delete [] fit_covar;
    
    // if(infile.is_open())
  } else {

    std::cout << "ERROR!!! Couldn't open input file: " << infile_name << "\nExiting program . . . " << std::endl;
    
  }
  
  // int main(int argc, char* argv[])
}






