/*

This is version 1.0 of the C BusyFunc library that fits the Busy Function to data.
See Westmeier, Jurek, Obreschkow & Koribalski (2013) for more details about the implementation
and the Busy Function.

Created by Russell J. Jurek, 30th June 2013.
Email: Russell.Jurek@gmail.com

 */

#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<omp.h>
#include<time.h>

#ifndef _cBFfit_OMP_
#define _cBFfit_OMP_

// Chain of functions that carry out Busy Function fitting --- multiple versions for float and double typed data

void BusyFunc(double x, double a[], double *y, double dyda[], int fit_mode, double mid, double amp);

void FitBusyFunc_engine_flt(int NOvals, float * x_vals, float * y_vals, float * n_vals, double * model_params, int fit_mode, int NOs, double ** start_vals, double mid, double amp, double ** fit_covar, int vb_flag);

void FitBusyFunc_engine_dbl(int NOvals, double * x_vals, double * y_vals, double * n_vals, double * model_params, int fit_mode, int NOs, double ** start_vals, double mid, double amp, double ** fit_covar, int vb_flag);

int FitBusyFunc_flt(int NOvals, float * x_vals, float * y_vals, float * n_vals, float * fit_params, float ** fit_covar, int vb_flag);

int FitBusyFunc_dbl(int NOvals, double * x_vals, double * y_vals, double * n_vals, double * fit_params, double ** fit_covar, int vb_flag);

void covsrt(double **covar, int ma, int ia[], int mfit);

void mrqcof_flt(float x[], float y[], float sig[], int ndata, double a[], int ia[], int ma, double **alpha, double beta[], double *chisq, void (*funcs) (double, double [], double *, double [], int, double, double), int fit_mode, double mid, double amp);

void mrqcof_dbl(double x[], double y[], double sig[], int ndata, double a[], int ia[], int ma, double **alpha, double beta[], double *chisq, void (*funcs) (double, double [], double *, double [], int, double, double), int fit_mode, double mid, double amp);

int mrqmin_flt(float x[], float y[], float sig[], int ndata, double a[], int ia[], int ma, double **covar, double **alpha, double *chisq, void (*funcs)(double, double [], double *, double [], int, double, double), double *alamda, int fit_mode, double mid, double amp, int * mfit, double * ochisq, double * atry, double * beta, double * da, double ** oneda);

int mrqmin_dbl(double x[], double y[], double sig[], int ndata, double a[], int ia[], int ma, double **covar, double **alpha, double *chisq, void (*funcs)(double, double [], double *, double [], int, double, double), double *alamda, int fit_mode, double mid, double amp, int * mfit, double * ochisq, double * atry, double * beta, double * da, double ** oneda);

void svbksb(double **u, double w[], double **v, int m, int n, double b[], double x[]);

void svdcmp(double **a, int m, int n, double w[], double **v);
 
double ran2(long * idum);

double pythag(double a, double b);

#endif




