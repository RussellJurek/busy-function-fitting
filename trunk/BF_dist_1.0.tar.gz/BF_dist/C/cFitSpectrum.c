/*

This is version 1.0 of the demonstration program for the C BusyFunc library that fits the Busy 
Function to data. See Westmeier, Jurek, Obreschkow & Koribalski (2013) for more details about 
the implementation of this C library and the Busy Function.

Created by Russell J. Jurek, 30th June 2013.
Email: Russell.Jurek@gmail.com

 */

#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<cBFfit_OMP.h>

int main(int argc, char* argv[]){

  FILE * infile;
  char * infile_name, * dummy3;
  char dummy1[10000], dummy2[1000];
  int i,j,k,m,length,v,NOvals,vb_flag = -1, cols[3] = {0,1,-99};
  //float * x_vals, * y_vals, * n_vals, * fit_params, ** fit_covar;
  double * x_vals, * y_vals, * n_vals, * fit_params, ** fit_covar;
  
  // test if insufficient arguments were specified on the command line
  if((argc == 1) || (argc >= 7)){ printf("Incorrect number of arguments. Use `FitSpectrum -h' to view instructions."); return 0; }
  
  // get input file from the command line
  infile_name = argv[1];
  
  // display instructions if the first entry on the command line was -h or -H
  if((strcmp(infile_name,"-h") == 0) || (strcmp(infile_name,"-H") == 0)){ printf("Instructions for FitSpectrum: \n\nThis program uses the C++ Busy Function fitting library to fit the Busy Function to a single spectra. This program assumes that each line of the input file contains an x and y value, as well as an optional noise value for each (x,y). This program also assumes space delimited input files.\n\nUsage: FitSpectrum input_file [x_col] [y_col] [noise_col] [-v or -vv] \n       FitSpectrum -h\n\nThe input_file is the only mandatory input. All other inputs are optional, which is represented by []. The optional inputs are:\nx_col: The column containing the x values. Count from 0. Default is 0.\ny_col: The column containing the y values. Count from 0. Default is 1.\nnoise_col: The column containing the noise values. Default is -99, which assigns a value of 1 for every x.\n-v: Turn verbosity to medium (default is none).\n-vv: Turn verbosity to high (default is none).\n\nThe fitting results are written to the terminal. The first value is the dimensionality of the best fitting BF model. The next 16 values are the BF fit parameters and their uncertainties (listed in value, error pairs). The next value is chi^2. The remaining 64 values are the chi^2 covariance matrix.\nThe values are written out in scientific notation to accommodate especially large or small values.\n"); return 0; }
  
  // get input columns and -v/-vv from the command line --- if specified
  for(i = 2; ((i < argc) && (i < 6)); i++){
    
    dummy3 = argv[i];
    if((strcmp(dummy3,"-v") == 0) || (strcmp(dummy3,"-V") == 0)){
      vb_flag = 0;
      break;
    } else if((strcmp(dummy3,"-vv") == 0) || (strcmp(dummy3,"-VV") == 0) || (strcmp(dummy3,"-Vv") == 0) || (strcmp(dummy3,"-vV") == 0)){
      vb_flag = 1;
      break;
    } else {
      sscanf(dummy3,"%i",&cols[(i - 2)]);
    }
    
  }
  
  // display columns to be used
  if(vb_flag >= 0){ printf("Using x_col = %d, y_col = %d & noise_col = %d \n",cols[0],cols[1],cols[2]); }
  
  // open input file
  if(vb_flag >= 0){ printf("Opening input file: %s \n",infile_name); }
  infile = NULL;
  infile = fopen(infile_name,"r");
  
  // check that the input file is open
  if(infile != NULL){
    
    // create arrays used by BusyFunc
    //fit_params = malloc(sizeof(float) * 17);
    //fit_covar =  malloc(sizeof(float *) * 8);
    //for(i = 0; i < 8; i++){ fit_covar[i] = malloc(sizeof(float) * 8); }
    fit_params = malloc(sizeof(double) * 17);
    fit_covar =  malloc(sizeof(double *) * 8);
    for(i = 0; i < 8; i++){ fit_covar[i] = malloc(sizeof(double) * 8); }
    
    // count the number of entries in the input file
    NOvals = 0;
    while(fgets(dummy1,10000,infile) != NULL){
      
      j = strlen(dummy1);
      if(j < 1){ continue; }
      j = strspn(dummy1," \t");
      if((dummy1[j] == '#') || (dummy1[j] == '\0')){ continue; }
      NOvals++;
      
    }
    j = fseek(infile,0,SEEK_SET);
    if(vb_flag >= 0){ printf("%d entries in the source+noise catalogue.",NOvals); }
    
    // allocate memory to store input file
    //x_vals = malloc(sizeof(float) * NOvals);
    //y_vals = malloc(sizeof(float) * NOvals);
    //n_vals = malloc(sizeof(float) * NOvals);
    x_vals = malloc(sizeof(double) * NOvals);
    y_vals = malloc(sizeof(double) * NOvals);
    n_vals = malloc(sizeof(double) * NOvals);
    
    // read input file into memory
    if(vb_flag >= 0){ printf("Reading source+noise objects into arrays . . . \n"); }
    v = 0;
    while((fgets(dummy1,10000,infile) != NULL) && (v < NOvals)){
      
      j = strlen(dummy1);
      if(j < 1){ continue; }
      j = strspn(dummy1," \t");
      if((dummy1[j] == '#') || (dummy1[j] == '\0')){ continue; }
      
      m = 0;
      i = 0;
      while(i > -1){
	j = m+(strspn((dummy1+m)," \t")); 
	if(dummy1[j] == '\0'){ i = -99; continue; }  
	k = j+1+(strcspn((dummy1+j+1)," \t"));
	if(k >= strlen(dummy1)){ k = strlen(dummy1) - 1; }
	m = k + 1;
	length = k - j;
	strcpy(dummy2,"");
	strncpy(dummy2,(dummy1+j),length);
	strcpy(&dummy2[length],"\0");
	
	//if(i == cols[0]){ sscanf(dummy2,"%f",&x_vals[v]); }
	//if(i == cols[1]){ sscanf(dummy2,"%f",&y_vals[v]); }
	//if(i == cols[2]){ sscanf(dummy2,"%f",&n_vals[v]); }
	if(i == cols[0]){ sscanf(dummy2,"%lf",&x_vals[v]); }
	if(i == cols[1]){ sscanf(dummy2,"%lf",&y_vals[v]); }
	if(i == cols[2]){ sscanf(dummy2,"%lf",&n_vals[v]); }
	
	// increment column index
	i++;
	
	// close while loop that loads data into variables
      }      
      
      // specify constant noise = 1.0 if cols[2] < 0
      if(cols[2] < 0){ n_vals[v] = 1.0; }
      
      // increment array index
      v++;
      
      // close while loop loading infile into arrays
    }
    if(vb_flag >= 0){ printf("done.\n"); }
    
    // close input file
    fclose(infile);
    
    // specify initial roll-off range
    fit_params[4] = x_vals[0] + (0.05 * (x_vals[(NOvals - 1)] - x_vals[0]));
    fit_params[8] = x_vals[0] + (0.95 * (x_vals[(NOvals - 1)] - x_vals[0]));
    
    // call busy function fitting routine
    //k = FitBusyFunc_flt(NOvals,x_vals,y_vals,n_vals,fit_params,fit_covar,vb_flag);
    k = FitBusyFunc_dbl(NOvals,x_vals,y_vals,n_vals,fit_params,fit_covar,vb_flag);
    
    // display BF fitting result
    printf("%d ",k);
    for(i = 0; i < 17; i++){ printf("%e ",fit_params[i]); }
    for(i = 0; i < 8; i++){
      for(j = 0; j < 8; j++){
	printf("%e ",fit_covar[i][j]);
      }
    }
    printf("\n");
    
    // free up memory
    free(x_vals);
    free(y_vals);
    free(n_vals);
    free(fit_params);
    for(i = 0; i < 8; i++){ free(fit_covar[i]); }
    free(fit_covar);
    
    // if(infile != NULL)
  } else {
    
    printf("ERROR!!! Couldn't open input file: %s \n",infile_name);
    
  }
  
  return 1;

  // int main(int argc, char* argv[])
}






