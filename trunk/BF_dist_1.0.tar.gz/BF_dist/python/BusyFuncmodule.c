/*

This is version 1.0 of the wrapper for the C BusyFunc library that fits the Busy Function to data.
See Westmeier, Jurek, Obreschkow & Koribalski (2013) for more details about the implementation
and the Busy Function.

Created by Russell J. Jurek, 30th June 2013.
Email: Russell.Jurek@gmail.com

*/

#include<Python.h>
#include<cBFfit_OMP.h>

// wrapper function called from Python
static PyObject *
BusyFunc_fit(PyObject *self, PyObject *args){

  int FitBusyFunc_dbl(int NOvals, double * x_vals, double * y_vals, double * n_vals, double * fit_params, double ** fit_covar, int vb_flag);
  int i, j, dims, NOvals, vb_flag;
  double * x_vals, * y_vals, * n_vals, x_min, x_max;
  double * fit_params, ** fit_covar;
  double return_fit_params[17], return_fit_covar[8][8];

  // define Python objects
  PyObject * py_x_vals, * py_y_vals, * py_n_vals, * py_fit_params, * py_fit_covar;

  // parse Python tuple object into a mixture of python list objects and C variables
  if(!(PyArg_ParseTuple(args,"OOOidd",&py_x_vals,&py_y_vals,&py_n_vals,&vb_flag,&x_min,&x_max))){ 
    
    printf("Failed to successfully parse python inputs to BusyFunc.fit(). Exiting . . . \n"); 
    return NULL; 
  
  }

  // check that the python objects are all lists
  if(!(PyList_Check(py_x_vals))){ 
    
    printf("ERROR: Argument 1 is not a list. Exiting . . . \n"); 
    PyErr_SetString(PyExc_TypeError,"Argument 1 is not a list.");
    return NULL; 

  }
  if(!(PyList_Check(py_y_vals))){ 

    printf("ERROR: Argument 2 is not a list. Exiting . . . \n"); 
    PyErr_SetString(PyExc_TypeError,"Argument 2 is not a list.");
    return NULL; 

  }
  if(!(PyList_Check(py_n_vals))){ 

    printf("ERROR: Argument 3 is not a list. Exiting . . . \n"); 
    PyErr_SetString(PyExc_TypeError,"Argument 3 is not a list.");
    return NULL; 

  }

  // create the C arrays passed to the cBFfit_OMP library
  NOvals = (int) PyList_Size(py_x_vals);
  if((int) PyList_Size(py_y_vals) < NOvals){ NOvals = (int) PyList_Size(py_y_vals); }
  if((int) PyList_Size(py_n_vals) < NOvals){ NOvals = (int) PyList_Size(py_n_vals); }
  if(NOvals < 2){

    // set an exception if NOvals < 2
    printf("ERROR: NOvals (= %d) is too small. Exiting . . . \n",NOvals);
    PyErr_SetString(PyExc_TypeError,"Less than 2 elements in the smallest input list.");
    return NULL;

  }
  x_vals = malloc(NOvals * sizeof(double));
  y_vals = malloc(NOvals * sizeof(double));
  n_vals = malloc(NOvals * sizeof(double));
  fit_params = malloc(17 * sizeof(double));
  for(i = 0; i < 17; i++){ fit_params[i] = 0.0; }
  fit_params[4] = x_min;
  fit_params[8] = x_max;
  fit_covar = malloc(8 * sizeof(double *));
  for(j = 0; j < 8; j++){ 
    
    fit_covar[j] = malloc(8 * sizeof(double)); 
    for(i = 0; i < 8; i++){ fit_covar[j][i] = 0.0; }

  }

  // copy the Python input values into the C arrays
  for(i = 0; i < NOvals; i++){
    
    x_vals[i] = PyFloat_AsDouble(PyList_GetItem(py_x_vals,(Py_ssize_t) i));
    y_vals[i] = PyFloat_AsDouble(PyList_GetItem(py_y_vals,(Py_ssize_t) i));
    n_vals[i] = PyFloat_AsDouble(PyList_GetItem(py_n_vals,(Py_ssize_t) i));
    
  }

  // call C busy function --- double precision version;
  //                          the module could be recompiled to use floats and call FitBusyFunc_flt
  //                          for a *slight* improvement in speed
  dims = FitBusyFunc_dbl(NOvals,x_vals,y_vals,n_vals,fit_params,fit_covar,vb_flag);
  
  // copy fitting results into Python objects
  for(i = 0; i < 17; i++){ return_fit_params[i] = fit_params[i]; }
  for(j = 0; j < 8; j++){ 
    for(i = 0; i < 8; i++){
      return_fit_covar[j][i] = fit_covar[j][i];
    }
  }
  
  // free up C arrays
  free(x_vals);
  free(y_vals);
  free(n_vals);
  free(fit_params);
  for(i = 0; i < 8; i++){ free(fit_covar[i]); }
  free(fit_covar);

  // return a Python tuple containing the results
  return Py_BuildValue("i[ddddddddddddddddd][dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd]",dims,return_fit_params[0],return_fit_params[1],return_fit_params[2],return_fit_params[3],return_fit_params[4],return_fit_params[5],return_fit_params[6],return_fit_params[7],return_fit_params[8],return_fit_params[9],return_fit_params[10],return_fit_params[11],return_fit_params[12],return_fit_params[13],return_fit_params[14],return_fit_params[15],return_fit_params[16],return_fit_covar[0][0],return_fit_covar[0][1],return_fit_covar[0][2],return_fit_covar[0][3],return_fit_covar[0][4],return_fit_covar[0][5],return_fit_covar[0][6],return_fit_covar[0][7],return_fit_covar[1][0],return_fit_covar[1][1],return_fit_covar[1][2],return_fit_covar[1][3],return_fit_covar[1][4],return_fit_covar[1][5],return_fit_covar[1][6],return_fit_covar[1][7],return_fit_covar[2][0],return_fit_covar[2][1],return_fit_covar[2][2],return_fit_covar[2][3],return_fit_covar[2][4],return_fit_covar[2][5],return_fit_covar[2][6],return_fit_covar[2][7],return_fit_covar[3][0],return_fit_covar[3][1],return_fit_covar[3][2],return_fit_covar[3][3],return_fit_covar[3][4],return_fit_covar[3][5],return_fit_covar[3][6],return_fit_covar[3][7],return_fit_covar[4][0],return_fit_covar[4][1],return_fit_covar[4][2],return_fit_covar[4][3],return_fit_covar[4][4],return_fit_covar[4][5],return_fit_covar[4][6],return_fit_covar[4][7],return_fit_covar[5][0],return_fit_covar[5][1],return_fit_covar[5][2],return_fit_covar[5][3],return_fit_covar[5][4],return_fit_covar[5][5],return_fit_covar[5][6],return_fit_covar[5][7],return_fit_covar[6][0],return_fit_covar[6][1],return_fit_covar[6][2],return_fit_covar[6][3],return_fit_covar[6][4],return_fit_covar[6][5],return_fit_covar[6][6],return_fit_covar[6][7],return_fit_covar[7][0],return_fit_covar[7][1],return_fit_covar[7][2],return_fit_covar[7][3],return_fit_covar[7][4],return_fit_covar[7][5],return_fit_covar[7][6],return_fit_covar[7][7]);

}

// method table and initialisation function
static PyMethodDef BFmethods[] = {

  {"fit", BusyFunc_fit, METH_VARARGS, "Fit the Busy Function to arrays of x, y and y-error values. \n\nThis package fits the Busy Function (see Westmeier, Jurek, Obreschkow & Koribalski 2013) to user supplied data. This package uses the implementation described in Westemeier et al. (2013). Please cite this paper in any published works that utilise this package. \n\nThis package fits the following forumulation of the Busy Function,\n\ny(x) = 0.25 * alpha * {1 + erf[beta_1 * (x - gamma_1)]} * {1 + erf[beta_2 * (gamma_2 - x)]} * {1 + phi * [x - theta]^N},\n\nwhere the following constraints are applied using variable re-mapping: alpha >= 0.0, beta_1 >= 0.0, beta_2 >= 0.0, phi >= 0.0, 2 <= N <= 8, x_min <= gamma_1 <= x_max, x_min <= gamma_2 <= x_max and x_min <= theta <= x_max. Note that the beta_1 and beta_2 constraints implicitly imposes a weak constraint, gamma_1 (almost always) <= gamma_2. \n\nUsage: (dims,fit_params,fit_covar) = BusyFunc.fit(x_vals,y_vals,y_err_vals,verbose_flag,x_min,x_max) \n\nInput: \nThis package takes six arguments. The first three are lists containing the x values, y values and errors in the y values. A list of \"1\"s should be used when you don\'t have/want to use uncertainties in the y values. Alternatively, spuriously large uncertainties can be assigned to y values that you want the fitting program to ignore eg. channels dominated by RFI in integrated HI spectra.\n\nThe verbose_flag specifies the amount of diagnostic output displayed on the terminal. Values of -1, 0 and 1 generate none, minimal, and maximal diagnostic output.\n\nThe x_min and x_max values specifies the region within the data believed to contain signal. This can be set to x_vals[0] and x_vals[len(x_vals) - 1] without causing any problems. If you know that the first 10 and last 20 values are noise however, setting x_min and x_max accordingly will improve your fitting results. Output:\nThis package returns a 3-tuple containg an integer and two lists. The first tuple value is an integer value. It is the dimensionality of the Busy Function fit. Possible values are 4 through 8. The second tuple is a list. This list contains 17 float values. The first 16 are the Busy Function fit values and their uncertainties. The final value is the chi-squared value of the Busy Function fit. The second list is 64 float values. This second list contains the covariance matrix of the Busy Function fit. The covariance matrix can be used to check for degeneracies in the Busy Function fit.\n\nOutput structure:\n\n fit_params = \n(alpha, alpha error,\nbeta_1, beta_1 error,\ngamma_1, gamma_1 error,\nbeta_2, beta_2 error,\ngamma_2, gamma_2 error\nphi, phi error,\ntheta, theta error,\nN, N error)\n\nfit_covar = \n(alpha x alpha, alpha x beta_1, alpha x gamma_1, alpha x beta_2, alpha x gamma_2, alpha x phi, alpha x theta, alpha x N\nbeta_1 x alpha, beta_1 x beta_1, beta_1 x gamma_1, beta_1 x beta_2, beta_1 x gamma_2, beta_1 x phi, beta_1 x theta, beta_1 x N\ngamma_1 x alpha, gamma_1 x beta_1, gamma_1 x gamma_1, gamma_1 x beta_2, gamma_1 x gamma_2, gamma_1 x phi, gamma_1 x theta, gamma_1 x N\nbeta_2 x alpha, beta_2 x beta_1, beta_2 x gamma_1, beta_2 x beta_2, beta_2 x gamma_2, beta_2 x phi, beta_2 x theta, beta_2 x N\ngamma_2 x alpha, gamma_2 x beta_1, gamma_2 x gamma_1, gamma_2 x beta_2, gamma_2 x gamma_2, gamma_2 x phi, gamma_2 x theta, gamma_2 x N\nphi x alpha, phi x beta_1, phi x gamma_1, phi x beta_2, phi x gamma_2, phi x phi, phi x theta, phi x N\ntheta x alpha, theta x beta_1, theta x gamma_1, theta x beta_2, theta x gamma_2, theta x phi, theta x theta, theta x N\nN x alpha, N x beta_1, N x gamma_1, N x beta_2, N x gamma_2, N x phi, N x theta, N x N)\n\n"},
  {NULL,NULL,0,NULL} /* sentinel */

};

// define module initialisation function, which loads method table
PyMODINIT_FUNC
initBusyFunc(void)
{
  (void) Py_InitModule("BusyFunc", BFmethods);
}








