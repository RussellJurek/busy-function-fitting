/*

This is a demonstration program for  version 1.2 of the C++ BusyFunc library that fits the 
Busy Function to data. See Westmeier, Jurek, Obreschkow & Koribalski (2013) for more details 
about the implementation of this library and the Busy Function.

Created by Russell J. Jurek, 27th December 2013.
Email: Russell.Jurek@gmail.com

 */

#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<BFfit_OMP.h>
#include<iomanip>

int main(int argc, char* argv[]){

  std::fstream infile;
  std::string dummy1, infile_name;
  std::stringstream dummy2;
  int i,j,k,m,length,v,NOvals,fit_type,vb_flag = -1, cols[3] = {0,1,-99}, NOr = 10000, NOs = 1000, iter_max = 30, refine_iter = 3000;
  //float * x_vals, * y_vals, * n_vals, * fit_params, ** fit_covar, fit_x_min, fit_x_max, ** rand_fits, ** rand_obs_vals, ** obs_stats, ** obs_covar;
  double * x_vals, * y_vals, * n_vals, * fit_params, ** fit_covar, fit_x_min, fit_x_max, ** rand_fits, ** rand_obs_vals, ** obs_stats, ** obs_covar;

  // test if insufficient arguments were specified on the command line
  if((argc == 1) || (argc >= 12)){ std::cout << "Incorrect number of arguments. Use `FitSpectrum -h' to view instructions." << std::endl; return 0; }

  // get input file from the command line
  dummy2.str("");
  dummy2.clear();
  dummy2 << argv[1];
  dummy1 = "";
  dummy2 >> infile_name;

  // display instructions if the first entry on the command line was -h or -H
  if((infile_name == "-h") || (infile_name == "-H")){ std::cout << "Instructions for FitSpectrum: \n\nThis program uses the C++ Busy Function fitting library to fit the Busy Function to a single spectra. This program assumes that each line of the input file contains an x and y value, as well as an optional noise value for each (x,y). This program also assumes space delimited input files.\n\nUsage: FitSpectrum input_file [x_col] [y_col] [noise_col] [-v or -vv] [-s NOs iter_max] [-r refine_iter] \n       FitSpectrum -h\n\nThe input_file is the only mandatory input. All other inputs are optional, which is represented by []. The optional inputs are:\nx_col: The column containing the x values. Count from 0. Default is 0.\ny_col: The column containing the y values. Count from 0. Default is 1.\nnoise_col: The column containing the noise values. Default is -99, which assigns a value of 1 for every x.\n-v: Turn verbosity to medium (default is none).\n-vv: Turn verbosity to high (default is none).\n-s NOs iter_max: These 3 values specify a non-default number of LVM seeds and LVM iterations per seed (defaults are 1000 and 30).\n-r refine_iter: These 2 values specify the number of iterations to use to refine the best fit by re-fitting (default is 3000).\n\nThe fitting results are written to the terminal. The first value is the dimensionality of the best fitting BF model. The next 16 values are the BF fit parameters and their uncertainties (listed in value, error pairs). The next value is chi^2. The remaining 64 values are the chi^2 covariance matrix.\nThe values are written out in scientific notation to accommodate especially large or small values.\n" << std::endl; return 0; }

  // process command line arguments
  j = 0;
  for(i = 2; ((i < argc) && (i < 11)); i++){

    dummy2.str("");
    dummy2.clear();
    dummy2 << argv[i];
    dummy1 = "";
    dummy2 >> dummy1;
    
    // process a verbose flag
    if((dummy1 == "-v") || (dummy1 == "-V")){ 
      vb_flag = 0; 
      continue;
    } 
    if((dummy1 == "-vv") || (dummy1 == "-VV") || (dummy1 == "-Vv") || (dummy1 == "-vV")){ 
      vb_flag = 1; 
      continue;
    }

    // process a LVM seed number and iteration maximum specification
    if((dummy1 == "-s") || (dummy1 == "-S")){
      dummy2.str("");
      dummy2.clear();
      dummy2 << argv[(i + 1)];
      dummy2 >> NOs;
      dummy2.str("");
      dummy2.clear();
      dummy2 << argv[(i + 2)];
      dummy2 >> iter_max;
      i+=2;
      continue;
    }

    // process a refinement iteration specification
    if((dummy1 == "-r") || (dummy1 == "-R")){
      dummy2.str("");
      dummy2.clear();
      dummy2 << argv[(i + 1)];
      dummy2 >> refine_iter;
      i++;
      continue;
    }

    // process a column number
    dummy2.str("");
    dummy2.clear();
    dummy2 << dummy1;
    dummy2 >> cols[j];
    j++;

  }
  if(refine_iter < iter_max){ refine_iter = iter_max; }

  // display columns to be used
  if(vb_flag >= 0){ std::cout << "Using x_col = " << cols[0] << ", y_col = " << cols[1] << " & noise_col = " << cols[2] << std::endl; }

  // display seeds and iterations
  if(vb_flag >= 0){ std::cout << "Using " << NOs << " LVM seeds, with a maximum of " << iter_max << " iterations per seed. Refining fit with " << refine_iter << " iterations." << std::endl; }

  // open input file
  if(vb_flag >= 0){ std::cout << "Opening input file: " << infile_name << std::endl; }
  infile.open(infile_name.c_str(),std::ios::in);

  // check that the input file is open
  if(infile.is_open()){

    // create arrays used by BusyFunc fitting routines
    // use float data
    /*fit_params = new float[17];
    fit_covar =  new float * [8];
    for(i = 0; i < 8; i++){ 
      fit_covar[i] = new float[8]; 
    }
    rand_fits = new float * [NOr];
    rand_obs_vals = new float * [NOr];
    for(i = 0; i < NOr; i++){ 
      rand_obs_vals[i] = new float[7]; 
      rand_fits[i] = new float[8];
    }
    obs_stats = new float * [7];
    for(i = 0; i < 7; i++){ obs_stats[i] = new float[8]; }
    obs_covar = new float * [7];
    for(i = 0; i < 7; i++){ obs_covar[i] = new float[7]; }*/
    // use double data
    fit_params = new double[17];
    fit_covar =  new double * [8];
    for(i = 0; i < 8; i++){ 
      fit_covar[i] = new double[8]; 
    }
    rand_fits = new double * [NOr];
    rand_obs_vals = new double * [NOr];
    for(i = 0; i < NOr; i++){ 
      rand_obs_vals[i] = new double[7]; 
      rand_fits[i] = new double[8];
    }
    obs_stats = new double * [7];
    for(i = 0; i < 7; i++){ obs_stats[i] = new double[8]; }
    obs_covar = new double * [7];
    for(i = 0; i < 7; i++){ obs_covar[i] = new double[7]; }

    // count the number of entries in the input file
    NOvals = 0;
    while(!(infile.eof())){
      
      dummy1 = "";
      getline(infile,dummy1);
      if ((dummy1 != "") && (dummy1.find("#",0) == std::string::npos)){ NOvals++;  }
      
    }
    infile.clear();
    infile.seekg(0,std::ios::beg);
    if(vb_flag >= 0){ std::cout << NOvals << " entries in the source+noise catalogue." << std::endl; }
    
    // allocate memory to store input file
    // use float data
    /*x_vals = new float[NOvals];
    y_vals = new float[NOvals];
    n_vals = new float[NOvals];*/
    // use double data
    x_vals = new double[NOvals];
    y_vals = new double[NOvals];
    n_vals = new double[NOvals];
    
    // read input file into memory
    if(vb_flag >= 0){ std::cout << "Reading source+noise objects into arrays . . . " << std::endl; }
    v = 0;
    while((!(infile.eof())) && (v < NOvals)){
      dummy1 = "";
      getline(infile,dummy1);
      if ((dummy1.find("#",0) != std::string::npos) || (dummy1 == "")){ continue; }
      m = 0;
      i = 0;
      while(i > -1){
	j = dummy1.find_first_not_of(" ",m);
	if (j == (int) std::string::npos) { i = -99; continue; }
	k = dummy1.find_first_of(" ",j+1);
	if (k == (int) std::string::npos) { k = dummy1.length(); }
	m = k + 1;
	length = k - j;
	dummy2.str("");
	dummy2.clear();
	dummy2.str(dummy1.substr(j,length));
	if(i == cols[0]){ dummy2 >> x_vals[v]; }
	if(i == cols[1]){ dummy2 >> y_vals[v]; }
	if(i == cols[2]){ dummy2 >> n_vals[v]; }
	
	// increment column index
	i++;
	
	// close while loop that loads data into variables
      }      
      
      // specify constant noise = 1.0 if cols[2] < 0
      if(cols[2] < 0){ n_vals[v] = 1.0; }
      
      // increment array index
      v++;
      
      // close while loop loading infile into arrays
    }
    if(vb_flag >= 0){ std::cout << "done." << std::endl; }
    
    // close input file
    infile.close();
    
    // specify initial roll-off range
    fit_x_min = fit_params[4] = x_vals[0] + (0.05 * (x_vals[(NOvals - 1)] - x_vals[0]));
    fit_x_max = fit_params[8] = x_vals[0] + (0.95 * (x_vals[(NOvals - 1)] - x_vals[0]));
    
    // call busy function fitting routine
    fit_type = FitBusyFunc(NOvals,x_vals,y_vals,n_vals,fit_params,fit_covar,k,NOs,iter_max,vb_flag);
    
    // refine BF fit - call busy function fitting routine with NOs = -1
    fit_type = FitBusyFunc(NOvals,x_vals,y_vals,n_vals,fit_params,fit_covar,k,-1,refine_iter,vb_flag);

    // display BF fitting result
    std::cout << "BF fit . . . " << std::endl;
    std::cout << k << std::scientific << " ";
    for(i = 0; i < 17; i++){ std::cout << fit_params[i] << " "; }
    for(i = 0; i < 8; i++){
      for(j = 0; j < 8; j++){
	std::cout << fit_covar[i][j] << " ";
      }
    }
    std::cout << std::fixed << std::endl;

    // call functions that generate N random BF fit variants, calculates observational parameters for them
    // and measures basic statistical properties 
    CreateRandFits(NOr,rand_fits,fit_type,fit_params,fit_covar,fit_x_min,fit_x_max,vb_flag);
    CalcObsParams(NOr,rand_fits,NOvals,x_vals,rand_obs_vals,vb_flag);
    AnalyseObsVals(NOr,7,rand_obs_vals,obs_stats,vb_flag);

    // display statistical properties of observational parameters
    std::cout << std::scientific;
    for(j = 0; j < 7; j++){
      switch (j) {
      case 0:
	std::cout << "Total intensity --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis " << std::endl;
	break;
      case 1:
	std::cout << "Peak intensity --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis " << std::endl;
	break;	
      case 2:
	std::cout << "Peak intensity position --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis  " << std::endl;
	break;
      case 3:
	std::cout << "W_50 width --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis  " << std::endl;
	break;
      case 4:
	std::cout << "W_50 position --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis  " << std::endl;
	break;
      case 5:
	std::cout << "W_20 width --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis  " << std::endl;
	break;
      case 6:
	std::cout << "W_20 position --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis  " << std::endl;
	break;
      default:
	break;
      }
      for(i = 0; i < 8; i++){
	std::cout << obs_stats[j][i] << " " << std::flush;
      }
      std::cout << std::endl;
    }
    std::cout << std::fixed;

    // calculate and display observational parameter covariance
    ApproxObsCovar(fit_type,NOvals,x_vals,fit_params,fit_covar,obs_covar,fit_x_min,fit_x_max);
    std::cout << "Observational parameter covariance matrix . . . " << std::endl;
    for(j = 0; j < 7; j++){
      for(i = 0; i < 7; i++){
	std::cout << obs_covar[j][i] << " ";
      }
      std::cout << std::endl;
    }
    std::cout << "Resultant errors . . . " << std::endl;
    for(i = 0; i < 7; i++){ std::cout << sqrtf(obs_covar[i][i]) << " "; }
    std::cout << std::endl;

    // free up memory
    delete [] x_vals;
    delete [] y_vals;
    delete [] n_vals;
    delete [] fit_params;
    for(i = 0; i < 8; i++){ delete [] fit_covar[i]; }
    delete [] fit_covar;
    for(i = 0; i < NOr; i++){ 
      delete [] rand_fits[i];
      delete [] rand_obs_vals[i];
    }
    delete [] rand_fits;
    delete [] rand_obs_vals;
    for(i = 0; i < 7; i++){ 
      delete [] obs_stats[i]; 
      delete [] obs_covar[i];
    }
    delete [] obs_stats;
    delete [] obs_covar;

    // if(infile.is_open())
  } else {

    std::cout << "ERROR!!! Couldn't open input file: " << infile_name << "\nExiting program . . . " << std::endl;
    
  }
  
  // int main(int argc, char* argv[])
}






