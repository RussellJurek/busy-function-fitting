#include<Python.h>
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<omp.h>
#include<time.h>

#define IM1 2147483563
#define IM2 2147483399
#define AM (1.0/IM1)
#define IMM1 (IM1-1)
#define IA1 40014
#define IA2 40692
#define IQ1 53668
#define IQ2 52774
#define IR1 12211
#define IR2 3791
#define NTAB 32
#define NDIV (1+IMM1/NTAB)
#define EPS 1.2e-307
#define RNMX (1.0-EPS)

static float sqrarg;
#define SQR(a) ((sqrarg=(a)) == 0.0 ? 0.0 : sqrarg*sqrarg)
static float minarg1,minarg2;
#define FMIN(a,b) (minarg1=(a),minarg2=(b),(minarg1) < (minarg2) ? (minarg1) : (minarg2))
static float maxarg1,maxarg2;
#define FMAX(a,b) (maxarg1=(a),maxarg2=(b),(maxarg1) > (maxarg2) ? (minarg1) : (minarg2))
static int iminarg1,iminarg2;
#define IMIN(a,b) (iminarg1=(a),iminarg2=(b),(iminarg1) < (iminarg2) ? (iminarg1) : (iminarg2))
static int imaxarg1,imaxarg2;
#define IMAX(a,b) (imaxarg1=(a),imaxarg2=(b),(imaxarg1) > (imaxarg2) ? (imaxarg1) : (imaxarg2))
#define SIGN(a,b) ((b) >= 0.0 ? fabs(a) : -fabs(a))
#define SWAP(a,b) {temp=(a);(a)=(b);(b)=temp;};
#define TINY 1.0e-20;

void BusyFunc(double x, double a[], double *y, double dyda[], int fit_mode, double mid, double amp);

void FitBusyFunc_engine_flt(int NOvals, float * x_vals, float * y_vals, float * n_vals, double * model_params, int fit_mode, int NOs, double ** start_vals, double mid, double amp, double ** fit_covar, int vb_flag);

void FitBusyFunc_engine_dbl(int NOvals, double * x_vals, double * y_vals, double * n_vals, double * model_params, int fit_mode, int NOs, double ** start_vals, double mid, double amp, double ** fit_covar, int vb_flag);

int FitBusyFunc_flt(int NOvals, float * x_vals, float * y_vals, float * n_vals, float * fit_params, float ** fit_covar, int vb_flag);

int FitBusyFunc_dbl(int NOvals, double * x_vals, double * y_vals, double * n_vals, double * fit_params, double ** fit_covar, int vb_flag);

void covsrt(double **covar, int ma, int ia[], int mfit);

void mrqcof_flt(float x[], float y[], float sig[], int ndata, double a[], int ia[], int ma, double **alpha, double beta[], double *chisq, void (*funcs) (double, double [], double *, double [], int, double, double), int fit_mode, double mid, double amp);

void mrqcof_dbl(double x[], double y[], double sig[], int ndata, double a[], int ia[], int ma, double **alpha, double beta[], double *chisq, void (*funcs) (double, double [], double *, double [], int, double, double), int fit_mode, double mid, double amp);

int mrqmin_flt(float x[], float y[], float sig[], int ndata, double a[], int ia[], int ma, double **covar, double **alpha, double *chisq, void (*funcs)(double, double [], double *, double [], int, double, double), double *alamda, int fit_mode, double mid, double amp, int * mfit, double * ochisq, double * atry, double * beta, double * da, double ** oneda);

int mrqmin_dbl(double x[], double y[], double sig[], int ndata, double a[], int ia[], int ma, double **covar, double **alpha, double *chisq, void (*funcs)(double, double [], double *, double [], int, double, double), double *alamda, int fit_mode, double mid, double amp, int * mfit, double * ochisq, double * atry, double * beta, double * da, double ** oneda);

void svbksb(double **u, double w[], double **v, int m, int n, double b[], double x[]);

void svdcmp(double **a, int m, int n, double w[], double **v);
 
double ran2(long * idum);

double pythag(double a, double b);





