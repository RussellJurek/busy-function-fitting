/*

This is version 1.2 of the demonstration program for the C BusyFunc library that fits the Busy 
Function to data. See Westmeier, Jurek, Obreschkow & Koribalski (2013) for more details about 
the implementation of this C library and the Busy Function.

Created by Russell J. Jurek, 27th December 2013.
Email: Russell.Jurek@gmail.com

 */

#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<cBFfit_OMP.h>

int main(int argc, char* argv[]){

  FILE * infile;
  char * infile_name, * dummy3;
  char dummy1[10000], dummy2[1000];
  int i,j,k,m,length,v,NOvals,vb_flag = -1, fit_type, cols[3] = {0,1,-99}, NOr = 10000, NOs = 1000, iter_max = 30, refine_iter = 3000;
  //float * x_vals, * y_vals, * n_vals, * fit_params, ** fit_covar, fit_x_min, fit_x_max, ** rand_fits, ** rand_obs_vals, ** obs_stats, ** obs_covar;
  double * x_vals, * y_vals, * n_vals, * fit_params, ** fit_covar, fit_x_min, fit_x_max, ** rand_fits, ** rand_obs_vals, ** obs_stats, ** obs_covar;
  
  // test if insufficient arguments were specified on the command line
  if((argc == 1) || (argc >= 7)){ printf("Incorrect number of arguments. Use `FitSpectrum -h' to view instructions."); return 0; }
  
  // get input file from the command line
  infile_name = argv[1];
  
  // display instructions if the first entry on the command line was -h or -H
  if((strcmp(infile_name,"-h") == 0) || (strcmp(infile_name,"-H") == 0)){ printf("Instructions for FitSpectrum: \n\nThis program uses the C++ Busy Function fitting library to fit the Busy Function to a single spectra. This program assumes that each line of the input file contains an x and y value, as well as an optional noise value for each (x,y). This program also assumes space delimited input files.\n\nUsage: FitSpectrum input_file [x_col] [y_col] [noise_col] [-v or -vv] [-s NOs iter_max] [-r refine_iter] \n       FitSpectrum -h\n\nThe input_file is the only mandatory input. All other inputs are optional, which is represented by []. The optional inputs are:\nx_col: The column containing the x values. Count from 0. Default is 0.\ny_col: The column containing the y values. Count from 0. Default is 1.\nnoise_col: The column containing the noise values. Default is -99, which assigns a value of 1 for every x.\n-v: Turn verbosity to medium (default is none).\n-vv: Turn verbosity to high (default is none).\n-s NOs iter_max: These 3 values specify a non-default number of LVM seeds and LVM iterations per seed (defaults are 1000 and 30).\n-r refine_iter: These 2 values specify the number of iterations to use to refine the best fit by re-fitting (default is 3000).\n\nThe fitting results are written to the terminal. The first value is the dimensionality of the best fitting BF model. The next 16 values are the BF fit parameters and their uncertainties (listed in value, error pairs). The next value is chi^2. The remaining 64 values are the chi^2 covariance matrix.\nThe values are written out in scientific notation to accommodate especially large or small values.\n"); return 0; }
 
  // process command line arguments
  j = 0;
  for(i = 2; ((i < argc) && (i < 11)); i++){

    dummy3 = argv[i];
    
    // process a verbose flag
    if((strcmp(dummy3,"-v") == 0) || (strcmp(dummy3,"-V") == 0)){ 
      vb_flag = 0; 
      continue;
    } 
    if((strcmp(dummy3,"-vv") == 0) || (strcmp(dummy3,"-VV") == 0) || (strcmp(dummy3,"-Vv") == 0) || (strcmp(dummy3,"-vV") == 0)){ 
      vb_flag = 1; 
      continue;
    }

    // process a LVM seed number and iteration maximum specification
    if((strcmp(dummy3,"-s") == 0) || (strcmp(dummy3,"-S") == 0)){
      sscanf(argv[(i + 1)],"%i",&NOs);
      sscanf(argv[(i + 2)],"%i",&iter_max);
      i+=2;
      continue;
    }

    // process a refinement iteration specification
    if((strcmp(dummy3,"-r") == 0) || (strcmp(dummy3,"-R") == 0)){
      sscanf(argv[(i + 1)],"%i",&refine_iter);
      i++;
      continue;
    }

    // process a column number
    sscanf(argv[i],"%i",&cols[j]);
    j++;

  }
  if(refine_iter < iter_max){ refine_iter = iter_max; }  

  // display columns to be used
  if(vb_flag >= 0){ printf("Using x_col = %d, y_col = %d & noise_col = %d \n",cols[0],cols[1],cols[2]); }
  
  // display seeds and iterations
  if(vb_flag >= 0){ printf("Using %i LVM seeds, with a maximum of %i iterations per seed. Refining fit with %i iterations.\n",NOs,iter_max,refine_iter); }

  // open input file
  if(vb_flag >= 0){ printf("Opening input file: %s \n",infile_name); }
  infile = NULL;
  infile = fopen(infile_name,"r");
  
  // check that the input file is open
  if(infile != NULL){
    
    // create arrays used by BusyFunc
    //
    // float versions 
    //fit_params = malloc(sizeof(float) * 17);
    //fit_covar =  malloc(sizeof(float *) * 8);
    //rand_fits = malloc(sizeof(float *) * NOr);
    //for(i = 0; i < 8; i++){ fit_covar[i] = malloc(sizeof(float) * 8); }
    //rand_obs_vals = malloc(sizeof(float *) * NOr);
    //for(i = 0; i < NOr; i++){ 
    //  rand_obs_vals[i] = malloc(sizeof(float) * 7); 
    //  rand_fits[i] = malloc(sizeof(float) * 8);
    //}
    //obs_stats = malloc(sizeof(float *) * 7);
    //for(i = 0; i < 7; i++){ obs_stats[i] = malloc(sizeof(float) * 8); }
    //
    // double versions
    fit_params = malloc(sizeof(double) * 17);
    fit_covar =  malloc(sizeof(double *) * 8);
    rand_fits = malloc(sizeof(double *) * NOr);
    for(i = 0; i < 8; i++){ fit_covar[i] = malloc(sizeof(double) * 8); }
    rand_obs_vals = malloc(sizeof(double *) * NOr);
    for(i = 0; i < NOr; i++){ 
      rand_obs_vals[i] = malloc(sizeof(double) * 7); 
      rand_fits[i] = malloc(sizeof(double) * 8);
    }
    obs_stats = malloc(sizeof(double *) * 7);
    for(i = 0; i < 7; i++){ obs_stats[i] = malloc(sizeof(double) * 8); }
    obs_covar = malloc(sizeof(double *) * 7);
    for(i = 0; i < 7; i++){ obs_covar[i] = malloc(sizeof(double) * 7); }
    
    // count the number of entries in the input file
    NOvals = 0;
    while(fgets(dummy1,10000,infile) != NULL){
      
      j = strlen(dummy1);
      if(j < 1){ continue; }
      j = strspn(dummy1," \t");
      if((dummy1[j] == '#') || (dummy1[j] == '\0')){ continue; }
      NOvals++;
      
    }
    j = fseek(infile,0,SEEK_SET);
    if(vb_flag >= 0){ printf("%d entries in the source+noise catalogue.",NOvals); }
    
    // allocate memory to store input file
    //x_vals = malloc(sizeof(float) * NOvals);
    //y_vals = malloc(sizeof(float) * NOvals);
    //n_vals = malloc(sizeof(float) * NOvals);
    x_vals = malloc(sizeof(double) * NOvals);
    y_vals = malloc(sizeof(double) * NOvals);
    n_vals = malloc(sizeof(double) * NOvals);
    
    // read input file into memory
    if(vb_flag >= 0){ printf("Reading source+noise objects into arrays . . . \n"); }
    v = 0;
    while((fgets(dummy1,10000,infile) != NULL) && (v < NOvals)){
      
      j = strlen(dummy1);
      if(j < 1){ continue; }
      j = strspn(dummy1," \t");
      if((dummy1[j] == '#') || (dummy1[j] == '\0')){ continue; }
      
      m = 0;
      i = 0;
      while(i > -1){
	j = m+(strspn((dummy1+m)," \t")); 
	if(dummy1[j] == '\0'){ i = -99; continue; }  
	k = j+1+(strcspn((dummy1+j+1)," \t"));
	if(k >= strlen(dummy1)){ k = strlen(dummy1) - 1; }
	m = k + 1;
	length = k - j;
	strcpy(dummy2,"");
	strncpy(dummy2,(dummy1+j),length);
	strcpy(&dummy2[length],"\0");
	
	//if(i == cols[0]){ sscanf(dummy2,"%f",&x_vals[v]); }
	//if(i == cols[1]){ sscanf(dummy2,"%f",&y_vals[v]); }
	//if(i == cols[2]){ sscanf(dummy2,"%f",&n_vals[v]); }
	if(i == cols[0]){ sscanf(dummy2,"%lf",&x_vals[v]); }
	if(i == cols[1]){ sscanf(dummy2,"%lf",&y_vals[v]); }
	if(i == cols[2]){ sscanf(dummy2,"%lf",&n_vals[v]); }
	
	// increment column index
	i++;
	
	// close while loop that loads data into variables
      }      
      
      // specify constant noise = 1.0 if cols[2] < 0
      if(cols[2] < 0){ n_vals[v] = 1.0; }
      
      // increment array index
      v++;
      
      // close while loop loading infile into arrays
    }
    if(vb_flag >= 0){ printf("done.\n"); }
    
    // close input file
    fclose(infile);
    
    // specify initial roll-off range
    fit_x_min = fit_params[4] = x_vals[0] + (0.05 * (x_vals[(NOvals - 1)] - x_vals[0]));
    fit_x_max = fit_params[8] = x_vals[0] + (0.95 * (x_vals[(NOvals - 1)] - x_vals[0]));
    
    // call busy function fitting routine to find best fit
    fit_type = FitBusyFunc_dbl(NOvals,x_vals,y_vals,n_vals,fit_params,fit_covar,&k,NOs,iter_max,vb_flag);
    
    // refine best fit
    fit_type = FitBusyFunc_dbl(NOvals,x_vals,y_vals,n_vals,fit_params,fit_covar,&k,-1,refine_iter,vb_flag);

    // display BF fitting result
    printf("BF fit . . . \n");
    printf("%d ",k);
    for(i = 0; i < 17; i++){ printf("%e ",fit_params[i]); }
    for(i = 0; i < 8; i++){
      for(j = 0; j < 8; j++){
	printf("%e ",fit_covar[i][j]);
      }
    }
    printf("\n");
    
    // call functions that generate N random BF fit variants, calculates observational parameters for them
    // and measures basic statistical properties 
    CreateRandFits_dbl(NOr,rand_fits,fit_type,fit_params,fit_covar,fit_x_min,fit_x_max,vb_flag);
    CalcObsParams_dbl(NOr,rand_fits,NOvals,x_vals,rand_obs_vals,vb_flag);
    AnalyseObsVals_dbl(NOr,7,rand_obs_vals,obs_stats,vb_flag);

    // display statistical properties of observational parameters
    for(j = 0; j < 7; j++){
      switch (j) {
      case 0:
	printf("Total intensity --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis \n");
	break;
      case 1:
	printf("Peak intensity --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis \n");
	break;	
      case 2:
	printf("Peak intensity position --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis \n");
	break;
      case 3:
	printf("W_50 width --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis \n");
	break;
      case 4:
	printf("W_50 position --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis \n");
	break;
      case 5:
	printf("W_20 width --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis \n");
	break;
      case 6:
	printf("W_20 position --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis \n");
	break;
      default:
	break;
      }
      for(i = 0; i < 8; i++){
	printf("%e ",obs_stats[j][i]);
      }
      printf("\n");
    }

    // calculate and display observational parameter covariance
    ApproxObsCovar_dbl(fit_type,NOvals,x_vals,fit_params,fit_covar,obs_covar,fit_x_min,fit_x_max);
    printf("Observational parameter covariance matrix . . . \n");
    for(j = 0; j < 7; j++){
      for(i = 0; i < 7; i++){
	printf("%lf ",obs_covar[j][i]);
      }
      printf("\n");
    }
    printf("Resultant errors . . . \n");
    for(i = 0; i < 7; i++){ printf("%lf ",sqrtf(obs_covar[i][i])); }
    printf("\n");

    // free up memory
    free(x_vals);
    free(y_vals);
    free(n_vals);
    free(fit_params);
    for(i = 0; i < 8; i++){ free(fit_covar[i]); }
    free(fit_covar);

    for(i = 0; i < NOr; i++){ 
      free(rand_fits[i]);
      free(rand_obs_vals[i]);
    }
    free(rand_fits);
    free(rand_obs_vals);
    for(i = 0; i < 7; i++){ 
      free(obs_stats[i]); 
      free(obs_covar[i]);
    }
    free(obs_stats);
    free(obs_covar);
    
    // if(infile != NULL)
  } else {
    
    printf("ERROR!!! Couldn't open input file: %s \n",infile_name);
    
  }
  
  return 1;

  // int main(int argc, char* argv[])
}






