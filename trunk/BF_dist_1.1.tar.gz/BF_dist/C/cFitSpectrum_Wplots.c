/*

This is version 1.0 of the demonstration program for the C BusyFunc library that fits the Busy 
Function to data. See Westmeier, Jurek, Obreschkow & Koribalski (2013) for more details about 
the implementation of this C library and the Busy Function.

Created by Russell J. Jurek, 30th June 2013.
Email: Russell.Jurek@gmail.com

 */

#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<cBFfit_OMP.h>
#include<cpgplot.h>

int main(int argc, char* argv[]){

  FILE * infile;
  char * infile_name, * dummy3, * output_plot_name;
  char dummy1[10000], dummy2[1000];
  int i,j,k,m,length,v,NOvals,vb_flag = -1, fit_type, cols[3] = {0,1,-99}, NOr = 10000, NOs = 1000, iter_max = 30, refine_iter = 3000;
  //float * x_vals, * y_vals, * n_vals, * fit_params, ** fit_covar, fit_x_min, fit_x_max, ** rand_fits, ** rand_obs_vals, ** obs_stats, ** obs_covar;
  double * x_vals, * y_vals, * n_vals, * fit_params, ** fit_covar, fit_x_min, fit_x_max, ** rand_fits, ** rand_obs_vals, ** obs_stats, ** obs_covar;
  
  // plotting variables
  int NOa = 1501;
  float * hist_vals, * hist_HD_vals, * hist2D_vals, * hist2D_HD_vals, * plot_tmp_vals, * plot_tmp_x_vals,plot_angle,plot_radius;
  float SD_step,y_min,y_max,HD_step,tr[6],p_min[8] = {9E30,9E30,9E30,9E30,9E30,9E30,9E30,9E30},p_max[8] = {-9E30,-9E30,-9E30,-9E30,-9E30,-9E30,-9E30,-9E30};
  float mapped_fit[8],det_covar_proj,inv_covar_proj[2][2];

  // test if insufficient arguments were specified on the command line
  if((argc == 1) || (argc >= 7)){ printf("Incorrect number of arguments. Use `FitSpectrum -h' to view instructions."); return 0; }
  
  // get input file from the command line
  infile_name = argv[1];
  
  // display instructions if the first entry on the command line was -h or -H
  if((strcmp(infile_name,"-h") == 0) || (strcmp(infile_name,"-H") == 0)){ printf("Instructions for FitSpectrum: \n\nThis program uses the C++ Busy Function fitting library to fit the Busy Function to a single spectra. This program assumes that each line of the input file contains an x and y value, as well as an optional noise value for each (x,y). This program also assumes space delimited input files.\n\nUsage: FitSpectrum input_file [x_col] [y_col] [noise_col] [-v or -vv] [-s NOs iter_max] [-r refine_iter] \n       FitSpectrum -h\n\nThe input_file is the only mandatory input. All other inputs are optional, which is represented by []. The optional inputs are:\nx_col: The column containing the x values. Count from 0. Default is 0.\ny_col: The column containing the y values. Count from 0. Default is 1.\nnoise_col: The column containing the noise values. Default is -99, which assigns a value of 1 for every x.\n-v: Turn verbosity to medium (default is none).\n-vv: Turn verbosity to high (default is none).\n-s NOs iter_max: These 3 values specify a non-default number of LVM seeds and LVM iterations per seed (defaults are 1000 and 30).\n-r refine_iter: These 2 values specify the number of iterations to use to refine the best fit by re-fitting (default is 3000).\n\nThe fitting results are written to the terminal. The first value is the dimensionality of the best fitting BF model. The next 16 values are the BF fit parameters and their uncertainties (listed in value, error pairs). The next value is chi^2. The remaining 64 values are the chi^2 covariance matrix.\nThe values are written out in scientific notation to accommodate especially large or small values.\n"); return 0; }
 
  // process command line arguments
  j = 0;
  for(i = 2; ((i < argc) && (i < 11)); i++){

    dummy3 = argv[i];
    
    // process a verbose flag
    if((strcmp(dummy3,"-v") == 0) || (strcmp(dummy3,"-V") == 0)){ 
      vb_flag = 0; 
      continue;
    } 
    if((strcmp(dummy3,"-vv") == 0) || (strcmp(dummy3,"-VV") == 0) || (strcmp(dummy3,"-Vv") == 0) || (strcmp(dummy3,"-vV") == 0)){ 
      vb_flag = 1; 
      continue;
    }

    // process a LVM seed number and iteration maximum specification
    if((strcmp(dummy3,"-s") == 0) || (strcmp(dummy3,"-S") == 0)){
      sscanf(argv[(i + 1)],"%i",&NOs);
      sscanf(argv[(i + 2)],"%i",&iter_max);
      i+=2;
      continue;
    }

    // process a refinement iteration specification
    if((strcmp(dummy3,"-r") == 0) || (strcmp(dummy3,"-R") == 0)){
      sscanf(argv[(i + 1)],"%i",&refine_iter);
      i++;
      continue;
    }

    // process a column number
    sscanf(argv[i],"%i",&cols[j]);
    j++;

  }
  if(refine_iter < iter_max){ refine_iter = iter_max; }  

  // display columns to be used
  if(vb_flag >= 0){ printf("Using x_col = %d, y_col = %d & noise_col = %d \n",cols[0],cols[1],cols[2]); }
  
  // display seeds and iterations
  if(vb_flag >= 0){ printf("Using %i LVM seeds, with a maximum of %i iterations per seed. Refining fit with %i iterations.\n",NOs,iter_max,refine_iter); }

  // open input file
  if(vb_flag >= 0){ printf("Opening input file: %s \n",infile_name); }
  infile = NULL;
  infile = fopen(infile_name,"r");
  
  // check that the input file is open
  if(infile != NULL){
    
    // create arrays used by BusyFunc
    //
    // float versions 
    //fit_params = malloc(sizeof(float) * 17);
    //fit_covar =  malloc(sizeof(float *) * 8);
    //rand_fits = malloc(sizeof(float *) * NOr);
    //for(i = 0; i < 8; i++){ fit_covar[i] = malloc(sizeof(float) * 8); }
    //rand_obs_vals = malloc(sizeof(float *) * NOr);
    //for(i = 0; i < NOr; i++){ 
    //  rand_obs_vals[i] = malloc(sizeof(float) * 7); 
    //  rand_fits[i] = malloc(sizeof(float) * 8);
    //}
    //obs_stats = malloc(sizeof(float *) * 7);
    //for(i = 0; i < 7; i++){ obs_stats[i] = malloc(sizeof(float) * 8); }
    //
    // double versions
    fit_params = malloc(sizeof(double) * 17);
    fit_covar =  malloc(sizeof(double *) * 8);
    rand_fits = malloc(sizeof(double *) * NOr);
    for(i = 0; i < 8; i++){ fit_covar[i] = malloc(sizeof(double) * 8); }
    rand_obs_vals = malloc(sizeof(double *) * NOr);
    for(i = 0; i < NOr; i++){ 
      rand_obs_vals[i] = malloc(sizeof(double) * 7); 
      rand_fits[i] = malloc(sizeof(double) * 8);
    }
    obs_stats = malloc(sizeof(double *) * 7);
    for(i = 0; i < 7; i++){ obs_stats[i] = malloc(sizeof(double) * 8); }
    obs_covar = malloc(sizeof(double *) * 7);
    for(i = 0; i < 7; i++){ obs_covar[i] = malloc(sizeof(double) * 7); }
    
    // count the number of entries in the input file
    NOvals = 0;
    while(fgets(dummy1,10000,infile) != NULL){
      
      j = strlen(dummy1);
      if(j < 1){ continue; }
      j = strspn(dummy1," \t");
      if((dummy1[j] == '#') || (dummy1[j] == '\0')){ continue; }
      NOvals++;
      
    }
    j = fseek(infile,0,SEEK_SET);
    if(vb_flag >= 0){ printf("%d entries in the source+noise catalogue.",NOvals); }
    
    // allocate memory to store input file
    //x_vals = malloc(sizeof(float) * NOvals);
    //y_vals = malloc(sizeof(float) * NOvals);
    //n_vals = malloc(sizeof(float) * NOvals);
    x_vals = malloc(sizeof(double) * NOvals);
    y_vals = malloc(sizeof(double) * NOvals);
    n_vals = malloc(sizeof(double) * NOvals);
    
    // read input file into memory
    if(vb_flag >= 0){ printf("Reading source+noise objects into arrays . . . \n"); }
    v = 0;
    while((fgets(dummy1,10000,infile) != NULL) && (v < NOvals)){
      
      j = strlen(dummy1);
      if(j < 1){ continue; }
      j = strspn(dummy1," \t");
      if((dummy1[j] == '#') || (dummy1[j] == '\0')){ continue; }
      
      m = 0;
      i = 0;
      while(i > -1){
	j = m+(strspn((dummy1+m)," \t")); 
	if(dummy1[j] == '\0'){ i = -99; continue; }  
	k = j+1+(strcspn((dummy1+j+1)," \t"));
	if(k >= strlen(dummy1)){ k = strlen(dummy1) - 1; }
	m = k + 1;
	length = k - j;
	strcpy(dummy2,"");
	strncpy(dummy2,(dummy1+j),length);
	strcpy(&dummy2[length],"\0");
	
	//if(i == cols[0]){ sscanf(dummy2,"%f",&x_vals[v]); }
	//if(i == cols[1]){ sscanf(dummy2,"%f",&y_vals[v]); }
	//if(i == cols[2]){ sscanf(dummy2,"%f",&n_vals[v]); }
	if(i == cols[0]){ sscanf(dummy2,"%lf",&x_vals[v]); }
	if(i == cols[1]){ sscanf(dummy2,"%lf",&y_vals[v]); }
	if(i == cols[2]){ sscanf(dummy2,"%lf",&n_vals[v]); }
	
	// increment column index
	i++;
	
	// close while loop that loads data into variables
      }      
      
      // specify constant noise = 1.0 if cols[2] < 0
      if(cols[2] < 0){ n_vals[v] = 1.0; }
      
      // increment array index
      v++;
      
      // close while loop loading infile into arrays
    }
    if(vb_flag >= 0){ printf("done.\n"); }
    
    // close input file
    fclose(infile);
    
    // specify initial roll-off range
    fit_x_min = fit_params[4] = x_vals[0] + (0.05 * (x_vals[(NOvals - 1)] - x_vals[0]));
    fit_x_max = fit_params[8] = x_vals[0] + (0.95 * (x_vals[(NOvals - 1)] - x_vals[0]));
    
    // call busy function fitting routine to find best fit
    fit_type = FitBusyFunc_dbl(NOvals,x_vals,y_vals,n_vals,fit_params,fit_covar,&k,NOs,iter_max,vb_flag);
    
    // refine best fit
    fit_type = FitBusyFunc_dbl(NOvals,x_vals,y_vals,n_vals,fit_params,fit_covar,&k,-1,refine_iter,vb_flag);

    // display BF fitting result
    printf("BF fit . . . \n");
    printf("%d ",k);
    for(i = 0; i < 17; i++){ printf("%e ",fit_params[i]); }
    for(i = 0; i < 8; i++){
      for(j = 0; j < 8; j++){
	printf("%e ",fit_covar[i][j]);
      }
    }
    printf("\n");
    
    // call functions that generate N random BF fit variants, calculates observational parameters for them
    // and measures basic statistical properties 
    CreateRandFits_dbl(NOr,rand_fits,fit_type,fit_params,fit_covar,fit_x_min,fit_x_max,vb_flag);
    CalcObsParams_dbl(NOr,rand_fits,NOvals,x_vals,rand_obs_vals,vb_flag);
    AnalyseObsVals_dbl(NOr,7,rand_obs_vals,obs_stats,vb_flag);

    // display statistical properties of observational parameters
    for(j = 0; j < 7; j++){
      switch (j) {
      case 0:
	printf("Total intensity --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis \n");
	break;
      case 1:
	printf("Peak intensity --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis \n");
	break;	
      case 2:
	printf("Peak intensity position --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis \n");
	break;
      case 3:
	printf("W_50 width --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis \n");
	break;
      case 4:
	printf("W_50 position --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis \n");
	break;
      case 5:
	printf("W_20 width --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis \n");
	break;
      case 6:
	printf("W_20 position --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis \n");
	break;
      default:
	break;
      }
      for(i = 0; i < 8; i++){
	printf("%lf ",obs_stats[j][i]);
      }
      printf("\n");
    }

    // calculate and display observational parameter covariance
    ApproxObsCovar_dbl(fit_type,NOvals,x_vals,fit_params,fit_covar,obs_covar,fit_x_min,fit_x_max);
    printf("Observational parameter covariance matrix . . . \n");
    for(j = 0; j < 7; j++){
      for(i = 0; i < 7; i++){
	printf("%lf ",obs_covar[j][i]);
      }
      printf("\n");
    }
    printf("Resultant errors . . . \n");
    for(i = 0; i < 7; i++){ printf("%lf ",sqrtf(obs_covar[i][i])); }
    printf("\n");

    // allocate memory used for plotting
    printf("allocating plotting memory . . . \n");
    hist_vals = malloc(sizeof(float) * 10);
    hist_HD_vals = malloc(sizeof(float) * 100);
    hist2D_vals = malloc(sizeof(float) * 100);
    hist2D_HD_vals = malloc(sizeof(float) * 10000);

    // open output plot
    i = (int) strcspn(infile_name,".");
    output_plot_name = infile_name;
    strcpy(&output_plot_name[i],"\0");
    strcat(output_plot_name,"_BFplots.ps");
    strcat(output_plot_name,"/cps");
    cpgopen(output_plot_name);

    // determine range of BF fit random variants
    for(i = 0; i < NOr; i++){
      
      for(j = 0; j < 8; j++){

	p_max[j] = (p_max[j] > rand_fits[i][j]) ? p_max[j] : rand_fits[i][j];
	p_min[j] = (p_min[j] < rand_fits[i][j]) ? p_min[j] : rand_fits[i][j];

      }

    }
    for(i = 0; i < 8; i++){ 
      if(fabs(p_max[i] - p_min[i]) <= 1.00000E-30){ 
	p_min[i]-=0.05; 
	p_max[i]+=0.05;
      }
    }

    // plot data and best fit
    if(vb_flag >= 0){ printf("Plotting data, BF fit and residuals . . . \n"); }
    plot_tmp_x_vals = malloc(sizeof(float) * NOvals);
    plot_tmp_vals = malloc(sizeof(float) * NOvals);
    y_min = 9E30;
    y_max = -9E30;
    for(i = 0; i < NOvals; i++){ 

      plot_tmp_x_vals[i] = (float) x_vals[i];
      plot_tmp_vals[i] = 0.25 * fit_params[0] * (1.0 + erff((fit_params[2] * (x_vals[i] - fit_params[4])))) * (1.0 + erff((fit_params[6] * (fit_params[8] - x_vals[i])))) * (1.0 + (fit_params[10] * (powf((fabs((fit_params[12] - x_vals[i]))),fit_params[14]))));
      if(isnan(plot_tmp_vals[i])){ plot_tmp_vals[i] = 0.0; }
      if(isinf(plot_tmp_vals[i])){ plot_tmp_vals[i] = (plot_tmp_vals[i] > 0.0) ? 9E30 : -9E30; }
      y_min = (y_min < plot_tmp_vals[i]) ? y_min : plot_tmp_vals[i];
      y_min = (y_min < y_vals[i]) ? y_min : y_vals[i];
      y_max = (y_max > plot_tmp_vals[i]) ? y_max : plot_tmp_vals[i];
      y_max = (y_max > y_vals[i]) ? y_max : y_vals[i];

    }
    if(vb_flag >= 0){ printf("\n"); }
    if(y_min == y_max){ y_min-=0.1; y_max+=0.1; }
    cpgenv(x_vals[0],x_vals[(NOvals - 1)],(y_min - 0.05 * (y_max - y_min)),(y_max + 0.05 * (y_max - y_min)),0,0);
    cpgsci(2);
    cpgline(NOvals,plot_tmp_x_vals,plot_tmp_vals);
    cpgsci(1);
    for(i = 0; i < NOvals; i++){ plot_tmp_vals[i] = (float) y_vals[i] - plot_tmp_vals[i]; }
    cpgsci(4);
    cpgline(NOvals,plot_tmp_x_vals,plot_tmp_vals);
    cpgsci(1);
    for(i = 0; i < NOvals; i++){ plot_tmp_vals[i] = (float) y_vals[i]; }
    cpgline(NOvals,plot_tmp_x_vals,plot_tmp_vals);    
    cpglab("channel/frequency/km s\\u-1\\d","intensity","data with fit overplotted");
    free(plot_tmp_vals);
    
    // plot parameter fits and correlated errors --- error ellipses overlaid on HD distributions
    if(vb_flag >= 0){ printf("Plotting parameter error ellipses overlaid on distributions . . . \n"); }
    plot_tmp_x_vals = malloc(sizeof(float) * NOa);
    plot_tmp_vals = malloc(sizeof(float) * NOa);
    if(fit_params[0] > 0.0){ mapped_fit[0] = log(fit_params[0]); } else { mapped_fit[0] = -1000.0; }
    if(isnan(mapped_fit[0])){ mapped_fit[0] = 0.0; }
    if(isinf(mapped_fit[0])){ mapped_fit[0] = (mapped_fit[0] > 0.0) ? 9E30 : -9E30; }
    if(fit_params[2] > 0.0){ mapped_fit[1] = log(fit_params[2]); } else { mapped_fit[1] = -1000.0; }
    if(isnan(mapped_fit[1])){ mapped_fit[1] = 0.0; }
    if(isinf(mapped_fit[1])){ mapped_fit[1] = (mapped_fit[1] > 0.0) ? 9E30 : -9E30; }
    mapped_fit[2] = asin((fit_params[4] - (0.5 * (fit_x_min + fit_x_max)))/(0.5 * (fit_x_max - fit_x_min)));
    if(isnan(mapped_fit[2])){ mapped_fit[2] = 0.0; }
    if(isinf(mapped_fit[2])){ mapped_fit[2] = (mapped_fit[2] > 0.0) ? 9E30 : -9E30; }
    if(fit_params[6] > 0.0){ mapped_fit[3] = log(fit_params[6]); } else { mapped_fit[3] = -1000.0; }
    if(isnan(mapped_fit[3])){ mapped_fit[3] = 0.0; }
    if(isinf(mapped_fit[3])){ mapped_fit[3] = (mapped_fit[3] > 0.0) ? 9E30 : -9E30; }
    mapped_fit[4] = asin((fit_params[8] - (0.5 * (fit_x_min + fit_x_max)))/(0.5 * (fit_x_max - fit_x_min)));
    if(isnan(mapped_fit[4])){ mapped_fit[4] = 0.0; }
    if(isinf(mapped_fit[4])){ mapped_fit[4] = (mapped_fit[4] > 0.0) ? 9E30 : -9E30; }
    if(fit_params[10] > 0.0){ mapped_fit[5] = log(fit_params[10]); } else { mapped_fit[5] = -1000.0; }
    if(isnan(mapped_fit[5])){ mapped_fit[5] = 0.0; }
    if(isinf(mapped_fit[5])){ mapped_fit[5] = (mapped_fit[5] > 0.0) ? 9E30 : -9E30; }
    mapped_fit[6] = asin((fit_params[12] - (0.5 * (fit_x_min + fit_x_max)))/(0.5 * (fit_x_max - fit_x_min)));
    if(isnan(mapped_fit[6])){ mapped_fit[6] = 0.0; }
    if(isinf(mapped_fit[6])){ mapped_fit[6] = (mapped_fit[6] > 0.0) ? 9E30 : -9E30; }
    mapped_fit[7] = asin((fit_params[14] - 5.0)/3.0);
    if(isnan(mapped_fit[7])){ mapped_fit[7] = 0.0; }
    if(isinf(mapped_fit[7])){ mapped_fit[7] = (mapped_fit[7] > 0.0) ? 9E30 : -9E30; }

    // over-write covariance matrix according to fit type; erase information about redundant parameters using information from relevant parameters
    switch(fit_type){
    case 1:
      for(i = 0; i < 8; i++){ 
	fit_covar[3][i] = fit_covar[1][i]; 
	fit_covar[i][3] = fit_covar[i][1];
      }
      for(i = 0; i < 8; i++){
	fit_covar[6][i] = 0.5 * (fit_covar[2][i] + fit_covar[4][i]);
	fit_covar[i][6] = 0.5 * (fit_covar[i][2] + fit_covar[i][4]);
      }
      break;
    case 2:
      for(i = 0; i < 8; i++){ 
	fit_covar[3][i] = fit_covar[1][i]; 
	fit_covar[i][3] = fit_covar[i][1];
      }
      for(i = 0; i < 8; i++){
	fit_covar[6][i] = 0.5 * (fit_covar[2][i] + fit_covar[4][i]);
	fit_covar[i][6] = 0.5 * (fit_covar[i][2] + fit_covar[i][4]);
      }
      break;
    case 3:
      for(i = 0; i < 8; i++){ 
	fit_covar[3][i] = fit_covar[1][i]; 
	fit_covar[i][3] = fit_covar[i][1];
      }
      for(i = 0; i < 8; i++){
	fit_covar[6][i] = 0.5 * (fit_covar[2][i] + fit_covar[4][i]);
	fit_covar[i][6] = 0.5 * (fit_covar[i][2] + fit_covar[i][4]);
      }
      break;
    case 4:
      for(i = 0; i < 8; i++){ 
	fit_covar[3][i] = fit_covar[1][i]; 
	fit_covar[i][3] = fit_covar[i][1];
      }
      for(i = 0; i < 8; i++){
	fit_covar[6][i] = 0.5 * (fit_covar[2][i] + fit_covar[4][i]);
	fit_covar[i][6] = 0.5 * (fit_covar[i][2] + fit_covar[i][4]);
      }
      break;
    case 5:
      for(i = 0; i < 8; i++){ 
	fit_covar[3][i] = fit_covar[1][i]; 
	fit_covar[i][3] = fit_covar[i][1];
      }
      break;
    default:
      break;
    }

    // adjust obs_stats[][2] (min) and obs_stats[][3] (max) if they're the same
    for(j = 0; j < 7; j++){
      if(obs_stats[j][2] == obs_stats[j][3]){ obs_stats[j][2]*=0.995; obs_stats[j][3]*=1.005; }
    }
    
    // construct plots of BF fit parameter distributions
    cpgpage();
    for(j = 0; j < 7; j++){

      for(k = j + 1; k < 8; k++){

	// initialise 2D distribution peak
	y_max = -9E30;
	
	// determine 2D distribution
	for(i = 0; i < 10000; i++){ hist2D_HD_vals[i] = 0.0; }
	SD_step = 0.01 * (p_max[j] - p_min[j]) * (p_max[k] - p_min[k]);
	HD_step = 0.01 * SD_step;

	for(i = 0; i < NOr; i++){

	  m = (int) floorf(((rand_fits[i][j] - p_min[j])/(0.01 * (p_max[j] - p_min[j]))));
	  v = (int) floorf(((rand_fits[i][k] - p_min[k])/(0.01 * (p_max[k] - p_min[k]))));
	  if((m >= 0) && (m < 100) && (v >= 0) && (v < 100)){

	    hist2D_HD_vals[(m + (100 * v))]+=(1.0/((float) NOr));
	    y_max = (y_max > hist2D_HD_vals[(m + (100 * v))]) ? y_max : hist2D_HD_vals[(m + (100 * v))];
	    
	  }

	  // for(i = 0; i < NOr; i++)
	}
	
	// convert 2D HD distribution into logarithmic counts
	for(i = 0; i < 10000; i++){
	  if(hist2D_HD_vals[i] > 0.0){ hist2D_HD_vals[i] = log(hist2D_HD_vals[i])/log(10.0); } else { hist2D_HD_vals[i] = -1000.0; }
	}
	y_max = log(y_max)/log(10.0);

	// plot HD 2D distribution
	cpgsvp((0.1 + (0.125 * (float) j)),(0.1 + (0.125 * (float) (j + 1))),(0.1 + (0.125 * (float) (k - 1))),(0.1 + (0.125 * (float) k)));
	cpgswin((p_min[j] - 0.1 * (p_max[j] - p_min[j])),(p_max[j] + 0.1 * (p_max[j] - p_min[j])),(p_min[k] - 0.1 * (p_max[k] - p_min[k])),(p_max[k] + 0.1 * (p_max[k] - p_min[k])));
	tr[0] = p_min[j] - 0.005 * (p_max[j] - p_min[j]);
	tr[1] = 0.01 * (p_max[j] - p_min[j]);
	tr[2] = 0.0;
	tr[3] = p_min[k] - 0.005 * (p_max[k] - p_min[k]);
	tr[4] = 0.0;
	tr[5] = 0.01 * (p_max[k] - p_min[k]);
	cpggray(hist2D_HD_vals,100,100,1,100,1,100,y_max,-5.0,tr);
	if(j == 0){
	  switch(k){
	  case 0:
	    cpglab("","\\(0627)","");
	    break;
	  case 1:
	    cpglab("","\\(0628)\\d1\\u","");
	    break;
	  case 2:
	    cpglab("","\\(0629)\\d1\\u","");
	    break;
	  case 3:
	    cpglab("","\\(0628)\\d2\\u","");
	    break;
	  case 4:
	    cpglab("","\\(0629)\\d2\\u","");
	    break;
	  case 5:
	    cpglab("","\\(0547)","");
	    break;
	  case 6:
	    cpglab("","\\(0534)","");
	    break;
	  case 7:
	    cpglab("","n","");
	    break;
	  default:
	    break;
	  }
	  if(k == 1){
	    cpgbox("BCNST",0,0,"BCNST",0,0);
	    cpglab("\\(0627)","","");
	  } else {
	    cpgbox("BCST",0,0,"BCNST",0,0);
	  }
	} else if((j + 1) == k) {
	  cpgbox("BCNST",0,0,"BCST",0,0);
	  switch(j){
	  case 0:
	    cpglab("\\(0627)","","");
	    break;
	  case 1:
	    cpglab("\\(0628)\\d1\\u","","");
	    break;
	  case 2:
	    cpglab("\\(0629)\\d1\\u","","");
	    break;
	  case 3:
	    cpglab("\\(0628)\\d2\\u","","");
	    break;
	  case 4:
	    cpglab("\\(0629)\\d2\\u","","");
	    break;
	  case 5:
	    cpglab("\\(0547)","","");
	    break;
	  case 6:
	    cpglab("\\(0534)","","");
	    break;
	  case 7:
	    cpglab("n","","");
	    break;
	  default:
	    break;
	  }
	} else {
	  cpgbox("BCST",0,0,"BCST",0,0);
	}
	
	// plot median values
	cpgsci(2);
	cpgsfs(2);
	cpgsch(1.5);
	cpgpt1(fit_params[(2 * j)],fit_params[(2 * k)],2);
	cpgsfs(1);
	cpgsci(1);
	cpgsch(1);
	
	det_covar_proj = (fit_covar[j][j] * fit_covar[k][k]) - (fit_covar[j][k] * fit_covar[k][j]);
	if(fabs(det_covar_proj) >= 1.0000E-30){

	  inv_covar_proj[0][0] = fit_covar[k][k] / det_covar_proj;
	  if(isnan(inv_covar_proj[0][0])){ inv_covar_proj[0][0] = 0.0; }
	  if(isinf(inv_covar_proj[0][0])){ inv_covar_proj[0][0] = (inv_covar_proj[0][0] > 0.0) ? 9E30 : -9E30; }
	  inv_covar_proj[1][0] = -1.0 * fit_covar[j][k] / det_covar_proj;
	  if(isnan(inv_covar_proj[1][0])){ inv_covar_proj[1][0] = 0.0; }
	  if(isinf(inv_covar_proj[1][0])){ inv_covar_proj[1][0] = (inv_covar_proj[1][0] > 0.0) ? 9E30 : -9E30; }
	  inv_covar_proj[0][1] = -1.0 * fit_covar[k][j] / det_covar_proj;
	  if(isnan(inv_covar_proj[0][1])){ inv_covar_proj[0][1] = 0.0; }
	  if(isinf(inv_covar_proj[0][1])){ inv_covar_proj[0][1] = (inv_covar_proj[0][1] > 0.0) ? 9E30 : -9E30; }
	  inv_covar_proj[1][1] = fit_covar[j][j] / det_covar_proj;
	  if(isnan(inv_covar_proj[1][1])){ inv_covar_proj[1][1] = 0.0; }
	  if(isinf(inv_covar_proj[1][1])){ inv_covar_proj[1][1] = (inv_covar_proj[1][1] > 0.0) ? 9E30 : -9E30; }
	  	  
	  // plot 1-sigma error ellipses
	  for(i = 0; i < (NOa - 1); i++){
	    
	    plot_angle = 6.283185307 * ((float) i) / ((float) (NOa - 1));
	    plot_radius = (float)((inv_covar_proj[1][1] * sin(plot_angle) * sin(plot_angle)) + (inv_covar_proj[0][0] * cos(plot_angle) * cos(plot_angle)) + ((inv_covar_proj[0][1] + inv_covar_proj[1][0]) * cos(plot_angle) * sin(plot_angle)));
	    if(plot_radius > 0.0){ plot_radius = sqrt((2.3 / plot_radius)); } else { plot_radius = 0.0; }
	    
	    plot_tmp_x_vals[i] = mapped_fit[j] + (plot_radius * cos(plot_angle));
	    plot_tmp_vals[i] = mapped_fit[k] + (plot_radius * sin(plot_angle));
	    switch(j){
	    case 0:
	      plot_tmp_x_vals[i] = expf(plot_tmp_x_vals[i]);
	      break;
	    case 1:
	      plot_tmp_x_vals[i] = expf(plot_tmp_x_vals[i]);
	      break;
	    case 2:
	      plot_tmp_x_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_x_vals[i]));
	      break;
	    case 3:
	      plot_tmp_x_vals[i] = expf(plot_tmp_x_vals[i]);
	      break;
	    case 4:
	      plot_tmp_x_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_x_vals[i]));
	      break;
	    case 5:
	      plot_tmp_x_vals[i] = expf(plot_tmp_x_vals[i]);
	      break;
	    case 6:
	      plot_tmp_x_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_x_vals[i]));
	      break;
	    case 7:
	      plot_tmp_x_vals[i] = 5.0 + (3.0 * sin(plot_tmp_x_vals[i]));
	      break;
	    default:
	      break;
	    }
	    switch(k){
	    case 0:
	      plot_tmp_vals[i] = expf(plot_tmp_vals[i]);
	      break;
	    case 1:
	      plot_tmp_vals[i] = expf(plot_tmp_vals[i]);
	      break;
	    case 2:
	      plot_tmp_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_vals[i]));
	      break;
	    case 3:
	      plot_tmp_vals[i] = expf(plot_tmp_vals[i]);
	      break;
	    case 4:
	      plot_tmp_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_vals[i]));
	      break;
	    case 5:
	      plot_tmp_vals[i] = expf(plot_tmp_vals[i]);
	      break;
	    case 6:
	      plot_tmp_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_vals[i]));
	      break;
	    case 7:
	      plot_tmp_vals[i] = 5.0 + (3.0 * sin(plot_tmp_vals[i]));
	      break;
	    default:
	      break;
	    }
	    if(isnan(plot_tmp_x_vals[i])){ plot_tmp_x_vals[i] = fit_params[(2 * j)]; }
	    if(isinf(plot_tmp_x_vals[i])){ plot_tmp_x_vals[i] = (plot_tmp_x_vals[i] > 0.0) ? 9E30 : -9E30; }
	    if(isnan(plot_tmp_vals[i])){ plot_tmp_vals[i] = fit_params[(2 * k)]; }
	    if(isinf(plot_tmp_vals[i])){ plot_tmp_vals[i] = (plot_tmp_vals[i] > 0.0) ? 9E30 : -9E30; }
	    	    
	  }
	  plot_tmp_x_vals[(NOa - 1)] = plot_tmp_x_vals[0];
	  plot_tmp_vals[(NOa - 1)] = plot_tmp_vals[0];
	  cpgsci(2);
	  cpgline(NOa,plot_tmp_x_vals,plot_tmp_vals);
	  cpgsci(1);
	  
	  // plot 3-sigma error ellipses
	  for(i = 0; i < (NOa - 1); i++){
	    
	    plot_angle = 6.283185307 * ((float) i) / ((float) (NOa - 1));
	    plot_radius = (float)((inv_covar_proj[1][1] * sin(plot_angle) * sin(plot_angle)) + (inv_covar_proj[0][0] * cos(plot_angle) * cos(plot_angle)) + ((inv_covar_proj[0][1] + inv_covar_proj[1][0]) * cos(plot_angle) * sin(plot_angle)));
	    if(plot_radius > 0.0){ plot_radius = sqrt((11.8 / plot_radius)); } else { plot_radius = 0.0; }
	    
	    plot_tmp_x_vals[i] = mapped_fit[j] + (plot_radius * cos(plot_angle));
	    plot_tmp_vals[i] = mapped_fit[k] + (plot_radius * sin(plot_angle));
	    switch(j){
	    case 0:
	      plot_tmp_x_vals[i] = expf(plot_tmp_x_vals[i]);
	      break;
	    case 1:
	      plot_tmp_x_vals[i] = expf(plot_tmp_x_vals[i]);
	      break;
	    case 2:
	      plot_tmp_x_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_x_vals[i]));
	      break;
	    case 3:
	      plot_tmp_x_vals[i] = expf(plot_tmp_x_vals[i]);
	      break;
	    case 4:
	      plot_tmp_x_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_x_vals[i]));
	      break;
	    case 5:
	      plot_tmp_x_vals[i] = expf(plot_tmp_x_vals[i]);
	      break;
	    case 6:
	      plot_tmp_x_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_x_vals[i]));
	      break;
	    case 7:
	      plot_tmp_x_vals[i] = 5.0 + (3.0 * sin(plot_tmp_x_vals[i]));
	      break;
	    default:
	      break;
	    }
	    switch(k){
	    case 0:
	      plot_tmp_vals[i] = expf(plot_tmp_vals[i]);
	      break;
	    case 1:
	      plot_tmp_vals[i] = expf(plot_tmp_vals[i]);
	      break;
	    case 2:
	      plot_tmp_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_vals[i]));
	      break;
	    case 3:
	      plot_tmp_vals[i] = expf(plot_tmp_vals[i]);
	      break;
	    case 4:
	      plot_tmp_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_vals[i]));
	      break;
	    case 5:
	      plot_tmp_vals[i] = expf(plot_tmp_vals[i]);
	      break;
	    case 6:
	      plot_tmp_vals[i] = (0.5 * (fit_x_min + fit_x_max)) + ((0.5 * (fit_x_max - fit_x_min)) * sin(plot_tmp_vals[i]));
	      break;
	    case 7:
	      plot_tmp_vals[i] = 5.0 + (3.0 * sin(plot_tmp_vals[i]));
	      break;
	    default:
	      break;
	    }
	    if(isnan(plot_tmp_x_vals[i])){ plot_tmp_x_vals[i] = fit_params[(2 * j)]; }
	    if(isinf(plot_tmp_x_vals[i])){ plot_tmp_x_vals[i] = (plot_tmp_x_vals[i] > 0.0) ? 9E30 : -9E30; }
	    if(isnan(plot_tmp_vals[i])){ plot_tmp_vals[i] = fit_params[(2 * k)]; }
	    if(isinf(plot_tmp_vals[i])){ plot_tmp_vals[i] = (plot_tmp_vals[i] > 0.0) ? 9E30 : -9E30; }
	    
	  }
	  plot_tmp_x_vals[(NOa - 1)] = plot_tmp_x_vals[0];
	  plot_tmp_vals[(NOa - 1)] = plot_tmp_vals[0];
	  cpgsci(3);
	  cpgline(NOa,plot_tmp_x_vals,plot_tmp_vals);
	  cpgsci(1);
	 
	  // if(fabs(det_covar_proj) >= 1.00000E-30)
	} else {

	  printf("Ill-conditioned matrix. Not plotting contours for combination %d, %d \n",j,k);
	  if(fabs(det_covar_proj) < 1.00000E-30){ printf("Determinant is too small! %lf < 1.00000E-30. Not plotting contours.\n",det_covar_proj); }

	}
	
	// for(k = j + 1; k < 8; k++)
      } 
      
      // for(j = 0; j < 7; j++)
    }
    free(plot_tmp_x_vals);
    free(plot_tmp_vals);
    
    // plot histograms of observational parameters
    if(vb_flag >= 0){ printf("Plotting observational parameter distributions . . . \n"); }
    plot_tmp_vals = malloc(sizeof(float) * 100);
    for(j = 0; j < 7; j++){

      // determine 1D distributions
      for(i = 0; i < 10; i++){ hist_vals[i] = 0.0; }
      for(i = 0; i < 100; i++){ hist_HD_vals[i] = 0.0; }
      SD_step = 0.1 * (obs_stats[j][3] - obs_stats[j][2]);
      HD_step = 0.01 * (obs_stats[j][3] - obs_stats[j][2]);
      y_max = -9E30;

      for(i = 0; i < NOr; i++){

	k = (int) floorf(((rand_obs_vals[i][j] - obs_stats[j][2])/SD_step));
	if((k >= 0) && (k < 10)){ 

	  hist_vals[k]+=(1.0/(10.0 * (float) NOr)); 
	  y_max = (y_max > hist_vals[k]) ? y_max : hist_vals[k];

	}
	k = (int) floorf(((rand_obs_vals[i][j] - obs_stats[j][2])/HD_step));
	if((k >= 0) && (k < 100)){ 

	  hist_HD_vals[k]+=(1.0/((float) NOr)); 
	  y_max = (y_max > hist_HD_vals[k]) ? y_max : hist_HD_vals[k];

	}

	// for(i = 0; i < NOr; i++)
      }

      // plot 1D distributions
      if(y_max <= 0.0){ y_max = 0.1; }
      cpgenv(obs_stats[j][2],obs_stats[j][3],(-0.025 * y_max),(1.025 * y_max),0,0);
      for(i = 0; i < 100; i++){ plot_tmp_vals[i] = obs_stats[j][2] + (((float) i + 0.5) * HD_step); }
      cpgline(100,plot_tmp_vals,hist_HD_vals);
      cpgsci(2);
      for(i = 0; i < 10; i++){ plot_tmp_vals[i] = obs_stats[j][2] + (((float) i + 0.5) * SD_step); }
      cpgline(10,plot_tmp_vals,hist_vals);
      cpgsci(1);
      switch (j){
      case 0:
	cpglab("total flux","relative distribution","");
	break;
      case 1:
	cpglab("peak flux","relative distribution","");
	break;
      case 2:
	cpglab("peak flux position","relative distribution","");
	break;
      case 3:
	cpglab("W\\d50\\u width","realative distribution","");
	break;
      case 4:
	cpglab("W\\d50\\u position","relative distribution","");
	break;
      case 5:
	cpglab("W\\d20\\u width","relative distribution","");
	break;
      case 6:
	cpglab("W\\d20\\u position","relative distribution","");
	break;
      default:
	break;
      }

      // for(j = 0; j < 7; j++)
    }
    free(plot_tmp_vals);
    
    // plot 2-D histograms of observational parameters
    plot_tmp_x_vals = malloc(sizeof(float) * NOa);
    plot_tmp_vals = malloc(sizeof(float) * NOa);
    cpgpage();
    for(j = 0; j < 7; j++){

      for(k = j; k < 7; k++){
	  
	// initialise 2D distribution peak
	y_max = -9E30;
	
	// determine 2D distributions
	for(i = 0; i < 100; i++){ hist2D_vals[i] = 0.0; }
	for(i = 0; i < 10000; i++){ hist2D_HD_vals[i] = 0.0; }
	SD_step = 0.01 * (obs_stats[j][3] - obs_stats[j][2]) * (obs_stats[k][3] - obs_stats[k][2]);
	HD_step = 0.01 * SD_step;
	for(i = 0; i < NOr; i++){
	  
	  m = (int) floorf(((rand_obs_vals[i][j] - obs_stats[j][2])/(0.1 * (obs_stats[j][3] - obs_stats[j][2]))));
	  v = (int) floorf(((rand_obs_vals[i][k] - obs_stats[k][2])/(0.1 * (obs_stats[k][3] - obs_stats[k][2]))));
	  if((m >= 0) && (m < 10) && (v >= 0) && (v < 10)){
	    
	    hist2D_vals[(m + (10 * v))]+=(0.01/((float) NOr));
	    y_max = (y_max > hist2D_vals[(m + (10 * v))]) ? y_max : hist2D_vals[(m + (10 * v))];
	    
	  }
	  m = (int) floorf(((rand_obs_vals[i][j] - obs_stats[j][2])/(0.01 * (obs_stats[j][3] - obs_stats[j][2]))));
	  v = (int) floorf(((rand_obs_vals[i][k] - obs_stats[k][2])/(0.01 * (obs_stats[k][3] - obs_stats[k][2]))));
	  if((m >= 0) && (m < 100) && (v >= 0) && (v < 100)){
	    
	    hist2D_HD_vals[(v + (100 * m))]+=(1.0/((float) NOr));
	    y_max = (y_max > hist2D_HD_vals[(v + (100 * m))]) ? y_max : hist2D_HD_vals[(v + (100 * m))];
	    
	  }
	  
	  // for(i = 0; i < NOr; i++)
	}
	
	// convert 2D histrograms to logarithmic counts
	for(i = 0; i < 100; i++){ 
	  if(hist2D_vals[i] > 0.0){ hist2D_vals[i] = log(hist2D_vals[i])/log(10.0); } else { hist2D_vals[i] = -1000.0; }
	}
	for(i = 0; i < 10000; i++){
	  if(hist2D_HD_vals[i] > 0.0){ hist2D_HD_vals[i] = log(hist2D_HD_vals[i])/log(10.0); } else { hist2D_HD_vals[i] = -1000.0; }
	}

	// plot SD 2D histogram
	if(y_max > 0.0){ y_max = log(y_max)/log(10.0); } else { y_max = -1000.0; }
	if(j != k){

	  cpgsvp((0.10 + (0.125 * (float) j)),(0.1 + (0.125 * (float) (j + 1))),(0.10 + (0.125 * (float) k)),(0.1 + (0.125 * (float) (k + 1))));
	  cpgswin((obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])));
	  tr[0] = obs_stats[j][2] - 0.05 * (obs_stats[j][3] - obs_stats[j][2]);
	  tr[1] = 0.1 * (obs_stats[j][3] - obs_stats[j][2]);
	  tr[2] = 0.0;
	  tr[3] = obs_stats[k][2] - 0.05 * (obs_stats[k][3] - obs_stats[k][2]);
	  tr[4] = 0.0;
	  tr[5] = 0.1 * (obs_stats[k][3] - obs_stats[k][2]);
	  cpggray(hist2D_vals,10,10,1,10,1,10,y_max,-5.0,tr);
	  if(j == 0){
	    switch(k){
	    case 0:
	      cpglab("","T\\dflux\\u","");
	      break;
	    case 1:
	      cpglab("","P\\dflux\\u","");
	      break;
	    case 2:
	      cpglab("","P\\df\\u pos.","");
	      break;
	    case 3:
	      cpglab("","W\\d50\\u width","");
	      break;
	    case 4:
	      cpglab("","W\\d50\\u position","");
	      break;
	    case 5:
	      cpglab("","W\\d20\\u width","");
	      break;
	    case 6:
	      cpglab("","W\\d20\\u position","");
	      break;
	    default:
	      break;
	    }
	    if(k == 0){
	      cpgbox("BCNST",0,0,"BCNST",0,0);
	    } else {
	      cpgbox("BCST",0,0,"BCNST",0,0);
	    }
	  } else {
	    if(k == 0){
	      cpgbox("BCNST",0,0,"BCST",0,0);
	    } else {
	      cpgbox("BCST",0,0,"BCST",0,0);
	    }
	  }

	  // plot median values
	  cpgsci(2);
	  cpgsfs(2);
	  cpgsch(1.5);
	  cpgpt1(obs_stats[j][0],obs_stats[k][0],2);
	  cpgsfs(1);
	  cpgsci(1);
	  cpgsch(1);

	  // if(j != k)
	}

	// plot HD 2D histogram
	cpgsvp((0.1 + (0.125 * (float) k)),(0.1 + (0.125 * (float) (k + 1))),(0.1 + (0.125 * (float) j)),(0.1 + (0.125 * (float) (j + 1))));
	cpgswin((obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])));
	tr[0] = obs_stats[k][2] - 0.005 * (obs_stats[k][3] - obs_stats[k][2]);
	tr[1] = 0.01 * (obs_stats[k][3] - obs_stats[k][2]);
	tr[2] = 0.0;
	tr[3] = obs_stats[j][2] - 0.005 * (obs_stats[j][3] - obs_stats[j][2]);
	tr[4] = 0.0;
	tr[5] = 0.01 * (obs_stats[j][3] - obs_stats[j][2]);
	cpggray(hist2D_HD_vals,100,100,1,100,1,100,y_max,-5.0,tr);
	if(j == 0){
	  if(k == 0){
	    cpgbox("BCNST",0,0,"BCNST",0,0);
	    cpglab("T\\dflux\\u","T\\dflux\\u","");
	  } else {
	    cpgbox("BCNST",0,0,"BCST",0,0);
	    switch(k){
	    case 0:
	      cpglab("T\\dflux\\u","","");
	      break;
	    case 1:
	      cpglab("P\\dflux\\u","","");
	      break;
	    case 2:
	      cpglab("P\\df\\u pos.","","");
	      break;
	    case 3:
	      cpglab("W\\d50\\u width","","");
	      break;
	    case 4:
	      cpglab("W\\d50\\u position","","");
	      break;
	    case 5:
	      cpglab("W\\d20\\u width","","");
	      break;
	    case 6:
	      cpglab("W\\d20\\u position","","");
	      break;
	    default:
	      break;
	    }
	  }
	} else {
	  cpgbox("BCST",0,0,"BCST",0,0);
	}
	
	// plot median values
	cpgsci(2);
	cpgsfs(2);
	cpgsch(1.5);
	cpgpt1(obs_stats[k][0],obs_stats[j][0],2);
	cpgsfs(1);
	cpgsci(1);
	cpgsch(1);

	// plot error ellipses or error intervals for a single parameter
       	if(j != k){

	  // calculate inverse of covariance matrix projection for this parameter combination	
	  det_covar_proj = (obs_covar[j][j] * obs_covar[k][k]) - (obs_covar[j][k] * obs_covar[k][j]);
	  if((fabs(det_covar_proj) >= 1.00000E-30) && (fabs(obs_covar[j][j]) >= 1.00000E-30) && (fabs(obs_covar[j][k]) >= 1.00000E-30) && (fabs(obs_covar[k][j]) >= 1.00000E-30) && (fabs(obs_covar[k][k]) >= 1.00000E-30)){
	    
	    inv_covar_proj[0][0] = obs_covar[k][k] / det_covar_proj;
	    if(isnan(inv_covar_proj[0][0])){ inv_covar_proj[0][0] = 0.0; }
	    if(isinf(inv_covar_proj[0][0])){ inv_covar_proj[0][0] = (inv_covar_proj[0][0] > 0.0) ? 9E30 : -9E30; }
	    inv_covar_proj[1][0] = -1.0 * obs_covar[j][k] / det_covar_proj;
	    if(isnan(inv_covar_proj[1][0])){ inv_covar_proj[1][0] = 0.0; }
	    if(isinf(inv_covar_proj[1][0])){ inv_covar_proj[1][0] = (inv_covar_proj[1][0] > 0.0) ? 9E30 : -9E30; }
	    inv_covar_proj[0][1] = -1.0 * obs_covar[k][j] / det_covar_proj;
	    if(isnan(inv_covar_proj[0][1])){ inv_covar_proj[0][1] = 0.0; }
	    if(isinf(inv_covar_proj[0][1])){ inv_covar_proj[0][1] = (inv_covar_proj[0][1] > 0.0) ? 9E30 : -9E30; }
	    inv_covar_proj[1][1] = obs_covar[j][j] / det_covar_proj;
	    if(isnan(inv_covar_proj[1][1])){ inv_covar_proj[1][1] = 0.0; }
	    if(isinf(inv_covar_proj[1][1])){ inv_covar_proj[1][1] = (inv_covar_proj[1][1] > 0.0) ? 9E30 : -9E30; }
	    
	    // plot 1-sigma error ellipses
	    for(i = 0; i < (NOa - 1); i++){
	      
	      plot_angle = 6.283185307 * ((float) i) / ((float) (NOa - 1));
	      plot_radius = (float)((inv_covar_proj[1][1] * sin(plot_angle) * sin(plot_angle)) + (inv_covar_proj[0][0] * cos(plot_angle) * cos(plot_angle)) + ((inv_covar_proj[0][1] + inv_covar_proj[1][0]) * cos(plot_angle) * sin(plot_angle)));
	      if(plot_radius > 0.0){ plot_radius = sqrt((2.3 / plot_radius)); } else { plot_radius = 0.0; }
	      
	      plot_tmp_x_vals[i] = obs_stats[j][0] + (plot_radius * cos(plot_angle));
	      plot_tmp_vals[i] = obs_stats[k][0] + (plot_radius * sin(plot_angle));
	      if(isnan(plot_tmp_x_vals[i])){ plot_tmp_x_vals[i] = fit_params[(2 * j)]; }
	      if(isinf(plot_tmp_x_vals[i])){ plot_tmp_x_vals[i] = (plot_tmp_x_vals[i] > 0.0) ? 9E30 : -9E30; }
	      if(isnan(plot_tmp_vals[i])){ plot_tmp_vals[i] = fit_params[(2 * k)]; }
	      if(isinf(plot_tmp_vals[i])){ plot_tmp_vals[i] = (plot_tmp_vals[i] > 0.0) ? 9E30 : -9E30; }
	      
	    }
	    plot_tmp_x_vals[(NOa - 1)] = plot_tmp_x_vals[0];
	    plot_tmp_vals[(NOa - 1)] = plot_tmp_vals[0];
	    
	    // re-set viewport to SD 2D distribution
	    cpgsvp((0.10 + (0.125 * (float) j)),(0.1 + (0.125 * (float) (j + 1))),(0.10 + (0.125 * (float) k)),(0.1 + (0.125 * (float) (k + 1))));
	    cpgswin((obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])));
	    cpgsci(2);
	    cpgline(NOa,plot_tmp_x_vals,plot_tmp_vals);
	    cpgsci(1);
	    
	    // re-set viewport to HD 3D distribution
	    cpgsvp((0.1 + (0.125 * (float) k)),(0.1 + (0.125 * (float) (k + 1))),(0.1 + (0.125 * (float) j)),(0.1 + (0.125 * (float) (j + 1))));
	    cpgswin((obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])));
	    for(i = 0; i < NOa; i++){
	      plot_angle = plot_tmp_x_vals[i];
	      plot_tmp_x_vals[i] = plot_tmp_vals[i];
	      plot_tmp_vals[i] = plot_angle;
	    }
	    cpgsci(2);
	    cpgline(NOa,plot_tmp_x_vals,plot_tmp_vals);
	    cpgsci(1);
	    
	    // plot 3-sigma error ellipses
	    for(i = 0; i < (NOa - 1); i++){
	      
	      plot_angle = 6.283185307 * ((float) i) / ((float) (NOa - 1));
	      plot_radius = (float)((inv_covar_proj[1][1] * sin(plot_angle) * sin(plot_angle)) + (inv_covar_proj[0][0] * cos(plot_angle) * cos(plot_angle)) + ((inv_covar_proj[0][1] + inv_covar_proj[1][0]) * cos(plot_angle) * sin(plot_angle)));
	      if(plot_radius > 0.0){ plot_radius = sqrt((11.8 / plot_radius)); } else { plot_radius = 0.0; }
	      
	      plot_tmp_x_vals[i] = obs_stats[j][0] + (plot_radius * cos(plot_angle));
	      plot_tmp_vals[i] = obs_stats[k][0] + (plot_radius * sin(plot_angle));
	      if(isnan(plot_tmp_x_vals[i])){ plot_tmp_x_vals[i] = fit_params[(2 * j)]; }
	      if(isinf(plot_tmp_x_vals[i])){ plot_tmp_x_vals[i] = (plot_tmp_x_vals[i] > 0.0) ? 9E30 : -9E30; }
	      if(isnan(plot_tmp_vals[i])){ plot_tmp_vals[i] = fit_params[(2 * k)]; }
	      if(isinf(plot_tmp_vals[i])){ plot_tmp_vals[i] = (plot_tmp_vals[i] > 0.0) ? 9E30 : -9E30; }
	      
	    }
	    plot_tmp_x_vals[(NOa - 1)] = plot_tmp_x_vals[0];
	    plot_tmp_vals[(NOa - 1)] = plot_tmp_vals[0];
	    
	    // re-set viewport to SD 2D distribution
	    cpgsvp((0.10 + (0.125 * (float) j)),(0.1 + (0.125 * (float) (j + 1))),(0.10 + (0.125 * (float) k)),(0.1 + (0.125 * (float) (k + 1))));
	    cpgswin((obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])));
	    cpgsci(3);
	    cpgline(NOa,plot_tmp_x_vals,plot_tmp_vals);
	    cpgsci(1);
	    
	    // re-set viewport to HD 3D distribution
	    cpgsvp((0.1 + (0.125 * (float) k)),(0.1 + (0.125 * (float) (k + 1))),(0.1 + (0.125 * (float) j)),(0.1 + (0.125 * (float) (j + 1))));
	    cpgswin((obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])));
	    for(i = 0; i < NOa; i++){
	      plot_angle = plot_tmp_x_vals[i];
	      plot_tmp_x_vals[i] = plot_tmp_vals[i];
	      plot_tmp_vals[i] = plot_angle;
	    }
	    cpgsci(3);
	    cpgline(NOa,plot_tmp_x_vals,plot_tmp_vals);
	    cpgsci(1);
	    
	    // if(fabs(det_covar_proj) >= 1.00000E-30)
	  } else {
	    
	    printf("Ill-conditioned matrix. Not plotting contours for combination %d, %d \n",j,k);
	    if(fabs(det_covar_proj) < 1.00000E-30){ printf("Determinant is too small! %lf < 1.00000E-30. Not plotting contours.\n",det_covar_proj); }
	    
	  }

	} else {

	  // re-set viewport to SD 2D distribution
	  cpgsvp((0.10 + (0.125 * (float) j)),(0.1 + (0.125 * (float) (j + 1))),(0.10 + (0.125 * (float) k)),(0.1 + (0.125 * (float) (k + 1))));
	  cpgswin((obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])));
	  cpgsci(2);
	  cpgmove((obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(-1.0 * (obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] + obs_stats[k][1] + obs_stats[j][0] + obs_stats[j][1]));
	  cpgdraw((obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(-1.0 * (obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] + obs_stats[k][1] + obs_stats[j][0] + obs_stats[j][1]));
	  cpgmove((obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(-1.0 * (obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] - obs_stats[k][1] + obs_stats[j][0] - obs_stats[j][1]));
	  cpgdraw((obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(-1.0 * (obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] - obs_stats[k][1] + obs_stats[j][0] - obs_stats[j][1]));
	  cpgsci(3);
	  cpgmove((obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(-1.0 * (obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] + obs_stats[j][0] + (3.0 * obs_stats[k][1] + obs_stats[j][1])));
	  cpgdraw((obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(-1.0 * (obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] + obs_stats[j][0] + (3.0 * obs_stats[k][1] + obs_stats[j][1])));
	  cpgmove((obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(-1.0 * (obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] + obs_stats[j][0] - (3.0 * obs_stats[k][1] + obs_stats[j][1])));
	  cpgdraw((obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(-1.0 * (obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])) + obs_stats[k][0] + obs_stats[j][0] - (3.0 * obs_stats[k][1] + obs_stats[j][1])));
	  cpgsci(1);
	  
	  // re-set viewport to HD 3D distribution
	  cpgsvp((0.1 + (0.125 * (float) k)),(0.1 + (0.125 * (float) (k + 1))),(0.1 + (0.125 * (float) j)),(0.1 + (0.125 * (float) (j + 1))));
	  cpgswin((obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(obs_stats[j][2] - 0.1 * (obs_stats[j][3] - obs_stats[j][2])),(obs_stats[j][3] + 0.1 * (obs_stats[j][3] - obs_stats[j][2])));
	  cpgsci(2);
	  cpgmove((obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(-1.0 * (obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] + obs_stats[j][1] + obs_stats[k][0] + obs_stats[k][1]));
	  cpgdraw((obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(-1.0 * (obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] + obs_stats[j][1] + obs_stats[k][0] + obs_stats[k][1]));
	  cpgmove((obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(-1.0 * (obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] - obs_stats[j][1] + obs_stats[k][0] - obs_stats[k][1]));
	  cpgdraw((obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(-1.0 * (obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] - obs_stats[j][1] + obs_stats[k][0] - obs_stats[k][1]));
	  cpgsci(3);
	  cpgmove((obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(-1.0 * (obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] + obs_stats[k][0] - (3.0 * obs_stats[j][1] + obs_stats[k][1])));
	  cpgdraw((obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(-1.0 * (obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] + obs_stats[k][0] - (3.0 * obs_stats[j][1] + obs_stats[k][1])));
	  cpgmove((obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(-1.0 * (obs_stats[k][2] - 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] + obs_stats[k][0] - (3.0 * obs_stats[j][1] + obs_stats[k][1])));
	  cpgdraw((obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])),(-1.0 * (obs_stats[k][3] + 0.1 * (obs_stats[k][3] - obs_stats[k][2])) + obs_stats[j][0] + obs_stats[k][0] - (3.0 * obs_stats[j][1] + obs_stats[k][1])));
	  cpgsci(1);
	  	  
	  // if(j == k)
	}

	// for(k = j + 1; k < 7; k++)
      }

      // for(j = 0; j < 7; j++)
    }
    free(plot_tmp_vals);
    free(plot_tmp_x_vals);
    
    // close output plot
    cpgclos();

    // free up memory
    free(x_vals);
    free(y_vals);
    free(n_vals);
    free(fit_params);
    for(i = 0; i < 8; i++){ free(fit_covar[i]); }
    free(fit_covar);

    for(i = 0; i < NOr; i++){ 
      free(rand_fits[i]);
      free(rand_obs_vals[i]);
    }
    free(rand_fits);
    free(rand_obs_vals);
    for(i = 0; i < 7; i++){ 
      free(obs_stats[i]); 
      free(obs_covar[i]);
    }
    free(obs_stats);
    free(obs_covar);
    
    // free up plotting memory
    free(hist_vals);
    free(hist_HD_vals);
    free(hist2D_vals);
    free(hist2D_HD_vals);

    // if(infile != NULL)
  } else {
    
    printf("ERROR!!! Couldn't open input file: %s \n",infile_name);
    
  }
  
  return 1;

  // int main(int argc, char* argv[])
}






