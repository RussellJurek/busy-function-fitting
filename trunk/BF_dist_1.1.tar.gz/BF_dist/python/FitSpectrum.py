#!/usr/bin/python

#####################################################################################################
#                                                                                                   #
# This is the python demo script for version 1.1 of the module that fits the Busy Function to data. #
# See Westmeier, Jurek, Obreschkow & Koribalski (2013) for more details about the implementation    #
# and the Busy Function.                                                                            #
#                                                                                                   #
# Created by Russell J. Jurek, 30th June 2013.                                                      #
# Email: Russell.Jurek@gmail.com                                                                    #
#                                                                                                   #
####################################################################################################

# import libraries
import sys;
import re;
import BusyFunc;

# define the main() function
def main():

    # check that sufficient arguments were entered on the command line
    if(int(len(sys.argv)) < 2):
        print "Insufficient number of arguments. Use 'python FitSpectrum -h' to see script usage.",
        sys.exit()

    # check if the first argument is -h or -H and display help message
    if((str(sys.argv[1]) == "-h") or (str(sys.argv[1]) == "-H")):
        print "Instructions for FitSpectrum: \n\nThis program uses the C/C++ Busy Function fitting library to fit the Busy Function to a single spectra. This program assumes that each line of the input file contains an x and y value, as well as an optional noise value for each (x,y). This program also assumes space delimited input files.\n\nUsage: FitSpectrum input_file [x_col] [y_col] [noise_col] [-v or -vv] \n       FitSpectrum -h\n\nThe input_file is the only mandatory input. All other inputs are optional, which is represented by []. The optional inputs are:\nx_col: The column containing the x values. Count from 0. Default is 0.\ny_col: The column containing the y values. Count from 0. Default is 1.\nnoise_col: The column containing the noise values. Default is -99, which assigns a value of 1 for every x.\n-v: Turn verbosity to medium (default is none).\n-vv: Turn verbosity to high (default is none).\n\nThe fitting results are written to the terminal. The first value is the dimensionality of the best fitting BF model. The next 16 values are the BF fit parameters and their uncertainties (listed in value, error pairs). The next value is chi^2. The remaining 64 values are the chi^2 covariance matrix.\nThe values are written out in scientific notation to accommodate especially large or small values.\n", 
        sys.exit()

    # open input file
    print "Opening input file: " + sys.argv[1];
    try:
        input_file = open(sys.argv[1],'rU');
    except:
        print "WARNING!!! Failed to open input file. Exiting.";
        sys.exit()

    # set the input columns
    x_col = 0;
    y_col = 1;
    y_err_col = 2;
    vb_flag = -1;
    if(len(sys.argv) > 2):
        x_col = int(sys.argv[2]);
        y_col = int(sys.argv[3]);
        if(len(sys.argv) >= 4):
            for i in range(4,len(sys.argv)):
                if(str(sys.argv[i]) == "-v"):
                    vb_flag = 0;
                elif(str(sys.argv[i]) == "-vv"):
                    vb_flag = 1;
                else:
                    y_err_col = int(sys.argv[4]);

    # initialise x_vals, y_vals and y_errs lists
    x_vals = [];
    y_vals = [];
    y_errs = [];

    # read input file into three arrays: x_vals, y_vals and y_errs
    print "Reading columns " + str(x_col) + "," + str(y_col) + "," + str(y_err_col) + " into x_vals, y_vals and y_errs.";
    for line in input_file:
        match = re.search(r'^#',line);
        if(match == None):
            row = line.split();
            x_vals.append(float(row[x_col]));
            y_vals.append(float(row[y_col]));
            y_errs.append(float(row[y_err_col]));

    # close the input file
    print "Closing input file: " + sys.argv[1];
    input_file.close();

    # call the Busy Function fitting routine 
    # 1. Set the x-range containing signal (VERY conservative --- set to limits of data)
    x_min = x_vals[0] + (0.05 * (x_vals[(len(x_vals) - 1)] - x_vals[0]));
    x_max = x_vals[0] + (0.95 * (x_vals[(len(x_vals) - 1)] - x_vals[0]));
    print "Calling BusyFunc.fit with vb_flag 0, x_min = " + str(x_min) + " & x_max = " + str(x_max); 
    # 2. Call the BusyFunc.fit function in the BusyFunc module 
    fit_type, dim, fit_params, fit_covar = BusyFunc.fit(x_vals,y_vals,y_errs,vb_flag,x_min,x_max,1000,30);

    # refine the Busy Function fit
    fit_type, dim, fit_params, fit_covar = BusyFunc.refine(x_vals,y_vals,y_errs,vb_flag,3000,fit_params)

    # print the BF fitting results to the terminal
    print "Busy Function fit results (fit type = " + str(fit_type) + ", " + str(dim) + " dimensions):";
    i = 0
    for i in range(8):
        print str(fit_params[(2 * i)]) + " +/- " + str(fit_params[((2 * i) + 1)]) + ", ",
    print "chi^2 = " + str(fit_params[16]);
    print "Busy Function fit covariance matrix:";
    j = 0
    for j in range(8):
        i = 0
        for i in range(8):
            print str(fit_covar[j][i]) + " ",
        print "";

    # generate 10,000 random BF fit variants
    rand_fits = BusyFunc.rand_fits(10000,fit_type,fit_params,fit_covar,x_min,x_max,vb_flag)

    # calculate observational values for each random BF variant
    obs_vals = BusyFunc.obs_vals(rand_fits,x_vals,vb_flag)

    # calculate statistical properties of observational parameters
    obs_stats = BusyFunc.obs_stats(obs_vals,vb_flag)

    # display statistics
    print "Total intensity --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis ";
    i = 0
    for i in range(8):
        print str(obs_stats[0][i]) + " ",
    print "";
    print "Peak intensity --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis ";
    i = 0
    for i in range(8):
        print str(obs_stats[1][i]) + " ",
    print "";
    print "Peak intensity position --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis ";
    i = 0
    for i in range(8):
        print str(obs_stats[2][i]) + " ",
    print "";
    print "W_50 width --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis ";
    i = 0
    for i in range(8):
        print str(obs_stats[3][i]) + " ",
    print "";
    print "W_50 position --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis "; 
    i = 0
    for i in range(8):
        print str(obs_stats[4][i]) + " ",
    print "";
    print "W_20 width --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis ";
    i = 0
    for i in range(8):
        print str(obs_stats[5][i]) + " ",
    print "";
    print "W_20 position --- median, std.dev. (from IQR), min, max, mean, std. dev., skewness, kurtosis ";
    i = 0
    for i in range(8):
        print str(obs_stats[6][i]) + " ",
    print "";

    # calculate a linear approximation of the observational parameter covariance matrix
    approx_errs, approx_obs_covar = BusyFunc.approx_obs_covar(fit_type,x_vals,fit_params,fit_covar,x_min,x_max)

    # display linear approximation of the observational parameter covariance matrix
    print "Observational parameter covariance matrix:";
    j = 0
    for j in range(7):
        i = 0   
        for i in range(7):
            print str(approx_obs_covar[j][i]) + " ",
        print "";
    
    # display corresponding uncertainties in observational parameters
    print "Resultant errors:";
    i = 0
    for i in range(7):
        print str(approx_errs[i]) + " ",
    print "";

# call main() if this python script is called directly
if __name__ == '__main__':
    main();


