#include<iostream>
#include<math.h>
#include<omp.h>
#include<cstdlib>
#include<ctime>

#define IM1 2147483563
#define IM2 2147483399
#define AM (1.0/IM1)
#define IMM1 (IM1-1)
#define IA1 40014
#define IA2 40692
#define IQ1 53668
#define IQ2 52774
#define IR1 12211
#define IR2 3791
#define NTAB 32
#define NDIV (1+IMM1/NTAB)
#define EPS 1.2e-307
#define RNMX (1.0-EPS)

static float sqrarg;
#define SQR(a) ((sqrarg=(a)) == 0.0 ? 0.0 : sqrarg*sqrarg)
static float minarg1,minarg2;
#define FMIN(a,b) (minarg1=(a),minarg2=(b),(minarg1) < (minarg2) ? (minarg1) : (minarg2))
static float maxarg1,maxarg2;
#define FMAX(a,b) (maxarg1=(a),maxarg2=(b),(maxarg1) > (maxarg2) ? (minarg1) : (minarg2))
static int iminarg1,iminarg2;
#define IMIN(a,b) (iminarg1=(a),iminarg2=(b),(iminarg1) < (iminarg2) ? (iminarg1) : (iminarg2))
static int imaxarg1,imaxarg2;
#define IMAX(a,b) (imaxarg1=(a),imaxarg2=(b),(imaxarg1) > (imaxarg2) ? (imaxarg1) : (imaxarg2))
#define SIGN(a,b) ((b) >= 0.0 ? fabs(a) : -fabs(a))
#define SWAP(a,b) {temp=(a);(a)=(b);(b)=temp;};
#define TINY 1.0e-20;

void BusyFunc(double x, double a[], double *y, double dyda[], int fit_mode, double mid, double amp);

template <class T_count, class T_xvals, class T_data>
  void FitBusyFunc_engine(T_count NOvals, T_xvals * x_vals, T_data * y_vals, T_data * n_vals, double * model_params, int fit_mode, int NOs, double ** start_vals, double mid, double amp, double ** fit_covar, int vb_flag){

  void BusyFunc(double x, double a[], double *y, double dyda[], int fit_mode, double mid, double amp);
  double ran2(long &idum);
  double chi2_best, chi2_sum, prev_chi2_val, chi2_val, ** best_params, *** best_fit_covar, * model_vals, model_max, y_max;
  // c arrays keep track of the following
  // c1 -- global scaling ---> re-mapped to exp(global scaling)
  // c2 -- first erff slope 
  // c3 -- first erff position ---> re-mapped to mid + amp * sin()
  // c4 -- second erff slope
  // c5 -- second erff position ---> re-mapped to mid + amp * sin()
  // c6 -- power-law scaling ---> re-mapped to exp(power-law scaling)
  // c7 -- power-law position
  // c8 -- power-law exponent ---> re-mapped to 5 + 3 * sin()
  int i, j, c[8], NOc[8], SVD_flag, btr_cnt, thrd, NOthrd;
  double c_val[8], c_min[8], c_max[8], c_step[8];    
  // variables used to do LVM optimisation
  double * alamda, ** a;
  long int seed;
  int ma = 8, iter, ** ia, s, s_done, iter_max = 30;
  double *** covar, *** alpha;
  void (*funcs)(double x, double a[], double *y, double dyda[], int fit_mode, double mid, double amp);
  funcs = &BusyFunc;
  // variables used to show start seed progress
  double progress;
  // variables used to implement MRQMIN using multi-threading
  int mfit;
  double ochisq, ** atry, ** beta, ** da, *** oneda;

  // 0. test the range of model_params
  for(i = 0; i < 17; i++){

    if(isinf(model_params[i])){ model_params[i] = (model_params[i] > 0.0) ? 9E30 : -9E30; }
    if(isnan(model_params[i])){ model_params[i] = 0.1; }

  }

  // 1. set the number of values to be used for each variable
  NOc[0] = 8; // over-all scaling
  NOc[1] = NOc[3] = 13; // roll-off 
  NOc[2] = NOc[4] = 9; // positions of roll-offs
  NOc[5] = 14; // power-law scaling --- minimum is 11, starts at 1E-8 --> powers to 1E3 is 13, maximal is 17 @ 1E7
  NOc[6] = 7; // position of power-law
  NOc[7] = 3; // power-law exponent

  // 2. set values according to input data
  c_min[0] = c_step[0] = (1.0 / ((double) NOc[0])); c_max[0] = 1.0;    
  c_min[1] = c_min[3] = 0.1; c_max[1] = c_max[3] = 10.0; c_step[1] = c_step[3] = 0.5; // this information isn't used in the current implementation --- retained for completeness
  c_min[2] = c_min[4] = c_min[6] = (model_params[4] >= (double) x_vals[0]) ? model_params[4] : (double) x_vals[0]; c_max[2] = c_max[4] = c_max[6] = (model_params[8] <= (double) x_vals[(NOvals - 1)]) ? model_params[8] : (double) x_vals[(NOvals - 1)]; c_step[2] = c_step[4] = c_step[6] = (c_max[2] - c_min[2]) / ((double) NOc[2] - 1.0);
  c_min[5] = -9.0; c_max[5] = 7.0; c_step[5] = 1.0; 
  c_min[7] = 2.0; c_max[7] = 8.0; c_step[7] = 2.0;  

  // 3. If the fit_mode is > 0, use brute force chi^2 sampling to find a new starting point.
  // Otherwise, use the previous starting point in start_vals[].
  if(fit_mode > 0){
    
    // 3.0 Create array model_vals[] used to generate and store curves
    model_vals = new double[NOvals];

    // 3.1. Find the maximum value of the input data
    y_max = -9E20;
    for(i = 0; i < NOvals; i++){ if((double) y_vals[i] >= y_max){ y_max = (double) y_vals[i]; } }

    // 3.2 seed the random number generator
    srand (time(NULL));
    seed = (long) (-1*(rand()));

    // 3.3 randomly generate NOs LVM seed values
    if(vb_flag > 0){

      std::cout << "Generating start seeds . . . " << std::endl;
      std::cout << "0         25        50        75        100%" << std::endl;
      std::cout << "| | | | | : | | | | : | | | | : | | | | :" << std::endl;

    }
    progress = 0.0;
    for(s = 0; s < NOs; s++){

      // randomly pick all the c_val[], then construct a curve and re-scale
      // c_val[0] accordingly
      for(i = 0; i < 8; i++){ 

	c[i] = (int) floor((ran2(seed) * ((double) NOc[i]))); 
	c_val[i] = c_min[i] + (((double) c[i]) * c_step[i]);
	if(isinf(c_val[i])){ c_val[i] = (c_val[i] > 0.0) ? 9E30 : -9E30; }
	if(isnan(c_val[i])){ c_val[i] = 0.0; }
	
      }
      c[4] = c[2] + (int) floor((ran2(seed) * ((double) (NOc[4] - c[2])))); 
      c_val[4] = c_min[4] + (((double) c[4]) * c_step[4]);
      c_val[5] = (c[5] > 0) ? (pow(10.0,c_val[5])) : 0.0;
      if(c[2] == c[4]){ c[6] = 0; }
      c_val[6] = c_val[2] + ((double) c[6] * ((c_val[4] - c_val[2]) / (double)(NOc[6] - 1)));
      for(i = 1; i < 4; i+=2){

	switch (c[i]) {
	case 0:
	  c_val[i] = 0.1;
	  break;
	case 1:
	  c_val[i] = 0.2;
	  break;
	case 2:
	  c_val[i] = 1.6;
	  break;
	case 3:
	  c_val[i] = 6.4;
	  break;
	case 4:
	  c_val[i] = 0.4;
	  break;
	case 5:
	  c_val[i] = 0.8;
	  break;
	case 6:
	  c_val[i] = 3.2;
	  break;
	case 7:
	  c_val[i] = 0.747806 / 1.25;
	  break;
	case 8:
	  c_val[i] = 0.747806 / 2.5;
	  break;
	case 9:
	  c_val[i] = 0.747806 / 5.0;
	  break;
	case 10:
	  c_val[i] = 0.747806 / 10.0;
	  break;
	case 11:
	  c_val[i] = 0.747806 / 15.0;
	  break;
	case 12:
	  c_val[i] = 0.747806 / 20.0;
	default:
	  c_val[i] = 10.0;
	  break;
	}

      }

      // test range of c_val[]
      for(i = 0; i < 8; i++){ 

	if(isinf(c_val[i])){ c_val[i] = (c_val[i] > 0.0) ? 9E30 : -9E30; }
	if(isnan(c_val[i])){ c_val[i] = 0.0; }
	
      }      

      // calculate curve
      model_max = -9E20;
      for(i = 0; i < NOvals; i++){
	
	model_vals[i] = 0.25 * 1E-3 * (1.0 + erff((c_val[1] * ((double) x_vals[i] - c_val[2])))) * (1.0 + erff((c_val[3] * (c_val[4] - (double) x_vals[i])))) * (1.0 + (c_val[5] * (pow((fabs((double) x_vals[i] - c_val[6])),c_val[7]))));
	if(isnan(model_vals[i])){ model_vals[i] = 0.0; }
	if(isinf(model_vals[i])){ model_vals[i] = (model_vals[i] > 0.0) ? 9E30 : -9E30; } 
	if(model_vals[i] >= model_max){ model_max = model_vals[i]; }
	
	// for(i = 0; i < NOvals; i++)
      }
		      
      // calculate chi^2
      chi2_sum = 0.0;
      for(i = 0; i < NOvals; i++){
	
	chi2_val = (double) y_vals[i] - (c_val[0] * y_max * model_vals[i] / model_max);
	chi2_val = chi2_val * chi2_val;
	if((!(isnan(chi2_val))) && (!(isinf(chi2_val)))){
	  
	  chi2_sum+=chi2_val;
	  
	} else if(isinf(chi2_val)){ chi2_sum+=1E20; }
	
	// for(i = 0; i < NOvals; i++)
      }
     
      if(isinf(chi2_sum)){ chi2_sum = (chi2_sum > 0.0) ? 9E30 : -9E30; }

      // re-scale c_val[0] and c_val[5]
      c_val[0]*=(y_max * 1E-3 / model_max);
      c_val[5]*=(y_max * 1E-3 / model_max);

      // update start_vals
      for(i = 0; i < 8; i++){ start_vals[s][i] = c_val[i]; }
      start_vals[s][8] = chi2_sum;

      // display progress
      if(vb_flag > 0){ while((((float) (s + 1)) / ((float) NOs)) >= progress){ std::cout << "*" << std::flush; progress+=0.025; } }

      // for(s = 0; s < NOs; s++)
    }
    if(vb_flag > 0){ std::cout << " done." << std::endl; }
  
    // 3.4 free up memory
    delete [] model_vals;
    model_vals = NULL;
    
    // if(fit_mode > 0)
  } else {

    if(vb_flag > 0){ std::cout << "Using existing LVM starting seeds . . . " << std::endl; }

  }
 
  // 4. Try to optimise each starting position using the Levenberg-Marquardt algorithm 
  // --- implemented using SVD --- and retain the global chi^2 minium
  NOthrd = omp_get_max_threads();
  if(vb_flag > 0){ std::cout << "Using " << NOthrd << " threads across " << omp_get_num_procs() << " cores . . . " << std::endl; }
  ia = new int * [NOthrd];
  alamda = new double[NOthrd];
  a = new double * [NOthrd];
  covar = new double ** [NOthrd];
  alpha = new double ** [NOthrd];
  best_params = new double * [NOthrd];
  best_fit_covar = new double ** [NOthrd];
  atry = new double * [NOthrd];
  beta = new double * [NOthrd];
  da = new double * [NOthrd];
  oneda = new double ** [NOthrd];
  for(thrd = 0; thrd < NOthrd; thrd++){
    a[thrd] = new double[8];
    covar[thrd] = new double * [8];
    alpha[thrd] = new double * [8];
    ia[thrd] = new int[8];
    best_params[thrd] = new double[17];
    best_fit_covar[thrd] = new double * [8];
    atry[thrd] = new double[8];
    beta[thrd] = new double[8];
    da[thrd] = new double[8];
    oneda[thrd] = new double * [8];
    for(i = 0; i < 8; i++){
      
      covar[thrd][i] = new double[8];
      alpha[thrd][i] = new double[8];
      best_fit_covar[thrd][i] = new double[8];
      oneda[thrd][i] = new double;

    }

  }

  // de-bugging: create arrays to track the threads
  int * seed_count = new int[NOthrd];
  for(thrd = 0; thrd < NOthrd; thrd++){ seed_count[thrd] = 0; }

  if(vb_flag > 0){

    std::cout << "Applying LVM to start seeds . . . " << std::endl;
    std::cout << "0         25        50        75        100%" << std::endl;
    std::cout << "| | | | | : | | | | : | | | | : | | | | :" << std::endl;

  }
  progress = 0.0;
  SVD_flag = -1;
  s_done = 0;
  chi2_best = -99.0;
#pragma omp parallel for if(omp_get_max_threads() > 1) schedule(dynamic,5) default(shared) private(thrd,i,j,ma,prev_chi2_val,chi2_val,iter,btr_cnt,mfit,ochisq) firstprivate(chi2_best) reduction(||:SVD_flag)
  for(s = 0; s < NOs; s++){

    // get thread number
    thrd = omp_get_thread_num();
    
    // de-bugging: increment the number of seeds processed by this thread
    seed_count[thrd]++; 

    // 4a. use fit_mode to set the number of free parameters and initialise a[] array
    for(i = 0; i < 8; i++){ ia[thrd][i] = 1; }
    fit_mode = abs(fit_mode);
    switch(fit_mode){
    case 1:    
      ma = 4;
      if(start_vals[s][0] > 0.0){ a[thrd][0] = log(start_vals[s][0]); } else { a[thrd][0] = -9E10; }
      if(start_vals[s][1] > 0.0){ a[thrd][1] = log(start_vals[s][1]); } else { a[thrd][1] = -9E10; }
      a[thrd][2] = (start_vals[s][2] - mid)/amp;
      if(a[thrd][2] > 1.0){ a[thrd][2] = 1.0; }
      if(a[thrd][2] < -1.0){ a[thrd][2] = -1.0; }
      a[thrd][2] = asin(a[thrd][2]);
      a[thrd][3] = (start_vals[s][4] - mid)/amp;
      if(a[thrd][3] > 1.0){ a[thrd][3] = 1.0; }
      if(a[thrd][3] < -1.0){ a[thrd][3] = -1.0; }
      a[thrd][3] = asin(a[thrd][3]);
      a[thrd][4] = a[thrd][5] = a[thrd][6] = a[thrd][7] = 0.0;
      break;
    case 2:    
      ma = 5;
      if(start_vals[s][0] > 0.0){ a[thrd][0] = log(start_vals[s][0]); } else { a[thrd][0] = -9E10; }
      if(start_vals[s][1] > 0.0){ a[thrd][1] = log(start_vals[s][1]); } else { a[thrd][1] = -9E10; }
      a[thrd][2] = (start_vals[s][2] - mid)/amp;
      if(a[thrd][2] > 1.0){ a[thrd][2] = 1.0; }
      if(a[thrd][2] < -1.0){ a[thrd][2] = -1.0; }
      a[thrd][2] = asin(a[thrd][2]);
      if(start_vals[s][3] > 0.0){ a[thrd][3] = log(start_vals[s][3]); } else { a[thrd][3] = -9E10; }
      a[thrd][4] = (start_vals[s][4] - mid)/amp;
      if(a[thrd][4] > 1.0){ a[thrd][4] = 1.0; }
      if(a[thrd][4] < -1.0){ a[thrd][4] = -1.0; }
      a[thrd][4] = asin(a[thrd][4]);
      a[thrd][5] = a[thrd][6] = a[thrd][7] = 0.0;
      break;
    case 3:    
      ma = 5;
      if(start_vals[s][0] > 0.0){ a[thrd][0] = log(start_vals[s][0]); } else { a[thrd][0] = -9E10; }
      if(start_vals[s][1] > 0.0){ a[thrd][1] = log(start_vals[s][1]); } else { a[thrd][1] = -9E10; }
      a[thrd][2] = (start_vals[s][2] - mid)/amp;
      if(a[thrd][2] > 1.0){ a[thrd][2] = 1.0; }
      if(a[thrd][2] < -1.0){ a[thrd][2] = -1.0; }
      a[thrd][2] = asin(a[thrd][2]);
      a[thrd][3] = (start_vals[s][4] - mid)/amp;
      if(a[thrd][3] > 1.0){ a[thrd][3] = 1.0; }
      if(a[thrd][3] < -1.0){ a[thrd][3] = -1.0; }
      a[thrd][3] = asin(a[thrd][3]);
      if(start_vals[s][5] > 0.0){ a[thrd][4] = log(start_vals[s][5]); } else { a[thrd][4] = -9E10; }
      a[thrd][5] = a[thrd][6] = a[thrd][7] = 0.0;
      break;
    case 4:
      ma = 6;
      if(start_vals[s][0] > 0.0){ a[thrd][0] = log(start_vals[s][0]); } else { a[thrd][0] = -9E10; }
      if(start_vals[s][1] > 0.0){ a[thrd][1] = log(start_vals[s][1]); } else { a[thrd][1] = -9E10; }
      a[thrd][2] = (start_vals[s][2] - mid)/amp;
      if(a[thrd][2] > 1.0){ a[thrd][2] = 1.0; }
      if(a[thrd][2] < -1.0){ a[thrd][2] = -1.0; }
      a[thrd][2] = asin(a[thrd][2]);
      a[thrd][3] = (start_vals[s][4] - mid)/amp;
      if(a[thrd][3] > 1.0){ a[thrd][3] = 1.0; }
      if(a[thrd][3] < -1.0){ a[thrd][3] = -1.0; }
      a[thrd][3] = asin(a[thrd][3]);
      if(start_vals[s][5] > 0.0){ a[thrd][4] = log(start_vals[s][5]); } else { a[thrd][4] = -9E10; }
      a[thrd][5] = (start_vals[s][7] - 5.0)/3.0;
      if(a[thrd][5] > 1.0){ a[thrd][5] = 1.0; }
      if(a[thrd][5] < -1.0){ a[thrd][5] = -1.0; }
      a[thrd][5] = asin(a[thrd][5]);
      a[thrd][6] = a[thrd][7] = 0.0;
      break;
    case 5:
      ma = 7;
      if(start_vals[s][0] > 0.0){ a[thrd][0] = log(start_vals[s][0]); } else { a[thrd][0] = -9E10; }
      if(start_vals[s][1] > 0.0){ a[thrd][1] = log(start_vals[s][1]); } else { a[thrd][1] = -9E10; }
      a[thrd][2] = (start_vals[s][2] - mid)/amp;
      if(a[thrd][2] > 1.0){ a[thrd][2] = 1.0; }
      if(a[thrd][2] < -1.0){ a[thrd][2] = -1.0; }
      a[thrd][2] = asin(a[thrd][2]);
      a[thrd][3] = (start_vals[s][4] - mid)/amp;
      if(a[thrd][3] > 1.0){ a[thrd][3] = 1.0; }
      if(a[thrd][3] < -1.0){ a[thrd][3] = -1.0; }
      a[thrd][3] = asin(a[thrd][3]);
      if(start_vals[s][5] > 0.0){ a[thrd][4] = log(start_vals[s][5]); } else { a[thrd][4] = -9E10; }
      a[thrd][5] = (start_vals[s][6] - mid)/amp;
      if(a[thrd][5] > 1.0){ a[thrd][5] = 1.0; }
      if(a[thrd][5] < -1.0){ a[thrd][5] = -1.0; }
      a[thrd][5] = asin(a[thrd][5]);
      a[thrd][6] = (start_vals[s][7] - 5.0)/3.0;
      if(a[thrd][6] > 1.0){ a[thrd][6] = 1.0; }
      if(a[thrd][6] < -1.0){ a[thrd][6] = -1.0; }
      a[thrd][6] = asin(a[thrd][6]);
      a[thrd][7] = 0.0;
      break;
    default:
      ma = 8;
      if(start_vals[s][0] > 0.0){ a[thrd][0] = log(start_vals[s][0]); } else { a[thrd][0] = -9E10; }
      if(start_vals[s][1] > 0.0){ a[thrd][1] = log(start_vals[s][1]); } else { a[thrd][1] = -9E10; }
      a[thrd][2] = (start_vals[s][2] - mid)/amp;
      if(a[thrd][2] > 1.0){ a[thrd][2] = 1.0; }
      if(a[thrd][2] < -1.0){ a[thrd][2] = -1.0; }
      a[thrd][2] = asin(a[thrd][2]);
      if(start_vals[s][3] > 0.0){ a[thrd][3] = log(start_vals[s][3]); } else { a[thrd][3] = -9E10; }
      a[thrd][4] = (start_vals[s][4] - mid)/amp;
      if(a[thrd][4] > 1.0){ a[thrd][4] = 1.0; }
      if(a[thrd][4] < -1.0){ a[thrd][4] = -1.0; }
      a[thrd][4] = asin(a[thrd][4]);
      if(start_vals[s][5] > 0.0){ a[thrd][5] = log(start_vals[s][5]); } else { a[thrd][5] = -9E10; }
      a[thrd][6] = (start_vals[s][6] - mid)/amp;
      if(a[thrd][6] > 1.0){ a[thrd][6] = 1.0; }
      if(a[thrd][6] < -1.0){ a[thrd][6] = -1.0; }
      a[thrd][6] = asin(a[thrd][6]);
      a[thrd][7] = (start_vals[s][7] - 5.0)/3.0;
      if(a[thrd][7] > 1.0){ a[thrd][7] = 1.0; }
      if(a[thrd][7] < -1.0){ a[thrd][7] = -1.0; }
      a[thrd][7] = asin(a[thrd][7]);
      break;
    }
    
    // de-bugging: display initial a[] values
    if((thrd == 0) && (s < 3)){ std::cout << "\nInitial a[] values for thrd = " << thrd << " and s = " << s << ": " << a[thrd][0] << " " << a[thrd][1] << " " << a[thrd][2] << " " << a[thrd][3] << " " << a[thrd][4] << " " << a[thrd][5] << " " << a[thrd][6] << " " << a[thrd][7] << std::endl; }

    // 4b. iterate until convergence is achieved for this starting position
    alamda[thrd] = prev_chi2_val = chi2_val = -99.0;
    iter = btr_cnt = 0;
    while((prev_chi2_val < 0.0) || (chi2_val >= prev_chi2_val) || ((prev_chi2_val - chi2_val) > (prev_chi2_val * 1E-4)) || (chi2_val > 8.999E30) || (btr_cnt < 5)){
      
      prev_chi2_val = chi2_val;
      SVD_flag = mrqmin(x_vals,y_vals,n_vals,NOvals,a[thrd],ia[thrd],ma,covar[thrd],alpha[thrd],&chi2_val,funcs,&alamda[thrd],fit_mode,mid,amp,mfit,ochisq,atry[thrd],beta[thrd],da[thrd],oneda[thrd]);
      if(isinf(chi2_val)){ chi2_val = (chi2_val > 0.0) ? 9E30 : prev_chi2_val + 1.0; }
      if(isnan(chi2_val)){ chi2_val = prev_chi2_val + 1.0; }
      if(chi2_val <= prev_chi2_val){ btr_cnt++; } else { btr_cnt = 0; }
      iter++;

      // de-bugging: display current results for thrd = 0
      if((thrd == 0) && (s < 3)){ std::cout << "thrd = " << thrd << " of " << NOthrd << " and s = " << s << ": iter = " << iter << "; chi2 = " << chi2_val << ", prev_chi2 = " << prev_chi2_val << " & btr_cnt = " << btr_cnt << " ---> fit: " << a[thrd][0] << " " << a[thrd][1] << " " << a[thrd][2] << " " << a[thrd][3] << " " << a[thrd][4] << " " << a[thrd][5] << " " << a[thrd][6] << " " << a[thrd][7] << std::endl; }

      if(iter >= iter_max){ break; }
      
    }
      
    // 4c. calculate final covariance matrix
    alamda[thrd] = -1.0;
    SVD_flag = mrqmin(x_vals,y_vals,n_vals,NOvals,a[thrd],ia[thrd],ma,covar[thrd],alpha[thrd],&chi2_val,funcs,&alamda[thrd],fit_mode,mid,amp,mfit,ochisq,atry[thrd],beta[thrd],da[thrd],oneda[thrd]);
    if(isinf(chi2_val)){ chi2_val = (chi2_val > 0.0) ? 9E30 : prev_chi2_val + 1.0; }
    if(isnan(chi2_val)){ chi2_val = prev_chi2_val + 1.0; }
    
    if((chi2_val > 0.0) && ((chi2_val < chi2_best) || (chi2_best < 0.0))){
            
      chi2_best = chi2_val;
           
      for(i = 0; i < 8; i++){
	for(j = 0; j < 8; j++){  
	  best_fit_covar[thrd][i][j] = 0.0;
	}
      }
           
      best_params[thrd][0] = exp(a[thrd][0]);
      if(isinf(best_params[thrd][0])){ best_params[thrd][0] = (best_params[thrd][0] > 0.0) ? 9E30 : -9E30; }
      if(isnan(best_params[thrd][0])){ best_params[thrd][0] = 0.0; }
      best_params[thrd][1] = best_params[thrd][0] * sqrt(covar[thrd][0][0]);
      switch(fit_mode){
      case 1:
	best_params[thrd][2] = exp(a[thrd][1]);
	if(isinf(best_params[thrd][2])){ best_params[thrd][2] = (best_params[thrd][2] > 0.0) ? 9E30 : -9E30; }
	if(isnan(best_params[thrd][2])){ best_params[thrd][2] = 0.0; }
	best_params[thrd][3] = best_params[thrd][2] * sqrt(covar[thrd][1][1]);
	best_params[thrd][4] = mid + (amp * (sin(a[thrd][2])));
	best_params[thrd][5] = amp * (cos(a[thrd][2])) * (sqrt(covar[thrd][2][2]));
	best_params[thrd][6] = best_params[thrd][2];
	best_params[thrd][7] = best_params[thrd][3];
	best_params[thrd][8] = mid + (amp * (sin(a[thrd][3])));
	best_params[thrd][9] = amp * (cos(a[thrd][3])) * (sqrt(covar[thrd][3][3]));
	best_params[thrd][10] = 0.0;
	best_params[thrd][11] = 0.0;
	best_params[thrd][12] = 0.5 * (best_params[thrd][4] + best_params[thrd][8]);
	best_params[thrd][13] = 0.0;
	best_params[thrd][14] = 4.0;
	best_params[thrd][15] = 0.0;
	best_params[thrd][16] = chi2_val;
	for(i = 0; i < 4; i++){
	  for(j = 0; j < 4; j++){
	    best_fit_covar[thrd][i][j] = covar[thrd][i][j];
	  }
	}
	for(j = 7; j > 3; j--){
	  best_fit_covar[thrd][j][j] = best_fit_covar[thrd][(j - 1)][(j - 1)];
	  for(i = 0; i < j; i++){ best_fit_covar[thrd][i][j] = best_fit_covar[thrd][i][(j - 1)]; }
	  for(i = 0; i < j; i++){ best_fit_covar[thrd][j][i] = best_fit_covar[thrd][(j - 1)][i]; }
	}
	for(i = 0; i < 8; i++){ best_fit_covar[thrd][i][3] = best_fit_covar[thrd][3][i] = best_fit_covar[thrd][i][5] = best_fit_covar[thrd][5][i] = best_fit_covar[thrd][i][6] = best_fit_covar[thrd][6][i] = best_fit_covar[thrd][i][7] = best_fit_covar[thrd][7][i] = 0.0; }
	break;
      case 2:
	best_params[thrd][2] = exp(a[thrd][1]);
	if(isinf(best_params[thrd][2])){ best_params[thrd][2] = (best_params[thrd][2] > 0.0) ? 9E30 : -9E30; }
	if(isnan(best_params[thrd][2])){ best_params[thrd][2] = 0.0; }
	best_params[thrd][3] = best_params[thrd][2] * sqrt(covar[thrd][1][1]);
	best_params[thrd][4] = mid + (amp * (sin(a[thrd][2])));
	best_params[thrd][5] = amp * (cos(a[thrd][2])) * (sqrt(covar[thrd][2][2]));
	best_params[thrd][6] = exp(a[thrd][3]);
	if(isinf(best_params[thrd][6])){ best_params[thrd][6] = (best_params[thrd][6] > 0.0) ? 9E30 : -9E30; }
	if(isnan(best_params[thrd][6])){ best_params[thrd][6] = 0.0; }
	best_params[thrd][7] = best_params[thrd][6] * sqrt(covar[thrd][3][3]);
	best_params[thrd][8] = mid + (amp * (sin(a[thrd][4])));
	best_params[thrd][9] = amp * (cos(a[thrd][4])) * (sqrt(covar[thrd][4][4]));
	best_params[thrd][10] = 0.0;
	best_params[thrd][11] = 0.0;
	best_params[thrd][12] = 0.5 * (best_params[thrd][4] + best_params[thrd][8]);
	best_params[thrd][13] = 0.0;
	best_params[thrd][14] = 4.0;
	best_params[thrd][15] = 0.0;
	best_params[thrd][16] = chi2_val;
	for(i = 0; i < 5; i++){
	  for(j = 0; j < 5; j++){
	    best_fit_covar[thrd][i][j] = covar[thrd][i][j];
	  }
	}
	for(i = 0; i < 8; i++){ best_fit_covar[thrd][i][5] = best_fit_covar[thrd][5][i] = best_fit_covar[thrd][i][6] = best_fit_covar[thrd][6][i] = best_fit_covar[thrd][i][7] = best_fit_covar[thrd][7][i] = 0.0; }
	break;
      case 3:
	best_params[thrd][2] = exp(a[thrd][1]);
	if(isinf(best_params[thrd][2])){ best_params[thrd][2] = (best_params[thrd][2] > 0.0) ? 9E30 : -9E30; }
	if(isnan(best_params[thrd][2])){ best_params[thrd][2] = 0.0; }
	best_params[thrd][3] = best_params[thrd][2] * sqrt(covar[thrd][1][1]);
	best_params[thrd][4] = mid + (amp * (sin(a[thrd][2])));
	best_params[thrd][5] = amp * (cos(a[thrd][2])) * (sqrt(covar[thrd][2][2]));
	best_params[thrd][6] = best_params[thrd][2];
	best_params[thrd][7] = best_params[thrd][3];
	best_params[thrd][8] = mid + (amp * (sin(a[thrd][3])));
	best_params[thrd][9] = amp * (cos(a[thrd][3])) * (sqrt(covar[thrd][3][3]));
	best_params[thrd][10] = exp(a[thrd][4]);
	if(isinf(best_params[thrd][10])){ best_params[thrd][10] = (best_params[thrd][10] > 0.0) ? 9E30 : -9E30; }
	if(isnan(best_params[thrd][10])){ best_params[thrd][10] = 0.0; }
	best_params[thrd][11] = best_params[thrd][10] * sqrt(covar[thrd][4][4]);
	best_params[thrd][12] = 0.5 * (best_params[thrd][4] + best_params[thrd][8]);
	best_params[thrd][13] = 0.0;
	best_params[thrd][14] = 4.0;
	best_params[thrd][15] = 0.0;
	best_params[thrd][16] = chi2_val;
	for(i = 0; i < 5; i++){
	  for(j = 0; j < 5; j++){
	    best_fit_covar[thrd][i][j] = covar[thrd][i][j];
	  }
	}
	for(j = 7; j > 3; j--){
	  best_fit_covar[thrd][j][j] = best_fit_covar[thrd][(j - 1)][(j - 1)];
	  for(i = 0; i < j; i++){ best_fit_covar[thrd][i][j] = best_fit_covar[thrd][i][(j - 1)]; }
	  for(i = 0; i < j; i++){ best_fit_covar[thrd][j][i] = best_fit_covar[thrd][(j - 1)][i]; }
	}
	for(i = 0; i < 8; i++){ best_fit_covar[thrd][i][3] = best_fit_covar[thrd][3][i] = best_fit_covar[thrd][i][6] = best_fit_covar[thrd][6][i] = best_fit_covar[thrd][i][7] = best_fit_covar[thrd][7][i] = 0.0; }
	break;
      case 4:
	best_params[thrd][2] = exp(a[thrd][1]);
	if(isinf(best_params[thrd][2])){ best_params[thrd][2] = (best_params[thrd][2] > 0.0) ? 9E30 : -9E30; }
	if(isnan(best_params[thrd][2])){ best_params[thrd][2] = 0.0; }
	best_params[thrd][3] = best_params[thrd][2] * sqrt(covar[thrd][1][1]);
	best_params[thrd][4] = mid + (amp * (sin(a[thrd][2])));
	best_params[thrd][5] = amp * (cos(a[thrd][2])) * (sqrt(covar[thrd][2][2]));
	best_params[thrd][6] = best_params[thrd][2];
	best_params[thrd][7] = best_params[thrd][3];
	best_params[thrd][8] = mid + (amp * (sin(a[thrd][3])));
	best_params[thrd][9] = amp * (cos(a[thrd][3])) * (sqrt(covar[thrd][3][3]));
	best_params[thrd][10] = exp(a[thrd][4]);
	if(isinf(best_params[thrd][10])){ best_params[thrd][10] = (best_params[thrd][10] > 0.0) ? 9E30 : -9E30; }
	if(isnan(best_params[thrd][10])){ best_params[thrd][10] = 0.0; }
	best_params[thrd][11] = best_params[thrd][10] * sqrt(covar[thrd][4][4]);
	best_params[thrd][12] = 0.5 * (best_params[thrd][4] + best_params[thrd][8]);
	best_params[thrd][13] = 0.0;
	best_params[thrd][14] = 5.0 + (3.0 * (sin(a[thrd][5])));
	best_params[thrd][15] = amp * (cos(a[thrd][5])) * (sqrt(covar[thrd][5][5]));
	best_params[thrd][16] = chi2_val;
	for(i = 0; i < 6; i++){
	  for(j = 0; j < 6; j++){
	    best_fit_covar[thrd][i][j] = covar[thrd][i][j];
	  }
	}
	for(j = 7; j > 3; j--){
	  best_fit_covar[thrd][j][j] = best_fit_covar[thrd][(j - 1)][(j - 1)];
	  for(i = 0; i < j; i++){ best_fit_covar[thrd][i][j] = best_fit_covar[thrd][i][(j - 1)]; }
	  for(i = 0; i < j; i++){ best_fit_covar[thrd][j][i] = best_fit_covar[thrd][(j - 1)][i]; }
	}
	for(j = 7; j > 5; j--){
	  best_fit_covar[thrd][j][j] = best_fit_covar[thrd][(j - 1)][(j - 1)];
	  for(i = 0; i < j; i++){ best_fit_covar[thrd][i][j] = best_fit_covar[thrd][i][(j - 1)]; }
	  for(i = 0; i < j; i++){ best_fit_covar[thrd][j][i] = best_fit_covar[thrd][(j - 1)][i]; }
	}
	for(i = 0; i < 8; i++){ best_fit_covar[thrd][i][3] = best_fit_covar[thrd][3][i] = best_fit_covar[thrd][i][6] = best_fit_covar[thrd][6][i] = 0.0; }
	break;
      case 5:
	best_params[thrd][2] = exp(a[thrd][1]);
	if(isinf(best_params[thrd][2])){ best_params[thrd][2] = (best_params[thrd][2] > 0.0) ? 9E30 : -9E30; }
	if(isnan(best_params[thrd][2])){ best_params[thrd][2] = 0.0; }
	best_params[thrd][3] = best_params[thrd][2] * sqrt(covar[thrd][1][1]);
	best_params[thrd][4] = mid + (amp * (sin(a[thrd][2])));
	best_params[thrd][5] = amp * (cos(a[thrd][2])) * (sqrt(covar[thrd][2][2]));
	best_params[thrd][6] = best_params[thrd][2];
	best_params[thrd][7] = best_params[thrd][3];
	best_params[thrd][8] = mid + (amp * (sin(a[thrd][3])));
	best_params[thrd][9] = amp * (cos(a[thrd][3])) * (sqrt(covar[thrd][3][3]));
	best_params[thrd][10] = exp(a[thrd][4]);
	if(isinf(best_params[thrd][10])){ best_params[thrd][10] = (best_params[thrd][10] > 0.0) ? 9E30 : -9E30; }
	if(isnan(best_params[thrd][10])){ best_params[thrd][10] = 0.0; }
	best_params[thrd][11] = best_params[thrd][10] * sqrt(covar[thrd][4][4]);
	best_params[thrd][12] = mid + (amp * (sin(a[thrd][5])));
	best_params[thrd][13] = amp * (cos(a[thrd][5])) * (sqrt(covar[thrd][5][5]));
	best_params[thrd][14] = 5.0 + (3.0 * (sin(a[thrd][6])));
	best_params[thrd][15] = amp * (cos(a[thrd][6])) * (sqrt(covar[thrd][6][6]));
	best_params[thrd][16] = chi2_val;
	for(i = 0; i < 7; i++){
	  for(j = 0; j < 7; j++){
	    best_fit_covar[thrd][i][j] = covar[thrd][i][j];
	  }
	}
	for(j = 7; j > 3; j--){
	  best_fit_covar[thrd][j][j] = best_fit_covar[thrd][(j - 1)][(j - 1)];
	  for(i = 0; i < j; i++){ best_fit_covar[thrd][i][j] = best_fit_covar[thrd][i][(j - 1)]; }
	  for(i = 0; i < j; i++){ best_fit_covar[thrd][j][i] = best_fit_covar[thrd][(j - 1)][i]; }
	}
	for(i = 0; i < 8; i++){ best_fit_covar[thrd][i][3] = best_fit_covar[thrd][3][i] = 0.0; }
	break;
      default:
	best_params[thrd][2] = exp(a[thrd][1]);
	if(isinf(best_params[thrd][2])){ best_params[thrd][2] = (best_params[thrd][2] > 0.0) ? 9E30 : -9E30; }
	if(isnan(best_params[thrd][2])){ best_params[thrd][2] = 0.0; }
	best_params[thrd][3] = best_params[thrd][2] * sqrt(covar[thrd][1][1]);
	best_params[thrd][4] = mid + (amp * (sin(a[thrd][2])));
	best_params[thrd][5] = amp * (cos(a[thrd][2])) * (sqrt(covar[thrd][2][2]));
	best_params[thrd][6] = exp(a[thrd][3]);
	if(isinf(best_params[thrd][6])){ best_params[thrd][6] = (best_params[thrd][6] > 0.0) ? 9E30 : -9E30; }
	if(isnan(best_params[thrd][6])){ best_params[thrd][6] = 0.0; }
	best_params[thrd][7] = best_params[thrd][6] * sqrt(covar[thrd][3][3]);
	best_params[thrd][8] = mid + (amp * (sin(a[thrd][4])));
	best_params[thrd][9] = amp * (cos(a[thrd][4])) * (sqrt(covar[thrd][4][4]));
	best_params[thrd][10] = exp(a[thrd][5]);
	if(isinf(best_params[thrd][10])){ best_params[thrd][10] = (best_params[thrd][10] > 0.0) ? 9E30 : -9E30; }
	if(isnan(best_params[thrd][10])){ best_params[thrd][10] = 0.0; }
	best_params[thrd][11] = best_params[thrd][10] * sqrt(covar[thrd][5][5]);
	best_params[thrd][12] = mid + (amp * (sin(a[thrd][6])));
	best_params[thrd][13] = amp * (cos(a[thrd][6])) * (sqrt(covar[thrd][6][6]));
	best_params[thrd][14] = 5.0 + (3.0 * (sin(a[thrd][7])));
	best_params[thrd][15] = amp * (cos(a[thrd][7])) * (sqrt(covar[thrd][7][7]));
	best_params[thrd][16] = chi2_val;
	for(i = 0; i < 8; i++){
	  for(j = 0; j < 8; j++){
	    best_fit_covar[thrd][i][j] = covar[thrd][i][j];
	  }
	}
	break;
      }
            
      // if(chi2_val < chi2_best)
    }
    
    // display progress
    if(vb_flag > 0){ 
      #pragma omp critical
      {
	s_done++;
	while((((float) (s_done + 1)) / ((float) NOs)) >= progress){ std::cout << "*" << std::flush; progress+=0.025; } 
      }
    }
      
    // for(s = 0; s < NOs; s++)
  }
  if(vb_flag > 0){ std::cout << " done." << std::endl; }
  
  // de-bugging: display the fitting results obtained by each core
  std::cout << std::endl;
  for(thrd = 0; thrd < NOthrd; thrd++){
    std::cout << "final results for thrd = " << thrd << " after processing " << seed_count[thrd] << " LVM seeds; chi^2 = " << best_params[thrd][16] << " ---> fit values:  ";
    for(i = 0; i < 16; i++){
      std::cout << best_params[thrd][i] << " ";
    }
    std::cout << std::endl;
  }

  // 5. If any starting position succeeded, return the LVM results. Otherwise, return the brute force chi^2 results.

  // update model_params array with the best result across the NOthrd threads
  for(s = 0, thrd = 1; thrd < NOthrd; thrd++){ if(((best_params[s][16] <= 0.0) || (best_params[thrd][16] < best_params[s][16])) && (best_params[thrd][16] > 0.0)){ s = thrd; } }
  for(i = 0; i < 17; i++){ model_params[i] = best_params[s][i]; }
  for(i = 0; i < 8; i++){
    for(j = 0; j < 8; j++){
      fit_covar[i][j] = best_fit_covar[s][i][j];
    }
  }

  // de-bugging: display the best fitting results across the multiple cores
  std::cout << "\nThe best results were obtained by thread = " << s << " which processed " << seed_count[s] << " LVM seeds; chi^2 = " << model_params[16] << " ---> fit values: ";
  for(i = 0; i < 16; i++){
    std::cout << model_params[i] << " ";
  }
  std::cout << std::endl;

  // de-bugging: free up memory used to track LVM seeds processed by each thread
  //delete [] seed_count;

  //std::cout << "6. Freeing up memory . . . " << std::endl;
  delete [] alamda;
  alamda = NULL;
  for(thrd = 0; thrd < NOthrd; thrd++){
    
    for(i = 0; i < 8; i++){

      delete [] covar[thrd][i];
      covar[thrd][i] = NULL;
      delete [] alpha[thrd][i];
      alpha[thrd][i] = NULL;
      delete [] oneda[thrd][i];
      oneda[thrd][i] = NULL;

    }

    delete [] covar[thrd];
    covar[thrd] = NULL;
    delete [] alpha[thrd];
    alpha[thrd] = NULL;
    delete [] a[thrd];
    a[thrd] = NULL;
    delete [] ia[thrd];
    ia[thrd] = NULL;

    delete [] best_params[thrd];
    best_params[thrd] = NULL;
    delete [] best_fit_covar[thrd];
    best_fit_covar[thrd] = NULL;
    delete [] oneda[thrd];
    oneda[thrd] = NULL;
    delete [] da[thrd];
    da[thrd] = NULL;
    delete [] beta[thrd];
    beta[thrd] = NULL;
    delete [] atry[thrd];
    atry[thrd] = NULL;

  }
  delete [] ia;
  ia = NULL;
  delete [] a;
  a = NULL;
  delete [] covar;
  covar = NULL;
  delete [] alpha;
  alpha = NULL;
  delete [] best_params;
  best_params = NULL;
  delete [] best_fit_covar;
  best_fit_covar = NULL;
  delete [] oneda;
  oneda = NULL;
  delete [] da;
  da = NULL;
  delete [] atry;
  atry = NULL;
  delete [] beta;
  beta = NULL;

  return;

}

template <class T_count, class T_xvals, class T_data, class T_result>
  int FitBusyFunc(T_count NOvals, T_xvals * x_vals, T_data * y_vals, T_data * n_vals, T_result * fit_params, T_result ** fit_covar, int vb_flag){

  double model_params[2][17], y_max, y_scale = 1.0, ** start_vals, ** temp_covar, mid, amp;
  int i, j, best_NOp, y_scale_flag, NOs = 1000;

  if(vb_flag >= 0){ std::cout << "Fitting Busy Function . . . " << std::endl; }

  // test the range of fit_params[4] and fit_params[8]
  if(fit_params[4] < x_vals[0]){ fit_params[4] = x_vals[0]; }
  if(fit_params[8] > x_vals[(NOvals - 1)]){ fit_params[8] = x_vals[(NOvals - 1)]; }

  // create arrays 
  temp_covar = new double * [8];
  for(i = 0; i < 8; i++){ temp_covar[i] = new double[8]; }
  start_vals = new double * [NOs];
  for(i = 0; i < NOs; i++){ start_vals[i] = new double[9]; }

  // initialise the mid-point and amplitude used to limit the roll-off and power-law positions during fitting using variable re-mapping
  mid = 0.5 * (double) (fit_params[4] + fit_params[8]);
  amp = 0.5 * (double) (fit_params[8] - fit_params[4]);

  // initialise the fit_params array
  if(vb_flag >= 0){ std::cout << "Initialising fit params to: " << std::flush; }
  for(i = 0; i < 17; i++){ 

    model_params[0][i] = model_params[1][i] = (double) fit_params[i]; 
    if(isinf(model_params[0][i])){ model_params[0][i] = (model_params[0][i] > 0.0) ? 9E30 : -9E30; }
    if(isnan(model_params[0][i])){ model_params[0][i] = 0.0; }
    if(isinf(model_params[1][i])){ model_params[1][i] = (model_params[1][i] > 0.0) ? 9E30 : -9E30; }
    if(isnan(model_params[1][i])){ model_params[1][i] = 0.0; }
    if(vb_flag >= 0){ std::cout << model_params[0][i] << " " << std::flush; }
    
  }
  if(vb_flag >= 0){ std::cout << std::endl; }

  // determine the y-axis range of the input data
  y_max = -9E30;
  for(i = 0; i < NOvals; i++){
    if((fabs((double) y_vals[i])) >= y_max){ y_max = fabs((double) y_vals[i]); }
  }

  // determine if the y-axis needs to be re-scaled and do so 
  // (includes re-scaling model_params[] and fit_params[])
  y_scale_flag = -1;
  if(y_max >= 1E7){

    y_scale = y_max / 1E7;
    if(vb_flag >= 0){ std::cout << "Re-scaling with " << y_scale << " . . . " << std::endl; }
    for(i = 0; i < NOvals; i++){ 

      y_vals[i]/=((T_data) y_scale); 
      n_vals[i]/=((T_data) y_scale);

    }
    model_params[0][0]/=y_scale;
    model_params[1][0]/=y_scale;
    y_scale_flag = 1;

  }
 
  // fit_mode == 1 -- 4 parameters; maximum symmetry and no power-law
  if(vb_flag >= 0){ std::cout << "Trying: fit mode 1 . . .  " << std::endl; }
  FitBusyFunc_engine(NOvals,x_vals,y_vals,n_vals,model_params[0],1,NOs,start_vals,mid,amp,temp_covar,vb_flag);
  for(i = 0; i < 17; i++){
    if(isinf(model_params[0][i])){ model_params[0][i] = (model_params[0][i] > 0.0) ? 9E30 : -9E30; }
    if(isnan(model_params[0][i])){ model_params[0][i] = 0.0; }
    model_params[1][i] = model_params[0][i];
    if(vb_flag >= 0){ std::cout << model_params[1][i] << " " << std::flush; }
  }
  if(vb_flag >= 0){ std::cout << ": " << model_params[1][16] << std::endl; }
  for(i = 0; i < 8; i++){
    for(j = 0; j < 8; j++){      
      fit_covar[i][j] = (T_result) temp_covar[i][j];
      if(isinf(fit_covar[i][j])){ fit_covar[i][j] = (fit_covar[i][j] > 0.0) ? 9E30 : -9E30; }
      if(isnan(fit_covar[i][j])){ fit_covar[i][j] = 0.0; }
    }
  }
  best_NOp = 4;
  if(vb_flag >= 0){ std::cout << "best_NOp = " << best_NOp << std::endl; }

  // fit_mode == 2 -- 5 parameters; no forced symmetry, but no power-law
  if(vb_flag >= 0){ std::cout << "Trying: fit mode -2 . . .  " << std::endl; }
  FitBusyFunc_engine(NOvals,x_vals,y_vals,n_vals,model_params[0],-2,NOs,start_vals,mid,amp,temp_covar,vb_flag);
  if((model_params[0][16] + (2 * (5 - best_NOp))) < model_params[1][16]){
    for(i = 0; i < 17; i++){
      if(isinf(model_params[0][i])){ model_params[0][i] = (model_params[0][i] > 0.0) ? 9E30 : -9E30; }
      if(isnan(model_params[0][i])){ model_params[0][i] = 0.0; }
      model_params[1][i] = model_params[0][i];
      if(vb_flag >= 0){ std::cout << model_params[1][i] << " " << std::flush; }
    }
    if(vb_flag >= 0){ std::cout << ": " << model_params[1][16] << " ---> " << (model_params[0][16] + (2 * (5 - best_NOp))) << std::endl; }
    for(i = 0; i < 8; i++){
      for(j = 0; j < 8; j++){
	fit_covar[i][j] = (T_result) temp_covar[i][j];
	if(isinf(fit_covar[i][j])){ fit_covar[i][j] = (fit_covar[i][j] > 0.0) ? 9E30 : -9E30; }
	if(isnan(fit_covar[i][j])){ fit_covar[i][j] = 0.0; }
      }
    }
    best_NOp = 5;
  } else {
    if(vb_flag >= 0){ 
      std::cout << "Too many parameters! " << model_params[0][16] << " + " << (2 * (5 - best_NOp)) << " >= " << model_params[1][16] << " for model: " << std::flush; 
      for(i = 0; i < 17; i++){
	std::cout << model_params[0][i] << " (" << model_params[1][i] << ") " << std::flush;
      }
      std::cout << std::endl;
    }
  }
  if(vb_flag >= 0){ std::cout << "best_NOp = " << best_NOp << std::endl; }

  // fit_mode == 3 -- 5 parameters; maximum symmetry and power-law = 4
  if(vb_flag >= 0){ std::cout << "Trying: fit mode -3 . . .  " << std::endl; }
  FitBusyFunc_engine(NOvals,x_vals,y_vals,n_vals,model_params[0],-3,NOs,start_vals,mid,amp,temp_covar,vb_flag);
  if((model_params[0][16] + (2 * (5 - best_NOp))) < model_params[1][16]){
    for(i = 0; i < 17; i++){
      if(isinf(model_params[0][i])){ model_params[0][i] = (model_params[0][i] > 0.0) ? 9E30 : -9E30; }
      if(isnan(model_params[0][i])){ model_params[0][i] = 0.0; }
      model_params[1][i] = model_params[0][i];
      if(vb_flag >= 0){ std::cout << model_params[1][i] << " " << std::flush; }
    }
    if(vb_flag >= 0){ std::cout << ": " << model_params[1][16] << " ---> " << (model_params[0][16] + (2 * (5 - best_NOp))) << std::endl; }
    for(i = 0; i < 8; i++){
      for(j = 0; j < 8; j++){
	fit_covar[i][j] = (T_result) temp_covar[i][j];
	if(isinf(fit_covar[i][j])){ fit_covar[i][j] = (fit_covar[i][j] > 0.0) ? 9E30 : -9E30; }
	if(isnan(fit_covar[i][j])){ fit_covar[i][j] = 0.0; }
      }
    }
    best_NOp = 5;
  } else {
    if(vb_flag >= 0){
      std::cout << "Too many parameters! " << model_params[0][16] << " + " << (2 * (5 - best_NOp)) << " >= " << model_params[1][16] << " for model: " << std::flush;
      for(i = 0; i < 17; i++){
	std::cout << model_params[0][i] << " (" << model_params[1][i] << ") " << std::flush;
      }
      std::cout << std::endl;
    }
  }
  if(vb_flag >= 0){ std::cout << "best_NOp = " << best_NOp << std::endl; }

  // fit_mode == 4 -- 6 parameters; maximum symmetry and power-law = ? ==> use previous fitting results
  if(vb_flag >= 0){ std::cout << "Trying: fit mode -4 . . .  " << std::endl; }
  FitBusyFunc_engine(NOvals,x_vals,y_vals,n_vals,model_params[0],-4,NOs,start_vals,mid,amp,temp_covar,vb_flag);
  if((model_params[0][16] + (2 * (6 - best_NOp))) < model_params[1][16]){
    for(i = 0; i < 17; i++){
      if(isinf(model_params[0][i])){ model_params[0][i] = (model_params[0][i] > 0.0) ? 9E30 : -9E30; }
      if(isnan(model_params[0][i])){ model_params[0][i] = 0.0; }
      model_params[1][i] = model_params[0][i];
      if(vb_flag >= 0){ std::cout << model_params[1][i] << " " << std::flush; }
    }
    if(vb_flag >= 0){ std::cout << ": " << model_params[1][16] << " ---> " << (model_params[0][16] + (2 * (6 - best_NOp))) << std::endl; }
    for(i = 0; i < 8; i++){
      for(j = 0; j < 8; j++){
	fit_covar[i][j] = (T_result) temp_covar[i][j];
	if(isinf(fit_covar[i][j])){ fit_covar[i][j] = (fit_covar[i][j] > 0.0) ? 9E30 : -9E30; }
	if(isnan(fit_covar[i][j])){ fit_covar[i][j] = 0.0; }
      }
    }
    best_NOp = 6;
  } else {
    if(vb_flag >= 0){
      std::cout << "Too many parameters! " << model_params[0][16] << " + " << (2 * (6 - best_NOp)) << " >= " << model_params[1][16] << " for model: " << std::flush;
      for(i = 0; i < 17; i++){
	std::cout << model_params[0][i] << " (" << model_params[1][i] << ") " << std::flush;
      }
      std::cout << std::endl;
    }
  }
  if(vb_flag >= 0){ std::cout << "best_NOp = " << best_NOp << std::endl; }
   
  // fit_mode == 5 -- 7 parameters; intermediate symmetry (symmetric error functions, but power-law is off-centre) and power-law = ? ==> use previous fitting results
  if(vb_flag >= 0){ std::cout << "Trying: fit mode -5 . . .  " << std::endl; }
  FitBusyFunc_engine(NOvals,x_vals,y_vals,n_vals,model_params[0],-5,NOs,start_vals,mid,amp,temp_covar,vb_flag);
  if((model_params[0][16] + (2 * (7 - best_NOp))) < model_params[1][16]){
    for(i = 0; i < 17; i++){
      if(isinf(model_params[0][i])){ model_params[0][i] = (model_params[0][i] > 0.0) ? 9E30 : -9E30; }
      if(isnan(model_params[0][i])){ model_params[0][i] = 0.0; }
      model_params[1][i] = model_params[0][i];
      if(vb_flag >= 0){ std::cout << model_params[1][i] << " " << std::flush; }
    }
    if(vb_flag >= 0){ std::cout << ": " << model_params[1][16] << " ---> " << (model_params[0][16] + (2 * (7 - best_NOp))) << std::endl; }
    for(i = 0; i < 8; i++){
      for(j = 0; j < 8; j++){
	fit_covar[i][j] = (T_result) temp_covar[i][j];
	if(isinf(fit_covar[i][j])){ fit_covar[i][j] = (fit_covar[i][j] > 0.0) ? 9E30 : -9E30; }
	if(isnan(fit_covar[i][j])){ fit_covar[i][j] = 0.0; }
      }
    }
    best_NOp = 7;
  } else {
    if(vb_flag >= 0){ 
      std::cout << "Too many parameters! " << model_params[0][16] << " + " << (2 * (7 - best_NOp)) << " >= " << model_params[1][16] << " for model: " << std::flush;
      for(i = 0; i < 17; i++){
	std::cout << model_params[0][i] << " (" << model_params[1][i] << ") " << std::flush;
      }
      std::cout << std::endl;
    }
  }
  if(vb_flag >= 0){ std::cout << "best_NOp = " << best_NOp << std::endl; }
  
  // fit_mode == 6 -- 8 parameters; no forced symmetry and power-law = ? ==> use previous fitting results
  if(vb_flag >= 0){ std::cout << "Trying: fit mode -6 . . .  " << std::endl; }
  FitBusyFunc_engine(NOvals,x_vals,y_vals,n_vals,model_params[0],-6,NOs,start_vals,mid,amp,temp_covar,vb_flag);
  if((model_params[0][16] + (2 * (8 - best_NOp))) < model_params[1][16]){
    for(i = 0; i < 17; i++){
      if(isinf(model_params[0][i])){ model_params[0][i] = (model_params[0][i] > 0.0) ? 9E30 : -9E30; }
      if(isnan(model_params[0][i])){ model_params[0][i] = 0.0; }
      model_params[1][i] = model_params[0][i];
      if(vb_flag >= 0){ std::cout << model_params[1][i] << " " << std::flush; }
    }
    if(vb_flag >= 0){ std::cout << ": " << model_params[1][16] << " ---> " << (model_params[0][16] + (2 * (8 - best_NOp))) << std::endl; }
    for(i = 0; i < 8; i++){
      for(j = 0; j < 8; j++){
	fit_covar[i][j] = (T_result) temp_covar[i][j];
	if(isinf(fit_covar[i][j])){ fit_covar[i][j] = (fit_covar[i][j] > 0.0) ? 9E30 : -9E30; }
	if(isnan(fit_covar[i][j])){ fit_covar[i][j] = 0.0; }
      }
    }
    best_NOp = 8;
  } else {
    if(vb_flag >= 0){
      std::cout << "Too many parameters! " << model_params[0][16] << " + " << (2 * (8 - best_NOp)) << " >= " << model_params[1][16] << " for model: " << std::flush;
      for(i = 0; i < 17; i++){
	std::cout << model_params[0][i] << " (" << model_params[1][i] << ") " << std::flush;
      }
      std::cout << std::endl;
    }
  }

  if(vb_flag >= 0){ 

    std::cout << "best_NOp = " << best_NOp << std::endl; 
    std::cout << "Best fitting model is fit_mode = " << best_NOp << std::endl;

  }

  // free up memory 
  for(i = 0; i < NOs; i++){

    delete [] start_vals[i];
    start_vals[i] = NULL;

  }
  delete [] start_vals;
  start_vals = NULL;
  for(i = 0; i < 8; i++){

    delete [] temp_covar[i];
    temp_covar[i] = NULL;

  }
  delete [] temp_covar;
  temp_covar = NULL;

  // if required, de-scale the input y_vals[] and the model parameters
  if(y_scale_flag > 0){

    if(vb_flag >= 0){ std::cout << "De-scaling with " << y_scale << " . . . " << std::endl; }
    for(i = 0; i < NOvals; i++){ 

      y_vals[i]*=((T_data) y_scale);
      n_vals[i]*=((T_data) y_scale);

    }
    model_params[1][0]*=y_scale;
    model_params[1][1]*=y_scale;

  }

  // return best fitting model (incorporating AIC penalties) and the number of model parameters
  for(i = 0; i < 17; i++){
    if(isinf(model_params[1][i])){ model_params[1][i] = (model_params[1][i] > 0.0) ? 9E30 : -9E30; }
    if(isnan(model_params[1][i])){ model_params[1][i] = 0.0; }
    fit_params[i] = (T_result) model_params[1][i];
  }
  return best_NOp;
  
}

void covsrt(double **covar, int ma, int ia[], int mfit);

template <class T_count, class T_xvals, class T_data>
void mrqcof(T_xvals x[], T_data y[], T_data sig[], T_count ndata, double a[], int ia[], int ma, double **alpha, double beta[], double *chisq, void (*funcs) (double, double [], double *, double [], int, double, double), int fit_mode, double mid, double amp){

  int i,j,k,l,m,mfit=0;
  double ymod,wt,sig2i,dy,*dyda;

  dyda = new double[ma];
  for(j=0;j<ma;j++){ if(ia[j]){ mfit++; } }
  for(j=0;j<mfit;j++){
    for(k=0;k<=j;k++){ alpha[j][k]=0.0; }
    beta[j]=0.0;
  }
  *chisq=0.0;
  for(i=0;i<ndata;i++){
    (*funcs)(((double) x[i]),a,&ymod,dyda,fit_mode,mid,amp);
    sig2i=1.0/((double)(sig[i]*sig[i]));
    dy=((double) y[i])-ymod;
    for (j=0,l=0;l<ma;l++) {
      if (ia[l]) {
	wt=dyda[l]*sig2i;
	for (k=0,m=0;m<=l;m++){
	  if(ia[m]){ alpha[j][k++]+=(wt*dyda[m]); }
	}
	beta[j++]+=(dy*wt);
      }
    }
    *chisq+=(dy*dy*sig2i);
  }
  if((isinf(*chisq)) || (isnan(*chisq))){ *chisq = 9E30; }
  for (j=1;j<mfit;j++){
    for (k=0;k<j;k++){ alpha[k][j]=alpha[j][k]; }
  }
 
  // test for inf and nan values in alpha, beta and dyda
  for(j = 0; j < mfit; j++){

    if(isinf(beta[j])){ beta[j] = (beta[j] > 0.0) ? 9E30 : -9E30; }
    if(isnan(beta[j])){ beta[j] = 0.0; }

    for(k = 0; k < mfit; k++){

      if(isinf(alpha[j][k])){ alpha[j][k] = (alpha[j][k] > 0.0) ? 9E30 : -9E30; }
      if(isnan(alpha[j][k])){ alpha[j][k] = 0.0; }

    }

  }

  delete [] dyda;
  dyda = NULL;
  
}

template <class T_count, class T_xvals, class T_data>
int mrqmin(T_xvals x[], T_data y[], T_data sig[], T_count ndata, double a[], int ia[], int ma, double **covar, double **alpha, double *chisq, void (*funcs)(double, double [], double *, double [], int, double, double), double *alamda, int fit_mode, double mid, double amp, int &mfit, double &ochisq, double * atry, double * beta, double * da, double ** oneda){

  void covsrt(double **covar, int ma, int ia[], int mfit);
  void svdcmp(double **a, int m, int n, double w[], double **v);
  void svbksb(double **u, double w[], double **v, int m, int n, double b[], double x[]);
  int i,j,k,l,state_flag;
  double ** temp_covar, * w, ** v, * soln, * b, wmax, wmin;

  // set the value of state_flag 
  state_flag = 0;
  if((*alamda > -2.0) && (*alamda < 0.0)){ 

    *alamda = 0.0; 
    state_flag = 1; 

  } else if(*alamda < -2.0){
    
    state_flag = -1;

  }

  // test range of *alamda to ensure it's not ludicrously small or large during mid-stages
  if(state_flag == 1){

    if(isnan(*alamda)){ *alamda = 1E-10; }
    if(isinf(*alamda)){ *alamda = (*alamda > 0.0) ? 1E20 : 1E-10; }
    if(*alamda < 1E-10){ *alamda = 1E-10; }
    if(*alamda > 1E20){ *alamda = 1E20; }
    
  }

  temp_covar = new double * [ma];
  for(j = 0; j < ma; j++){ temp_covar[j] = new double[ma]; }
  w = new double[ma];
  v = new double * [ma];
  for(j = 0; j < ma; j++){ v[j] = new double[ma]; }
  soln = new double[ma];
  b = new double[ma];

  if(state_flag < 0){
    for (mfit=0,j=0;j<ma;j++){ if(ia[j] > 0){ mfit++; } }
    *alamda=0.001;
    mrqcof(x,y,sig,ndata,a,ia,ma,alpha,beta,chisq,funcs,fit_mode,mid,amp);
    ochisq=(*chisq);
    for(j=0;j<ma;j++){ atry[j]=a[j]; }
  }
  for(j=0;j<mfit;j++){
    for(k=0;k<mfit;k++){ covar[j][k]=alpha[j][k]; }
    covar[j][j]=alpha[j][j]*(1.0+(*alamda));
    oneda[j][0]=beta[j];
  }

  // calculate inverse of covar[] using SVD 
  for(j=0;j<mfit;j++){
    for(k=0;k<mfit;k++){
      temp_covar[j][k]=covar[j][k];
    }
  }

  svdcmp(temp_covar,mfit,mfit,w,v);

  for(j=0;j<mfit;j++){
    if(isnan(w[j])){ w[j] = 0.0; }
    if(isinf(w[j])){ w[j] = (w[j] > 0.0) ? 9E30 : -9E30; }
    for(k=0;k<mfit;k++){
      if(isnan(temp_covar[j][k])){ temp_covar[j][k] = 0.0; }
      if(isinf(temp_covar[j][k])){ temp_covar[j][k] = (temp_covar[j][k] > 0.0) ? 9E30 : -9E30; }
      if(isnan(v[j][k])){ v[j][k] = 0.0; }
      if(isinf(v[j][k])){ v[j][k] = (v[j][k] > 0.0) ? 9E30 : -9E30; }
    }
  }

  // threshold useless weights --- uncomment the for loop to apply thresholding 
  wmax=0.0;
  //for(j=0;j<mfit;j++){ if(w[j] > wmax){ wmax = w[j]; } }
  //wmin=wmax * 1E-6;
  //wmin=wmax * 1E-9;
  wmin=wmax * 1E-12;
  for(j=0;j<mfit;j++){ if(w[j] < wmin){ w[j] = 0.0; } }

  for(j=0;j<mfit;j++){
    for(k=0;k<mfit;k++){ b[k] = soln[k] = 0.0; }
    b[j]=1.0;
    svbksb(temp_covar,w,v,mfit,mfit,b,soln);
    for(k=0;k<mfit;k++){ covar[k][j] = soln[k]; }

  }
  
  // ensure oneda[j][1] contains the solution, x, to A * x = b
  // using svbksb 
  for(j=0;j<mfit;j++){ b[j]=oneda[j][0]; soln[j] = 0.0; }
  svbksb(temp_covar,w,v,mfit,mfit,b,soln);
  for(j=0;j<mfit;j++){ da[j]=soln[j]; }

  if(state_flag > 0) {
    covsrt(covar,ma,ia,mfit);
    covsrt(alpha,ma,ia,mfit);
    return 1;
  }

  for(j=-1,l=0;l<ma;l++){ if(ia[l]){ atry[l]=a[l]+da[++j]; } }

  mrqcof(x,y,sig,ndata,atry,ia,ma,covar,da,chisq,funcs,fit_mode,mid,amp);

  if (*chisq < ochisq) {
    *alamda *= 0.1;
    ochisq=(*chisq);
    for (j=0;j<mfit;j++) {
      for (k=0;k<mfit;k++) alpha[j][k]=covar[j][k];
      beta[j]=da[j];
    }
    for (l=0;l<ma;l++) a[l]=atry[l];
  } else {
    *alamda *= 10.0;
    *chisq=ochisq;
  }

  for(i = 0; i < ma; i++){ delete [] temp_covar[i]; temp_covar[i] = NULL; }
  delete [] temp_covar;
  temp_covar = NULL;
  delete [] w;
  w = NULL;
  for(i = 0; i < ma; i++){ delete [] v[i]; v[i] = NULL; }
  delete [] v;
  v = NULL;
  delete [] soln;
  soln = NULL;
  delete [] b;
  b = NULL;
  
  return 1;

}

void svbksb(double **u, double w[], double **v, int m, int n, double b[], double x[]);

void svdcmp(double **a, int m, int n, double w[], double **v);
 
double ran2(long &idum);

double pythag(double a, double b);





