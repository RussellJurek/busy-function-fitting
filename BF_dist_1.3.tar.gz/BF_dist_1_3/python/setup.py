from distutils.core import setup, Extension

module1 = Extension('BusyFunc', 
                    include_dirs = ['./','../C','/usr/local/include'],
                    libraries = ['PyBFfit'],
                    library_dirs = ['./','../C','/usr/local/lib'],
                    extra_compile_args = ['-fopenmp'],
                    extra_link_args = ['-fopenmp'],
                    sources = ['BusyFuncmodule.c'])

setup (name = 'BusyFunc', 
       version = '1.2', 
       description = 'This package fits the Busy Function (see Westmeier, Jurek, Obreschkow & Koribalski 2013) to user supplied data. This package uses the implementation described in Westemeier et al. (2013). Please cite this paper in any published works that utilise this package. \n\nThis package fits the following forumulation of the Busy Function,\n\ny(x) = 0.25 * alpha * {1 + erf[beta_1 * (x - gamma_1)]} * {1 + erf[beta_2 * (gamma_2 - x)]} * {1 + phi * [x - theta]^N},\n\nwhere the following constraints are applied using variable re-mapping: alpha >= 0.0, beta_1 >= 0.0, beta_2 >= 0.0, phi >= 0.0, 2 <= N <= 8, x_min <= gamma_1 <= x_max, x_min <= gamma_2 <= x_max and x_min <= theta <= x_max. Note that the beta_1 and beta_2 constraints implicitly imposes a weak constraint, gamma_1 (almost always) <= gamma_2. \n\n',
       author = 'Russell J. Jurek',
       author_email = 'Russell.Jurek@gmail.com',
       ext_modules = [module1])

