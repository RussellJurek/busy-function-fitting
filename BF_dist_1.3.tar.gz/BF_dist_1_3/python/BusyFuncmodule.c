/*

This is version 1.2 of the wrapper for the C BusyFunc library that fits the Busy Function to data.
See Westmeier, Jurek, Obreschkow, Koribalski & Staveley-Smith (2013) for more details about the implementation
and the Busy Function.

Email: Russell.Jurek@gmail.com

Version 1.2 created by Russell J. Jurek, 27th December 2013.
Version 1.1 created by Russell J. Jurek, 9th November 2013.
Version 1.0 created by Russell J. Jurek, 30th June 2013.

*/

#include<Python.h>
#include<PyBFfit.h>

// wrapper function called from Python --- FitBusyFunc_dbl
static PyObject *
BusyFunc_Fit(PyObject *self, PyObject *args){

  int FitBusyFunc_dbl(int NOvals, double * x_vals, double * y_vals, double * n_vals, double * fit_params, double ** fit_covar, int * best_NOp, int NOs, int iter_max, int vb_flag);

  int i, j, dims, NOvals, vb_flag, NOs, iter_max, fit_type;
  double * x_vals, * y_vals, * n_vals, x_min, x_max;
  double * fit_params, ** fit_covar;

  // define Python objects
  PyObject * py_x_vals, * py_y_vals, * py_n_vals, * py_list_i, * py_list_j, * py_return;

  // parse Python tuple object into a mixture of python list objects and C variables
  if(!(PyArg_ParseTuple(args,"OOOiddii",&py_x_vals,&py_y_vals,&py_n_vals,&vb_flag,&x_min,&x_max,&NOs,&iter_max))){ 
    
    printf("Failed to successfully parse python inputs to BusyFunc.fit(). Exiting . . . \n"); 
    return NULL; 
  
  }

  // check that the python objects are all lists
  if(!(PyList_Check(py_x_vals))){ 
    
    printf("BusyFunc.fit ERROR: Argument 1 is not a list. Exiting . . . \n"); 
    PyErr_SetString(PyExc_TypeError,"Argument 1 is not a list.");
    return NULL; 

  }
  if(!(PyList_Check(py_y_vals))){ 

    printf("BusyFunc.fit ERROR: Argument 2 is not a list. Exiting . . . \n"); 
    PyErr_SetString(PyExc_TypeError,"Argument 2 is not a list.");
    return NULL; 

  }
  if(!(PyList_Check(py_n_vals))){ 

    printf("BusyFunc.fit ERROR: Argument 3 is not a list. Exiting . . . \n"); 
    PyErr_SetString(PyExc_TypeError,"Argument 3 is not a list.");
    return NULL; 

  }

  // set an exception if NOs or iter_max isn't a viable value
  if(NOs < 1){ 
    PyErr_SetString(PyExc_TypeError,"BusyFunc.fit ERROR: Too few LVM seeds specified. Value greater than 0 required.");
    return NULL;
  }
  if(iter_max < 1){ 
    PyErr_SetString(PyExc_TypeError,"BusyFunc.fit ERROR: Too few iterations specified for each LVM seed. Value greater than 0 required."); 
    return NULL;
  }

  // create the C arrays passed to the cBFfit_OMP library
  NOvals = (int) PyList_Size(py_x_vals);
  if((int) PyList_Size(py_y_vals) < NOvals){ NOvals = (int) PyList_Size(py_y_vals); }
  if((int) PyList_Size(py_n_vals) < NOvals){ NOvals = (int) PyList_Size(py_n_vals); }
  if(NOvals < 2){

    // set an exception if NOvals < 2
    printf("BusyFunc.fit ERROR: NOvals (= %d) is too small. Exiting . . . \n",NOvals);
    PyErr_SetString(PyExc_TypeError,"Less than 2 elements in the smallest input list.");
    return NULL;

  }
  x_vals = malloc(NOvals * sizeof(double));
  y_vals = malloc(NOvals * sizeof(double));
  n_vals = malloc(NOvals * sizeof(double));
  fit_params = malloc(17 * sizeof(double));
  for(i = 0; i < 17; i++){ fit_params[i] = 0.0; }
  fit_params[4] = x_min;
  fit_params[8] = x_max;
  fit_covar = malloc(8 * sizeof(double *));
  for(j = 0; j < 8; j++){ 
    
    fit_covar[j] = malloc(8 * sizeof(double)); 
    for(i = 0; i < 8; i++){ fit_covar[j][i] = 0.0; }

  }

  // copy the Python input values into the C arrays
  for(i = 0; i < NOvals; i++){
    
    x_vals[i] = PyFloat_AsDouble(PyList_GetItem(py_x_vals,(Py_ssize_t) i));
    y_vals[i] = PyFloat_AsDouble(PyList_GetItem(py_y_vals,(Py_ssize_t) i));
    n_vals[i] = PyFloat_AsDouble(PyList_GetItem(py_n_vals,(Py_ssize_t) i));
    
  }

  // call C busy function --- double precision version;
  //                          the module could be recompiled to use floats and call FitBusyFunc_flt
  //                          for a *slight* improvement in speed
  fit_type = FitBusyFunc_dbl(NOvals,x_vals,y_vals,n_vals,fit_params,fit_covar,&dims,NOs,iter_max,vb_flag);
  
  // build python object containing fit results
  py_return = PyTuple_New((Py_ssize_t) 4);
  PyTuple_SetItem(py_return,(Py_ssize_t) 0,Py_BuildValue("i",fit_type));
  PyTuple_SetItem(py_return,(Py_ssize_t) 1,Py_BuildValue("i",dims));
  py_list_i = PyList_New((Py_ssize_t) 17);
  for(i = 0; i < 17; i++){ PyList_SetItem(py_list_i,(Py_ssize_t) i,PyFloat_FromDouble(fit_params[i])); }
  PyTuple_SetItem(py_return,(Py_ssize_t) 2,py_list_i);
  py_list_j = PyList_New((Py_ssize_t) 8);
  for(j = 0; j < 8; j++){
    py_list_i = PyList_New((Py_ssize_t) 8);
    for(i = 0; i < 8; i++){
      PyList_SetItem(py_list_i,(Py_ssize_t) i,PyFloat_FromDouble(fit_covar[j][i]));
    }
    PyList_SetItem(py_list_j,(Py_ssize_t) j,py_list_i);
  }
  PyTuple_SetItem(py_return,(Py_ssize_t) 3,py_list_j);
  
  // free up C arrays
  free(x_vals);
  free(y_vals);
  free(n_vals);
  free(fit_params);
  for(i = 0; i < 8; i++){ free(fit_covar[i]); }
  free(fit_covar);

  // return a Python tuple containing the results
  return py_return;

}

// wrapper function called from Python --- FitBusyFunc_dbl with NOs = -1
static PyObject *
BusyFunc_Refine(PyObject *self, PyObject *args){

  int FitBusyFunc_dbl(int NOvals, double * x_vals, double * y_vals, double * n_vals, double * fit_params, double ** fit_covar, int * best_NOp, int NOs, int iter_max, int vb_flag);

  int i, j, dims, NOvals, vb_flag, iter_max, fit_type;
  double * x_vals, * y_vals, * n_vals;
  double * fit_params, ** fit_covar;

  // define Python objects
  PyObject * py_x_vals, * py_y_vals, * py_n_vals, * py_fit_params, * py_list_i, * py_list_j, * py_return;

  // parse Python tuple object into a mixture of python list objects and C variables
  if(!(PyArg_ParseTuple(args,"OOOiiO",&py_x_vals,&py_y_vals,&py_n_vals,&vb_flag,&iter_max,&py_fit_params))){ 
    
    printf("Failed to successfully parse python inputs to BusyFunc.refine(). Exiting . . . \n"); 
    return NULL; 
  
  }

  // check that the python objects are all lists
  if(!(PyList_Check(py_x_vals))){ 
    
    printf("BusyFunc.refine ERROR: Argument 1 is not a list. Exiting . . . \n"); 
    PyErr_SetString(PyExc_TypeError,"Argument 1 is not a list.");
    return NULL; 

  }
  if(!(PyList_Check(py_y_vals))){ 

    printf("BusyFunc.refine ERROR: Argument 2 is not a list. Exiting . . . \n"); 
    PyErr_SetString(PyExc_TypeError,"Argument 2 is not a list.");
    return NULL; 

  }
  if(!(PyList_Check(py_n_vals))){ 

    printf("BusyFunc.refine ERROR: Argument 3 is not a list. Exiting . . . \n"); 
    PyErr_SetString(PyExc_TypeError,"Argument 3 is not a list.");
    return NULL; 

  }
  if(!(PyList_Check(py_fit_params))){ 

    printf("BusyFunc.refine ERROR: Argument 8 is not a list. Exiting . . . \n"); 
    PyErr_SetString(PyExc_TypeError,"Argument 8 is not a list.");
    return NULL; 

  }

  // set an exception if NOs or iter_max isn't a viable value
  if(iter_max < 1){ 
    PyErr_SetString(PyExc_TypeError,"BusyFunc.refine ERROR: Too few iterations specified for LVM. Value greater than 0 required."); 
    return NULL;
  }

  // create the C arrays passed to the cBFfit_OMP library
  NOvals = (int) PyList_Size(py_x_vals);
  if((int) PyList_Size(py_y_vals) < NOvals){ NOvals = (int) PyList_Size(py_y_vals); }
  if((int) PyList_Size(py_n_vals) < NOvals){ NOvals = (int) PyList_Size(py_n_vals); }
  if(NOvals < 2){

    // set an exception if NOvals < 2
    printf("BusyFunc.refine ERROR: NOvals (= %d) is too small. Exiting . . . \n",NOvals);
    PyErr_SetString(PyExc_TypeError,"Less than 2 elements in the smallest input list.");
    return NULL;

  }
  x_vals = malloc(NOvals * sizeof(double));
  y_vals = malloc(NOvals * sizeof(double));
  n_vals = malloc(NOvals * sizeof(double));
  fit_params = malloc(17 * sizeof(double));
  for(i = 0; i < 17; i++){ fit_params[i] = 0.0; }
  fit_covar = malloc(8 * sizeof(double *));
  for(j = 0; j < 8; j++){ 
    
    fit_covar[j] = malloc(8 * sizeof(double)); 
    for(i = 0; i < 8; i++){ fit_covar[j][i] = 0.0; }

  }

  // copy the Python input values into the C arrays
  for(i = 0; i < NOvals; i++){
    
    x_vals[i] = PyFloat_AsDouble(PyList_GetItem(py_x_vals,(Py_ssize_t) i));
    y_vals[i] = PyFloat_AsDouble(PyList_GetItem(py_y_vals,(Py_ssize_t) i));
    n_vals[i] = PyFloat_AsDouble(PyList_GetItem(py_n_vals,(Py_ssize_t) i));
    
  }
  for(i = 0; i < 17; i++){ fit_params[i] = PyFloat_AsDouble(PyList_GetItem(py_fit_params,(Py_ssize_t) i)); }

  // call C busy function --- double precision version;
  //                          the module could be recompiled to use floats and call FitBusyFunc_flt
  //                          for a *slight* improvement in speed
  fit_type = FitBusyFunc_dbl(NOvals,x_vals,y_vals,n_vals,fit_params,fit_covar,&dims,-1,iter_max,vb_flag);
  
  // build python object containing fit results
  py_return = PyTuple_New((Py_ssize_t) 4);
  PyTuple_SetItem(py_return,(Py_ssize_t) 0,Py_BuildValue("i",fit_type));
  PyTuple_SetItem(py_return,(Py_ssize_t) 1,Py_BuildValue("i",dims));
  py_list_i = PyList_New(17);
  for(i = 0; i < 17; i++){ PyList_SetItem(py_list_i,(Py_ssize_t) i,PyFloat_FromDouble(fit_params[i])); }
  PyTuple_SetItem(py_return,(Py_ssize_t) 2,py_list_i);
  py_list_j = PyList_New(8);
  for(j = 0; j < 8; j++){
    py_list_i = PyList_New(8);
    for(i = 0; i < 8; i++){
      PyList_SetItem(py_list_i,(Py_ssize_t) i,PyFloat_FromDouble(fit_covar[j][i]));
    }
    PyList_SetItem(py_list_j,(Py_ssize_t) j,py_list_i);
  }
  PyTuple_SetItem(py_return,(Py_ssize_t) 3,py_list_j);
  
  // free up C arrays
  free(x_vals);
  free(y_vals);
  free(n_vals);
  free(fit_params);
  for(i = 0; i < 8; i++){ free(fit_covar[i]); }
  free(fit_covar);

  // return a Python tuple containing the results
  return py_return;

}

// wrapper function called from Python --- CreateRandFits_dbl
static PyObject *
BusyFunc_CreateRandFits(PyObject *self, PyObject *args){

  void CreateRandFits_dbl(int NOr, double ** rand_fits, int fit_type, double * BF_fit, double ** BF_covar, double x_min, double x_max, int vb_flag);

  int i, j, vb_flag, NOr, fit_type;
  double * fit_params, ** fit_covar, ** rand_fits, x_min, x_max;

  // define Python objects
  PyObject * py_fit_params, * py_fit_covar, * py_list_i, * py_return;

  // parse Python tuple object into a mixture of python list objects and C variables
  if(!(PyArg_ParseTuple(args,"iiOOddi",&NOr,&fit_type,&py_fit_params,&py_fit_covar,&x_min,&x_max,&vb_flag))){ 
    
    printf("Failed to successfully parse python inputs to BusyFunc.rand_fits(). Exiting . . . \n"); 
    return NULL; 
  
  }

  // check that the python objects are all lists
  if(!(PyList_Check(py_fit_params))){ 

    printf("BusyFunc.rand_fits ERROR: Argument 3 is not a list. Exiting . . . \n"); 
    PyErr_SetString(PyExc_TypeError,"Argument 3 is not a list.");
    return NULL; 

  }
  if(!(PyList_Check(py_fit_covar))){ 

    printf("BusyFunc.rand_fits ERROR: Argument 4 is not a list. Exiting . . . \n"); 
    PyErr_SetString(PyExc_TypeError,"Argument 4 is not a list.");
    return NULL; 

  }

  // create the C arrays passed to the cBFfit_OMP library
  fit_params = malloc(17 * sizeof(double));
  fit_covar = malloc(8 * sizeof(double *));
  for(j = 0; j < 8; j++){ fit_covar[j] = malloc(8 * sizeof(double)); }
  rand_fits = malloc(NOr * sizeof(double *));
  for(i = 0; i < NOr; i++){ rand_fits[i] = malloc(8 * sizeof(double)); }

  // copy the Python input values into the C arrays
  for(i = 0; i < 17; i++){ fit_params[i] = PyFloat_AsDouble(PyList_GetItem(py_fit_params,(Py_ssize_t) i)); }
  for(j = 0; j < 8; j++){
    for(i = 0; i < 8; i++){
      fit_covar[j][i] = PyFloat_AsDouble(PyList_GetItem(PyList_GetItem(py_fit_covar,(Py_ssize_t) j),(Py_ssize_t) i)); 
    }
  }

  // call C function --- double precision version;
  //                     the module could be recompiled to use floats and call CreateRandFits_flt
  //                     for a *slight* improvement in speed
  CreateRandFits_dbl(NOr,rand_fits,fit_type,fit_params,fit_covar,x_min,x_max,vb_flag);
    
  // return a Python tuple containing the random BF fits
  py_return = PyList_New((Py_ssize_t) NOr);
  for(j = 0; j < NOr; j++){

    py_list_i = PyList_New((Py_ssize_t) 8);
    for(i = 0; i < 8; i++){

      PyList_SetItem(py_list_i,(Py_ssize_t) i,PyFloat_FromDouble(rand_fits[j][i]));

    }
    PyList_SetItem(py_return,(Py_ssize_t) j,py_list_i);

  }

  // free up C arrays
  free(fit_params);
  for(i = 0; i < 8; i++){ free(fit_covar[i]); }
  free(fit_covar);
  for(i = 0; i < NOr; i++){ free(rand_fits[i]); }
  free(rand_fits);

  // return python object
  return py_return;

}

// wrapper function called from python --- CalcObsParams_dbl
static PyObject *
BusyFunc_CalcObsVals(PyObject *self, PyObject *args){

  void CalcObsParams_dbl(int NOr, double ** rand_fits, int NOvals, double * x_vals, double ** obs_vals, int vb_flag);

  int i, j, vb_flag, NOr, NOvals;
  double ** obs_vals, ** rand_fits, * x_vals;

  // define Python objects
  PyObject * py_rand_fits, * py_x_vals, * py_list_i, * py_return;

  // parse Python tuple object into a mixture of python list objects and C variables
  if(!(PyArg_ParseTuple(args,"OOi",&py_rand_fits,&py_x_vals,&vb_flag))){ 
    
    printf("Failed to successfully parse python inputs to BusyFunc.obs_vals(). Exiting . . . \n"); 
    return NULL; 
  
  }

  // check that the python objects are all lists
  if(!(PyList_Check(py_rand_fits))){ 

    printf("ERROR: Argument 1 is not a list. Exiting . . . \n"); 
    PyErr_SetString(PyExc_TypeError,"Argument 1 is not a list.");
    return NULL; 

  }
  if(!(PyList_Check(py_x_vals))){ 

    printf("ERROR: Argument 2 is not a list. Exiting . . . \n"); 
    PyErr_SetString(PyExc_TypeError,"Argument 2 is not a list.");
    return NULL; 

  }

  // get the number of values and random fits
  NOvals = (int) PyList_Size(py_x_vals);
  NOr = (int) PyList_Size(py_rand_fits);

  // create the C arrays passed to the cBFfit_OMP library
  x_vals = malloc(sizeof(double) * NOvals);
  rand_fits = malloc(sizeof(double *) * NOr);
  for(j = 0; j < NOr; j++){ rand_fits[j] = malloc(sizeof(double) * 8); }
  obs_vals = malloc(sizeof(double *) * NOr);
  for(j = 0; j < NOr; j++){ obs_vals[j] = malloc(sizeof(double) * 7); }

  // copy the Python input values into the C arrays
  for(i = 0; i < NOvals; i++){ x_vals[i] = PyFloat_AsDouble(PyList_GetItem(py_x_vals,(Py_ssize_t) i)); }
  for(j = 0; j < NOr; j++){
    for(i = 0; i < 8; i++){
      rand_fits[j][i] = PyFloat_AsDouble(PyList_GetItem(PyList_GetItem(py_rand_fits,(Py_ssize_t) j),(Py_ssize_t) i)); 
    }
  }

  // call C function --- double precision version;
  //                     the module could be recompiled to use floats and call CalcObsParams_flt
  //                     for a *slight* improvement in speed
  CalcObsParams_dbl(NOr,rand_fits,NOvals,x_vals,obs_vals,vb_flag);
    
  // return a Python tuple containing the random BF fits
  py_return = PyList_New((Py_ssize_t) NOr);
  for(j = 0; j < NOr; j++){

    py_list_i = PyList_New((Py_ssize_t) 7);
    for(i = 0; i < 7; i++){

      PyList_SetItem(py_list_i,(Py_ssize_t) i,PyFloat_FromDouble(obs_vals[j][i]));

    }
    PyList_SetItem(py_return,(Py_ssize_t) j,py_list_i);

  }

  // free up C arrays
  free(x_vals);
  for(i = 0; i < NOr; i++){ free(rand_fits[i]); }
  free(rand_fits);
  for(i = 0; i < NOr; i++){ free(obs_vals[i]); }
  free(obs_vals);

  // return python object
  return py_return;

}

// wrapper function called from python --- AnalyseObsVals_dbl
static PyObject *
BusyFunc_AnalyseObsVals(PyObject *self, PyObject *args){

  void AnalyseObsVals_dbl(int NOr, int NOprops, double ** obs_vals, double ** obs_stats, int vb_flag);

  int i, j, vb_flag, NOr, NOprops;
  double ** obs_vals, ** obs_stats;

  // define Python objects
  PyObject * py_obs_vals, * py_list_i, * py_return;

  // parse Python tuple object into a mixture of python list objects and C variables
  if(!(PyArg_ParseTuple(args,"Oi",&py_obs_vals,&vb_flag))){ 
    
    printf("Failed to successfully parse python inputs to BusyFunc.analyse_obs_vals(). Exiting . . . \n"); 
    return NULL; 
  
  }

  // check that the python objects are all lists
  if(!(PyList_Check(py_obs_vals))){ 

    printf("BusyFunc.analyse_obs_vals ERROR: Argument 1 is not a list. Exiting . . . \n"); 
    PyErr_SetString(PyExc_TypeError,"Argument 1 is not a list.");
    return NULL; 

  }

  // get the number of randomfits
  NOr = (int) PyList_Size(py_obs_vals);
  NOprops = 7;

  // create the C arrays passed to the cBFfit_OMP library
  obs_vals = malloc(sizeof(double *) * NOr);
  for(j = 0; j < NOr; j++){ obs_vals[j] = malloc(sizeof(double) * NOprops); }
  obs_stats = malloc(sizeof(double *) * NOprops);
  for(j = 0; j < NOprops; j++){ obs_stats[j] = malloc(sizeof(double) * 8); }

  // copy the Python input values into the C arrays
  for(j = 0; j < NOr; j++){
    for(i = 0; i < NOprops; i++){
      obs_vals[j][i] = PyFloat_AsDouble(PyList_GetItem(PyList_GetItem(py_obs_vals,(Py_ssize_t) j),(Py_ssize_t) i)); 
    }
  }

  // call C function --- double precision version;
  //                     the module could be recompiled to use floats and call AnalyseObsVals_flt
  //                     for a *slight* improvement in speed
  AnalyseObsVals_dbl(NOr,NOprops,obs_vals,obs_stats,vb_flag);
    
  // return a Python tuple containing the random BF fits
  py_return = PyList_New((Py_ssize_t) NOprops);
  for(j = 0; j < NOprops; j++){ 
    
    py_list_i = PyList_New((Py_ssize_t) 8);
    for(i = 0; i < 8; i++){

      PyList_SetItem(py_list_i,(Py_ssize_t) i,PyFloat_FromDouble(obs_stats[j][i]));

    }
    PyList_SetItem(py_return,(Py_ssize_t) j,py_list_i);

  }

  // free up C arrays
  for(i = 0; i < NOr; i++){ free(obs_vals[i]); }
  free(obs_vals);
  for(i = 0; i < NOprops; i++){ free(obs_stats[i]); }
  free(obs_stats);

  // return python object
  return py_return;

}

// wrapper function called from python --- ApproxObsCovar_dbl
static PyObject *
BusyFunc_ApproxObsCovar(PyObject *self, PyObject *args){

  void ApproxObsCovar_dbl(int fit_type, int NOvals, double * x_vals, double * fit_params, double ** fit_covar, double ** obs_covar, double x_min, double x_max);

  int i, j, NOvals, fit_type;
  double * x_vals, x_min, x_max;
  double * fit_params, ** fit_covar, ** obs_covar;

  // define Python objects
  PyObject * py_x_vals, * py_fit_params, * py_fit_covar, * py_list_i, * py_list_j, * py_return;

  // parse Python tuple object into a mixture of python list objects and C variables
  if(!(PyArg_ParseTuple(args,"iOOOdd",&fit_type,&py_x_vals,&py_fit_params,&py_fit_covar,&x_min,&x_max))){ 
    
    printf("Failed to successfully parse python inputs to BusyFunc.ApproxObsCovar(). Exiting . . . \n"); 
    return NULL; 
  
  }

  // check that the python objects are all lists
  if(!(PyList_Check(py_x_vals))){ 
    
    printf("ERROR: Argument 1 is not a list. Exiting . . . \n"); 
    PyErr_SetString(PyExc_TypeError,"Argument 1 is not a list.");
    return NULL; 

  }
  if(!(PyList_Check(py_fit_params))){ 

    printf("ERROR: Argument 4 is not a list. Exiting . . . \n"); 
    PyErr_SetString(PyExc_TypeError,"Argument 2 is not a list.");
    return NULL; 

  }
  if(!(PyList_Check(py_fit_covar))){ 

    printf("ERROR: Argument 5 is not a list. Exiting . . . \n"); 
    PyErr_SetString(PyExc_TypeError,"Argument 3 is not a list.");
    return NULL; 

  }

  // create the C arrays passed to the cBFfit_OMP library
  NOvals = (int) PyList_Size(py_x_vals);
  x_vals = malloc(NOvals * sizeof(double));
  fit_params = malloc(17 * sizeof(double));
  for(i = 0; i < 17; i++){ fit_params[i] = 0.0; }
  fit_covar = malloc(8 * sizeof(double *));
  for(j = 0; j < 8; j++){ 
    
    fit_covar[j] = malloc(8 * sizeof(double)); 
    for(i = 0; i < 8; i++){ fit_covar[j][i] = 0.0; }

  }
  obs_covar = malloc(7 * sizeof(double *));
  for(j = 0; j < 8; j++){
    
    obs_covar[j] = malloc(7 * sizeof(double));
    for(i = 0; i < 7; i++){ obs_covar[j][i] = 0.0; }

  }

  // copy the Python input values into the C arrays
  for(i = 0; i < NOvals; i++){ x_vals[i] = PyFloat_AsDouble(PyList_GetItem(py_x_vals,(Py_ssize_t) i)); }
  for(i = 0; i < 17; i++){ fit_params[i] = PyFloat_AsDouble(PyList_GetItem(py_fit_params,(Py_ssize_t) i)); }
  for(j = 0; j < 8; j++){
    for(i = 0; i < 8; i++){ 
      fit_covar[j][i] = PyFloat_AsDouble(PyList_GetItem(PyList_GetItem(py_fit_covar,(Py_ssize_t) j),(Py_ssize_t) i)); 
    }
  }

  // call C ApproxObsCovar function --- double precision version;
  //                                    the module could be recompiled to use floats and call FitBusyFunc_flt
  //                                    for a *slight* improvement in speed
  ApproxObsCovar_dbl(fit_type,NOvals,x_vals,fit_params,fit_covar,obs_covar,x_min,x_max);
  
  // build python return object
  py_return = PyTuple_New((Py_ssize_t) 2);
  py_list_i = PyList_New((Py_ssize_t) 7);
  for(i = 0; i < 7; i++){

    PyList_SetItem(py_list_i,(Py_ssize_t) i,PyFloat_FromDouble(sqrtf(obs_covar[i][i])));

  }
  PyTuple_SetItem(py_return,(Py_ssize_t) 0,py_list_i);
  py_list_j = PyList_New((Py_ssize_t) 7);
  for(j = 0; j < 7; j++){
    
    py_list_i = PyList_New((Py_ssize_t) 7);
    for(i = 0; i < 7; i++){

      PyList_SetItem(py_list_i,(Py_ssize_t) i,PyFloat_FromDouble(obs_covar[j][i]));

    }
    PyList_SetItem(py_list_j,(Py_ssize_t) j,py_list_i);

  }
  PyTuple_SetItem(py_return,(Py_ssize_t) 1,py_list_j);
  
  // free up C arrays
  free(x_vals);
  free(fit_params);
  for(i = 0; i < 8; i++){ free(fit_covar[i]); }
  free(fit_covar);
  for(i = 0; i < 7; i++){ free(obs_covar[i]); }
  free(obs_covar);

  // return a Python tuple containing the results
  return py_return;

}

// method table and initialisation function
static PyMethodDef BFmethods[] = {

  {"fit", BusyFunc_Fit, METH_VARARGS, "Fit the Busy Function to arrays of x, y and y-error values. \n\nThis package fits the Busy Function (see Westmeier, Jurek, Obreschkow & Koribalski 2013) to user supplied data. This package uses the implementation described in Westemeier et al. (2013). Please cite this paper in any published works that utilise this package. \n\nThis package fits the following forumulation of the Busy Function,\n\ny(x) = 0.25 * alpha * {1 + erf[beta_1 * (x - gamma_1)]} * {1 + erf[beta_2 * (gamma_2 - x)]} * {1 + phi * [x - theta]^N},\n\nwhere the following constraints are applied using variable re-mapping: alpha >= 0.0, beta_1 >= 0.0, beta_2 >= 0.0, phi >= 0.0, 2 <= N <= 8, x_min <= gamma_1 <= x_max, x_min <= gamma_2 <= x_max and x_min <= theta <= x_max. Note that the beta_1 and beta_2 constraints implicitly imposes a weak constraint, gamma_1 (almost always) <= gamma_2. \n\nUsage: (fit_type,dims,fit_params,fit_covar) = BusyFunc.fit(x_vals,y_vals,y_err_vals,verbose_flag,x_min,x_max,NOs,iter_max) \n\nInput: \nThis package takes eight arguments. The first three are lists containing the x values, y values and errors in the y values. A list of \"1\"s should be used when you don\'t have/want to use uncertainties in the y values. Alternatively, spuriously large uncertainties can be assigned to y values that you want the fitting program to ignore eg. channels dominated by RFI in integrated HI spectra.\n\nThe verbose_flag specifies the amount of diagnostic output displayed on the terminal. Values of -1, 0 and 1 generate none, minimal, and maximal diagnostic output.\n\nThe x_min and x_max values specifies the region within the data believed to contain signal. This can be set to x_vals[0] and x_vals[len(x_vals) - 1] without causing any problems. If you know that the first 10 and last 20 values are noise however, setting x_min and x_max accordingly will improve your fitting results.\n\nNOs is the number of LVM starting seeds to use. Specify a number greater than 0.\n\niter_max is the maximum number of iterations to use for each individual LVM seed.\n\nOutput:\nThis package returns a 3-tuple containg two integers and two lists. The first tuple is an integer value. It correspons to the BF variant that was the best fit. Possible values are 1 through 6. The second tuple value is an integer value. It is the dimensionality of the Busy Function variant that was the best fit. Possible values are 4 through 8. The second tuple is a list. This list contains 17 float values. The first 16 are the Busy Function fit values and their uncertainties. The final value is the chi-squared value of the Busy Function fit. The second list is 64 float values. It is structured as 8 lists of lists of 8 float values. This second structure contains the covariance matrix of the Busy Function fit. The covariance matrix can be used to check for degeneracies in the Busy Function fit.\n\nOutput structure:\n\n fit_params = \n(alpha, alpha error,\nbeta_1, beta_1 error,\ngamma_1, gamma_1 error,\nbeta_2, beta_2 error,\ngamma_2, gamma_2 error\nphi, phi error,\ntheta, theta error,\nN, N error)\n\nfit_covar = \n([alpha x alpha, alpha x beta_1, alpha x gamma_1, alpha x beta_2, alpha x gamma_2, alpha x phi, alpha x theta, alpha x N]\n[beta_1 x alpha, beta_1 x beta_1, beta_1 x gamma_1, beta_1 x beta_2, beta_1 x gamma_2, beta_1 x phi, beta_1 x theta, beta_1 x N]\n[gamma_1 x alpha, gamma_1 x beta_1, gamma_1 x gamma_1, gamma_1 x beta_2, gamma_1 x gamma_2, gamma_1 x phi, gamma_1 x theta, gamma_1 x N]\n[beta_2 x alpha, beta_2 x beta_1, beta_2 x gamma_1, beta_2 x beta_2, beta_2 x gamma_2, beta_2 x phi, beta_2 x theta, beta_2 x N]\n[gamma_2 x alpha, gamma_2 x beta_1, gamma_2 x gamma_1, gamma_2 x beta_2, gamma_2 x gamma_2, gamma_2 x phi, gamma_2 x theta, gamma_2 x N]\n[phi x alpha, phi x beta_1, phi x gamma_1, phi x beta_2, phi x gamma_2, phi x phi, phi x theta, phi x N]\n[theta x alpha, theta x beta_1, theta x gamma_1, theta x beta_2, theta x gamma_2, theta x phi, theta x theta, theta x N]\n[N x alpha, N x beta_1, N x gamma_1, N x beta_2, N x gamma_2, N x phi, N x theta, N x N])\n\n"},
  {"refine",BusyFunc_Refine, METH_VARARGS, "Fit a busy function using a single, user-specified starting position. This function uses a user specified number of iterations, iter_max, to improve upon a starting position. This function can be used to refine the output from this module's .fit method. \n\nUsage: (fit_type,dims,fit_params,fit_covar) = BusyFunc.fit(x_vals,y_vals,y_err_vals,verbose_flag,x_min,x_max,NOs,iter_max,start_position) \n\nInput:\nAll the inputs of BusyFunc.fit and an extra list at the end. This list at the end, start_position, has the same structure as the fit_params output of BusyFunc.fit(). This makes it easy to use this function to improve upon the results of a call to BusyFunc.fit(). Note that this method *ONLY* uses the 8 fit parameter values in start_position. The uncertainties and chi^2 value are superfluous. They can be set to arbitrary values without affecting this method's output.\n\nOutput: The same as this module's .fit method. \n\n"},
  {"rand_fits", BusyFunc_CreateRandFits, METH_VARARGS, "Generate random variations of a Busy Function fit using the fit and its covariance matrix. \n\nUsage: rand_fits = (NOr,fit_type,fit_params,fit_covar,x_min,x_max,vb_flag)\n\nInput:\nThe inputs, in order, are: the number of random fits to create; the numerical ID of the BF fit type returned by BusyFunc.fit() --- values range from 1 to 6; the BF fit parameters list returned by BusyFunc.fit(); the list of 8 lists structure returned by BusyFunc.fit() that contains the covariance matrix; the next two values are the x_min and x_max values input to BusyFunc.fit(), and the final value is a verbose flag --- -1, 0 and 1 generate none, minimal, and maximal diagnostic output.\n\nIt is *VERY* important that the x_min and x_max values match those used in BusyFunc.fit() (& BusyFunc.refine()), or the internal variable mapping used to constrain the fit parameters will be wrong. This will not cause a fault in this method (it has no way to tell what x_min and x_max should be!), but it will cause erroneous output.\n\nOutput: The output is a list of lists structure. It consists of NOr lists of 8 float values. Each list of 8 values is a properly correlated, random variant of the input Busy Function (fit_params).\n\n"},
  {"obs_vals", BusyFunc_CalcObsVals, METH_VARARGS, "Calculate 7 observational parameters for each Busy Function fit supplied by the user. \n\nUsage: obs_vals = BusyFunc.obs_vals(BF_fits,x_vals,vb_flag)\n\nInput:\nThe inputs, in order, are: a list of lists structure containing 8 Busy Function fit values for each object; the x values of the input data, and the final value is a verbose flag --- -1, 0 and 1 generate none, minimal, and maximal diagnostic output. The BF_fits list of lists structure matches the structure of the BusyFunc.rand_fits output. These two methods can be chained together. In this instance, BF_fits is equal to rand_fits.\n\nOutput:\nThe output is a list of lists structure. There is a list of 7 float values for each set of 8 Busy Function parameter values in the input list (BF_fits). Each list of 7 float values is a set of observational parameter values --- total intensity, peak intensity, peak intensity position, W_50, W_50 centre, W_20, W_20 centre.\n\n"},
  {"obs_stats", BusyFunc_AnalyseObsVals, METH_VARARGS, "Calculate 8 statistical properties for a list of obesrvational values. \n\nUsage: obs_stats = BusyFunc.obs_stats(obs_vals,vb_flag)\n\nInput:\nThe inputs, in order, are: a list of observational properties, and a verbose flag --- -1, 0 and 1 generate none, minimal, and maximal diagnostic output.\n\nThe output is a list of 8 statistical properties for each of the 7 observational properties (see BusyFunc.obs_vals()). This is stored in a list of lists structure. 7 lists of 8 float values. These 8 float values are (in order): median; inter-quartile range scaled to standard deviations; minimum; maximum; mean; standard deviation; skewness, and kurtosis.\n\n"},
  {"approx_obs_covar",BusyFunc_ApproxObsCovar, METH_VARARGS, "Calculate an approximation of the observable parameter covariance matrix from a busy function fit and covariance matrix. This covariance matrix and the corresponding uncertainties in the observable parameters are returned. \n\nUsage: (approx_errs, approx_obs_covar) = BusyFunc.approx_obs_covar(fit_type,x_vals,fit_params,fit_covar,x_min,x_max)\n\nInput:\nThe input is an integer, 2 lists of floats, a list of lists structure (8 of 8), and two floats.\nThe fit_type is the BF variant ID returned by BusyFunc.fit --- values 1 through 6.\nx_vals is the same as BusyFunc.fit().\nfit_params and fit_covar are the BusyFunc.fit() and BusyFunc.refine() output.\nx_min and x_max are the float values used to do the internal mapping.\n\nIt is *VERY* important that the x_min and x_max values match those used in BusyFunc.fit() (& BusyFunc.refine()), or the internal variable mapping used to constrain the fit parameters will be wrong. This will not cause a fault in this method (it has no way to tell what x_min and x_max should be!), but it will cause erroneous output. \n\nOutput:\nThe first tuple element is a list of observational parameter uncertainties. The second is a list of lists structure. 7 lists of 7 float values. \n\napprox_obs_covar = \n([total_flux x total flux, total flux x peak flux, total flux x peak flux position, total flux x W_50, total flux x W_50 centre, total flux x W_20, total flux x W_20 centre]\n[peak flux x total flux, peak flux x peak flux, peak flux x peak flux position, peak flux x W_50, peak flux x W_50 centre, peak flux x W_20, peak flux x W_20 centre]\n[peak flux position x total flux, peak flux position x peak flux, peak flux position x peak flux position, peak flux position x W_50, peak flux position x W_50 centre, peak flux position x W_20, peak flux position x W_20 centre]\n[W_50 x total flux, W_50 x peak flux, W_50 x peak flux position, W_50 x W_50, W_50 x W_50 centre, W_50 x W_20, W_50 x W_20 centre]\n[W_50 centre x total flux, W_50 centre x peak flux, W_50 centre x peak flux position, W_50 centre x W_50, W_50 centre x W_50 centre, W_50 centre x W_20, W_50 centre x W_20 centre]\n[W_20 x total flux, W_20 x peak flux, W_20 x peak flux position, W_20 x W_50, W_20 x W_50 centre, W_20 x W_20, W_20 x W_20 centre]\n[W_20 centre x total flux, W_20 centre x peak flux, W_20 centre x peak flux position, W_20 centre x W_50, W_20 centre x W_50 centre, W_20 centre x W_20, W_20 centre x W_20 centre])\n\n"},
  {NULL,NULL,0,NULL} /* sentinel */

};

// Initialise module depending on whether it's Python v2.+ or v3.+
#if PY_MAJOR_VERSION >= 3
// Python 3 initialisation

// define module definition
static struct PyModuleDef BusyFuncmodule = {
  PyModuleDef_HEAD_INIT,
  "BusyFunc",
  NULL,
  -1,
  BFmethods
};

// define module initialisation function, which loads module definition and method table
PyMODINIT_FUNC
PyInit_BusyFunc(void)
{
  return PyModule_Create(&BusyFuncmodule);
}

#else
// Python 2 initialisation

// define module initialisation function, which loads method table
PyMODINIT_FUNC
initBusyFunc(void) 
{
  (void) Py_InitModule("BusyFunc", BFmethods);
}

#endif

