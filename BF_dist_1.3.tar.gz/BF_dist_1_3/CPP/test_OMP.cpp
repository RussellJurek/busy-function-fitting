#include<iostream>
#include<omp.h>

using namespace std;

int main(){

  int i = omp_get_num_procs();
  cout << i << " cores found." << endl;

}

