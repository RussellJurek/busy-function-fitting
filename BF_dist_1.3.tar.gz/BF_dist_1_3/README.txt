V1.2 --- Created by Russell J. Jurek, 30th December 2013.
V1.1 --- Created by Russell J. Jurek, 9th November 2013. 
V1.0 --- Created by Russell J. Jurek, 30th June 2013. 
Email: Russell.Jurek@gmail.com 

===============================================================================================================================
OVERVIEW
===============================================================================================================================
This package fits the Busy Function (see Westmeier, Jurek, Obreschkow & Koribalski 2013) to user supplied data. This package 
uses the implementation described in Westemeier et al. (2013). Please cite this paper in any published works that utilise this 
package. 

This package fits the following forumulation of the Busy Function,

y(x) = 0.25 * alpha * {1 + erf[beta_1 * (x - gamma_1)]} * {1 + erf[beta_2 * (gamma_2 - x)]} * {1 + phi * [x - theta]^N},

where the following constraints are applied using variable re-mapping: alpha >= 0.0, beta_1 >= 0.0, beta_2 >= 0.0, 
phi >= 0.0, 2 <= N <= 8, x_min <= gamma_1 <= x_max, x_min <= gamma_2 <= x_max and x_min <= theta <= x_max. Note 
that the beta_1 and beta_2 constraints implicitly imposes a weak constraint, gamma_1 (almost always) <= gamma_2. 

This package consists of a C library, C++ library and a Python module. It does *NOT* require any other libraries. It is 
self contained and *FREE* for academic (research & teaching) purposes. 

This package is structured in the following way:

sub-directory C: Contains the source code for the C library. After installation, this will contain the C libraries
                 libcBFfit_OMP.a and libcBFfit.a. The OMP enabled library will not be created if the specified C compiler,
		 CC, doesn't support OMP.

		 A symbolic link, libPyBFfit.a, will be created in the python sub-directory. It will point to 
		 libcBFfit_OMP.a if it exists, and to libcBFfit.a otherwise. Similarly, a symbolic link to the 
		 corresponding header file will be created in the python sub-directory, PyBFfit.h. The C libraries and 
		 symbolic link *MUST* be installed before attempting to install the Python module. 

		 You will also find example C programs (cFitSpectrum.c & cFitSpectrum_Wplots.c) demonstrating how to use  
		 the C library. 
		 These example programs can be used to fit the Busy Function to a text file containing x, y and noise 
		 values --- each line is a frequency/wavelength.

sub-directory CPP: Contains the source code for the C++ library. After installation, this will contain the C++ libraries
                   libBFfit_OMP.a and libBFfit.a. The OMP enabled library will not be created if the specified C++ 
		   compiler, CXX, doesn't support OMP.

		   You will also find example C++ programs (FitSpectrum.cpp & FitSpectrum_Wplots.cpp) 
		   demonstrating how to use the C++ library. This example program can be used to fit the Busy Function 
		   to a text file containing x, y and noise values --- each line is a frequency/wavelength.

sub-directory python: Contains the python wrapper required to build the python module, BusyFunc, from the symbolic link to
	      	      the C library, libPyBFfit.a and PyBFfit.h. CAUTION: The C library *MUST* be built before attempting 
		      to create this python module. After installation this directory will contain a build of the BusyFunc 
		      module. 

		      You will also find an example python script (FitSpectrum.py) demonstrating how to use the module. 
		      This example program can be used to fit the Busy Function to a text file containing x, y and noise 
		      values --- each line is a frequency/wavelength.

		      IMPORTANT: The same compiler *must* be used to build the C library and python module.

		      USEFUL TIP: The python module is statically built within the `python/build' sub-directory. You can 
		      	     	  build the C library with the same compiler as your python instatllation, build the 
				  python module; and then re-build the C library with a different compiler. This is 
				  particularly useful if you use multiple python versions, which use different default
				  compilers.

sub-directory bin: After installation, this directory will contain the FitSpectrum, FitSpectrum_Wplots, cFitSpectrum and 
	      	   cFitSpectrum_Wplots programs. If possible, the programs will be built using the OMP enabled libraries.
		   The *_Wplots programs will *only* be created if a valid PGPLOT installation has been specified in,
		   PGPLOT_DIR.

sub-directory test_data: This directory contains 19 test files that can be used with any of the test programs to verify your
	      		 installation. The first line in each file contains the input parameters used to generate this data 
			 file. The order of these parameters matches the output structure of this package (see below). It 
			 also contains a demonstration of the analysis that is possible using a BF fit, test_BF_1_BFplots.tar.gz.

===============================================================================================================================
INSTALLATION
===============================================================================================================================

---------------------------------------
C/C++
---------------------------------------
Follow these instructions to compile and install the C & C++ libraries. 

1. At the terminal, navigate to the top level directory where you found this README.

2. Execute the command,
   
   make all [INSTALL_DIR=path-to-put-libraries] [INSTALL_INC=path-to-put-headers] [PGPLOT_DIR=path-to-pgplot-installation]
   	    [CC=path-to-C-compiler] [CXX=path-to-C++-compiler]
   
   The C & C++ libraries will now be built and the C & C++ example programs will be in the bin sub-directory. The inputs in 
   brackets are optional. If they aren't specified, then the makefile will use the standard linux location for
   libraries and include files as defaults: /usr/local/lib & /usr/local/include. The makefile will also try to use your
   default pgplot installation (if it exists) by calling the PGPLOT_DIR environment variable. If this variable doesn't 
   exist (because you don't have pgplot) or the necessary files can't be found, then make will skip the creation of 2 of 
   the demo programs that use the pgplot C library. It isn't a big deal. The C & C++ libraries themselves don't rely on pgplot.

   The default CC and CXX values are,
       CC=cc
       CXX=c++
   On most systems these will be symbolic links to your default C/C++ compilers. If this isn't the case, then you specify
   the path to the C/C++ compilers using these environment variables.

   On Mac OS X 10.8+ systems the default C/C++ compiler isn't a genuine GCC compiler. The default C/C++ compiler is a 
   clang-based compiler. If (like me) you've installed a genuine GCC compiler on a Mac OS X 10.8+ system, then you may run into
   a problem. The default python 2.7+ on Mac OS X 10.8+ systems has been compiled using the clang-based compiler. Set the CC
   argument to, CC=/usr/bin/llvm-gcc , to use the clang-based C compiler that comes with OS X 10.8+. The C library created
   this way will be compatible with the compiler called by the default python installation. 

3. An optional command is,
   
   make install

   This will copy the C & C++ libraries and headers to the locations in INSTALL_DIR and INSTALL_INC. The default locations 
   are /usr/local/lib & /usr/local/include.

   PERMISSION DENIED ERROR!!! Simple fix. Use the `sudo' command when trying to install the C/C++ libraries,

   sudo make install

4. A second optional command is,

   make clean

   This will delete the object (*.o) files that are turned into the C/C++ libraries.

If something goes wrong, make sure to execute the command,

   make distclean

before trying again. This will remove the object files (*.o), any failed attempts to build the C/C++ library and C/C++ programs.
On OS X (Mac), the ranlib tool will sometimes fail if it finds a previous, failed attempt to create a library. It's part of 
the Mac OS X setup. There's nothing I can do about it.

In summary,

   make all
   make install

You're done.

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! WARNING !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Newer versions of Mac OS X don't actually use the GCC compiler. They use Clang. Unfortunately Clang isn't capable of
implementing OMP. What's really annoying is that your laptop will appear to have gcc, but this is just a symbolic link in 
/usr/bin to Clang. If OMP fails on a Mac OS X because of OMP.h or -fopenmp, then /usr/bin/gcc is pointing to a Clang 
compiler. The solution is simple. Install a genuine gcc compiler. It's free and binaries exist to make it very simple. OMP
is important because it lets the Levenberg-Marquardt-Jurek (LVM-J) algorithm leverage a multi-core CPU. An N-core system
will theoretically run Nx faster with this algorithm, because all seeds are independent. In short, the performance gains of
OMP are worth installing a genuine GCC compiler. 

The v1.2 Busy Function distribution compiles both an OMP enabled (if possible) and OMP disabled C/C++ library. If you aren't
interested in maximum performance, then you can just use the OMP disabled C/C++ libraries. When using the Mac OS X 10.8+ 
default python installation, this is generally the easiest installation method.

---------------------------------------
Python
---------------------------------------
Follow these instructions to build the python module, BusyFunc.
1. Create the C library first. This is a NECESSITY!
2. Navigate to the BF_dist/python sub-directory in the terminal.
3. Build the BusyFunc module with the command,

   python setup.py build

   This will create a BF_dist/python/build sub-directory containg a local copy of the BusyFunc module. 

4. Integrate the BusyFunc module into your python installation,

   python setup.py install

If you need to start over, you can use the following command,

   python setup.py clean

You might need to delete the `python/build' sub-directory though. 

WARNING!!! On some systems, your C/C++ compiler might build a library for a different architecture than the target 
	   architecture used by your python installation. This can happen if you use multiple compilers/python installations.
	   The simplest solution is to specify a target architecture for either the C library or the python module. Option 1 
	   is to recreate the C library with the appropriate value of the "-arch" flag ("-arch i386" and/or "-arch x86_64") for 
	   Mac OS X compilers or the "-m" flag for genuine GCC compilers ("-m32" and/or "-m64"). 
	   Option 2 is to specify the python architecture, for example,
	   
	   ARCHFLAGS="-arch x86_64" python setup.py build
	   python setup.py install

	   You can also use the ARCHFLAGS to limit the python module to a single architecture. This is only necessary if you've
	   built the C library for a single architecture, but your python installation is trying to build a universal module
	   (32-bit and 64-bit). Again you have two options. Either create a universal C library or specify a single architecture.

WARNING!!! If you're using a Mac OS X 10.8+ system, then your default python installation was most likely built using the 
	   clang-based compiler at /usr/bin/llvm-gcc. If you've changed your system's default compiler, then you will probably
	   need to specify that the setup.py script uses this compiler, for example,

	   CC=/usr/bin/llvm-gcc ARCHFLAGS="-arch x86_64" python setup.py build
	   python setup.py install

PERMISSION DENIED ERROR!!! Simple fix. Use the `sudo' command when trying to install the python module,

	   sudo python setup.py install

===============================================================================================================================
USAGE
===============================================================================================================================

---------------------------------------
C core functionality
---------------------------------------

Usage:

int FitBusyFunc_flt(int NOvals, float * x_vals, float * y_vals, float * n_vals, float * fit_params, float ** fit_covar, int * best_NOp, int NOs, int iter_max, int vb_flag);

    or

int FitBusyFunc_dbl(int NOvals, double * x_vals, double * y_vals, double * n_vals, double * fit_params, double ** fit_covar, int * best_NOp, int NOs, int iter_max, int vb_flag);

Two versions of the Busy Function fitting routine are provided for processing either single-precision (float) or 
double-precision (double) data.

Input:
This function takes 10 iputs. The first is the number of data points. The next three are pointers/arrays containing the 
x values, y values and errors in the y values. A list of "1"s should be used when you don't have/want to use uncertainties 
in the y values. Alternatively, spuriously large uncertainties can be assigned to y values that you want the fitting program 
to ignore eg. channels dominated by RFI in integrated HI spectra.

The next two arguments, fit_params and fit_covar, are pointers/arrays that will contain the fitting results.

WARNING!!! fit_params[4] and fit_params[8] *MUST* be populated with x_min and x_max limits. These x_min and x_max limits are
applied to the error function positions. Note that these values will be range tested against the limits of the x_vals array.

The integer pointer best_NOp contains the dimensionality of the best Busy Function fit. An integer variable can be used instead
of an integer pointer by passing the address of the integer to the function eg. &best_NOp.

The number of randomly generated Levenberg-Marquardt seeds used to carry out the fitting is specified by NOs. The maximum 
number of LVM iterations applied to each seed is specified by iter_max. If you don't wish to use random LVM seeds, then NOs 
can be set to -1, and the values in the fit_params array will be used as the sole LVM seed. In this situation, the x_min and
x_max limits are set to: 

x_min = max{x_vals[0],(0.5*(fit_params[4] + fit_params[8]) - 0.5*(fit_params[8] - fit_params[4]))}
x_max = min{x_vals[(NOvals - 1)],(0.5*(fit_params[4] + fit_params[8]) + 0.5*(fit_params[8] - fit_params[4]))}

The vb_flag is an integer that specifies the amount of diagnostic output displayed on the terminal. Values of -1, 0 and 1 
generate none, minimal, and maximal diagnostic output.

Output:
This function's return value is a numerical value corresponding to the BF variant that was the best fit.
Value	BF variant
-----	----------------------------------------------------------------------------------------------------------------------
1	4 parameters; maximum symmetry and no power-law	
2	5 parameters; no forced symmetry, but no power-law
3	5 parameters; maximum symmetry and power-law = 4
4	6 parameters; maximum symmetry and power-law = ?
5	7 parameters; intermediate symmetry (symmetric error functions, but power-law is off-centre) and power-law = ?
6	8 parameters; no forced symmetry and power-law = ? ==> use previous fitting results

The input arguments, fit_params and fit_covar, contain the fitting results. The structure is described at the end.


---------------------------------------
C extended functionality
---------------------------------------

1. CreateRandFits
-----------------
This function generates completely correlated, random variants of a Busy Function fit from the fit and its covariance matrix.

Usage:

CreateRandFits_flt(NOr,rand_fits,fit_type,fit_params,fit_covar,fit_x_min,fit_x_max,vb_flag);

or

CreateRandFits_dbl(NOr,rand_fits,fit_type,fit_params,fit_covar,fit_x_min,fit_x_max,vb_flag);

Input:

NOr is an integer value. It is the number of random variants that you would like to create.

rand_fits is a pointer-to-a-pointer. It stores the resulting NOr fits, each one being 8 values. Memory must be allocated
to this pointer-to-a-pointer before it is passed to this function. It should be allocated as a pointer to NOr pointers to
8 values e.g. rand_fits = new float * [NOr]; for(i = 0; i < NOr; ++i){ rand_fits[i] = new float[8]; }.

fit_type is an integer value. It is the fit_type returned by FitBusyFunc(). Values range from 1 to 6.

fit_params is the 17 element array (as a pointer) returned by FitBusyFunc().

fit_covar is the 64 element array (as a pointer) returned by FitBusyFunc().

fit_x_min is the lower limit input to FitBusyFunc(). It *MUST* be identical to the value used to generate fit_params and fit_covar
using FitBusyFunc().

fit_x_max is the upper limit input to FitBusyFunc(). It *MUST* be identical to the value used to generate fit_params and fit_covar
using FitBusyFunc().

vb_flag is an integer value. It sets the verbosity of the function. -1 = none, 0 = minimal and 1 = maximal.

Output:

NOr correlated, random variants of the input BF fit. They are returned in rand_fits. This is a pointer-to-a-pointer structure.
Each random variant consists of 8 values, in the following order: alpha, beta_1, gamma_1, beta_2, gamma_2, phi, theta, N. 
These values will be zeroed accordingly for fit_type < 6.

2. CalcObsParams
----------------
This function calculates 7 observational parameters for a list of BF fits. The 7 observational parameters are: total flux, peak flux,
peak flux position, W_50 width, W_50 centre, W_20 width and W_20 centre.

Usage:

CalcObsParams_flt(NOr,rand_fits,NOvals,x_vals,rand_obs_vals,vb_flag);

or

CalcObsParams_dbl(NOr,rand_fits,NOvals,x_vals,rand_obs_vals,vb_flag);


Input:

NOr is an integer value. It is the number of BF fits that you want to calculate observational parameters for.

rand_fits is a pointer-to-a-pointer structure. It has the same layout as rand_fits in CreateRandFits(). This allows the output of
CreateRandFits() to be directly input to this function.

NOvals is an integer value. It is the number of data points that was used in FitBusyFunc().

x_vals is an array (as a pointer). It is the x values that were used in FitBusyFunc().

rand_obs_vals is a pointer-to-a-pointer. It stores the resulting NOr sets of observational values, each one being 7 values. 
Memory must be allocated to this pointer-to-a-pointer before it is passed to this function. It should be allocated as a pointer
to NOr pointers to 7 values e.g. rand_obs_vals = new float * [NOr]; for(i = 0; i < NOr; ++i){ rand_obs_vals[i] = new float[8]; }.

vb_flag is an integer value. It sets the verbosity of the function. -1 = none, 0 = minimal and 1 = maximal.

Output:

NOr sets of 7 observational parameters. They are returned in rand_obs_vals. This is a pointer-to-a-pointer structure.
Each set of observational parameters consists of, in order: total flux, peak flux, peak flux position, W_50 width, W_50 centre,
W_20 width, W_20 centre.

3. AnalyseObsVals
-----------------
This function carries out a basic statistical analysis of sets of observational parameters. It returns the median, inter-quartile
range (in standard deviations), minimum, maximum, mean, standard deviation, skewness and kurtosis.

Usage:

AnalyseObsVals_flt(NOr,NOparams,rand_obs_vals,obs_stats,vb_flag);

or

AnalyseObsVals_dbl(NOr,NOparams,rand_obs_vals,obs_stats,vb_flag);

Input:

NOr is an integer value. It is the number of sets of observational parameters to analyse.

NOparams is an integer value. It is the number of parameters in a set. The default value is 7. This isn't fixed to 7. This allows you to
calculate/add additional parameters (such as flag values) to each object.

rand_obs_vals is a pointer-to-a-pointer structure. It has the same layout as rand_obs_vals in CalcObsParams(). This allows the output of
CalcObsParams() to be directly input to this function.

obs_stats is a pointer-to-a-pointer. It contains the results of the analysis. Memory must be allocated for this structure prior to calling
this function. It should be allocated as a pointer to NOparams pointers to 8 values e.g. 
obs_stats = new float * [NOparams]; for(i = 0; i < NOparams; ++i){ obs_stats[i] = new float[8]; }.

vb_flag is an integer value. It sets the verbosity of the function. -1 = none, 0 = minimal and 1 = maximal.

Output:

A statistical analysis of NOparams from NOr sets of parameter values. For each parameter, this function returns, in order: median,
inter-quartile range (in standard deviations), minimum, maximum, mean, standard deviation, skewness & kurtosis.

4. ApproxObsCovar
-----------------
This function assumes an unknown, linear dependence of observational parameters on the BF fit values. Under this assumption, a numerical
approximation of the Jacobian of the observational parameters w.r.t. the Bf fits is calculated (J), and applied to the BF fit covariance 
matrix (C). The result of J^T*C*J is a linear approximation of the observational parameter covariance matrix.

Usage:
ApproxObsCovar_flt(fit_type,NOvals,x_vals,fit_params,fit_covar,obs_covar,fit_x_min,fit_x_max);

or

ApproxObsCovar_dbl(fit_type,NOvals,x_vals,fit_params,fit_covar,obs_covar,fit_x_min,fit_x_max);

Input:

fit_type is an integer value. It is the value returned by FitBusyFunc().

NOvals is an integer value. It is the number of data points that was used in FitBusyFunc().

x_vals is an array (as a pointer). It is the x values that were used in FitBusyFunc().

fit_params is the 17 element array (as a pointer) returned by FitBusyFunc().

fit_covar is the 64 element array (as a pointer) returned by FitBusyFunc().

obs_covar is a pointer-to-a-pointer. It is a pointer to 7 pointers to 7 values. Memory for this structure must be allocated before
calling this function e.g. obs_covar = new float[7]; for(i = 0; i < 7; ++i){ obs_covar[i] = new float[7]; }. The linear approximation
of the observational parameter covariance matrix is returned in this structure.

fit_x_min is the lower limit input to FitBusyFunc(). It *MUST* be identical to the value used to generate fit_params and fit_covar
using FitBusyFunc().

fit_x_max is the upper limit input to FitBusyFunc(). It *MUST* be identical to the value used to generate fit_params and fit_covar
using FitBusyFunc().

Output:

A 7 by 7, linear approximation to the observational parameter covariance matrix is returned in obs_covar. Running from top to bottom and left
to right, the covariance elements correspond to: total flux, peak flux, peak flux position, W_50 width, W_50 centre, W_20 width & W_20 centre. 


---------------------------------------
C++ core functionality
---------------------------------------

Usage:

template <class T_count, class T_xvals, class T_data, class T_result>
  int FitBusyFunc(T_count NOvals, T_xvals * x_vals, T_data * y_vals, T_data * n_vals, T_result * fit_params, T_result ** fit_covar, int & best_NOp, int NOs, int iter_max, int vb_flag){ . . .}

This C++ library utilises templated functions to allow flexible data types for both input and output.

Input:
This function takes 10 iputs. The first is the number of data points. The next three are pointers/arrays containing the 
x values, y values and errors in the y values. A list of "1"s should be used when you don't have/want to use uncertainties 
in the y values. Alternatively, spuriously large uncertainties can be assigned to y values that you want the fitting program 
to ignore eg. channels dominated by RFI in integrated HI spectra.

The next two arguments, fit_params and fit_covar, are pointers/arrays that will contain the fitting results. 

WARNING!!! fit_params[4] and fit_params[8] *MUST* be populated with x_min and x_max limits. These x_min and x_max limits are
applied to the error function positions. Note that these values will be range tested against the limits of the x_vals array.

The integer best_NOp contains the dimensionality of the best Busy Function fit.

The number of randomly generated Levenberg-Marquardt seeds used to carry out the fitting is specified by NOs. The maximum 
number of LVM iterations applied to each seed is specified by iter_max. If you don't wish to use random LVM seeds, then NOs 
can be set to -1, and the values in the fit_params array will be used as the sole LVM seed. In this situation, the x_min and
x_max limits are set to: 

x_min = max{x_vals[0],(0.5*(fit_params[4] + fit_params[8]) - 0.5*(fit_params[8] - fit_params[4]))}
x_max = min{x_vals[(NOvals - 1)],(0.5*(fit_params[4] + fit_params[8]) + 0.5*(fit_params[8] - fit_params[4]))}

The verbose_flag is an integer that specifies the amount of diagnostic output displayed on the terminal. Values of -1, 0 and 1 
generate none, minimal, and maximal diagnostic output.

Output:
This function's return value is a numerical value corresponding to the BF variant that was the best fit.
Value	BF variant
-----	----------------------------------------------------------------------------------------------------------------------
1	4 parameters; maximum symmetry and no power-law	
2	5 parameters; no forced symmetry, but no power-law
3	5 parameters; maximum symmetry and power-law = 4
4	6 parameters; maximum symmetry and power-law = ?
5	7 parameters; intermediate symmetry (symmetric error functions, but power-law is off-centre) and power-law = ?
6	8 parameters; no forced symmetry and power-law = ? ==> use previous fitting results

The input arguments, fit_params and fit_covar, contain the fitting results. The structure is described at the end.


---------------------------------------
C++ extended functionality
---------------------------------------

1. CreateRandFits
-----------------
This function generates completely correlated, random variants of a Busy Function fit from the fit and its covariance matrix.

Usage:

CreateRandFits(NOr,rand_fits,fit_type,fit_params,fit_covar,fit_x_min,fit_x_max,vb_flag);

Input:

NOr is an integer value. It is the number of random variants that you would like to create.

rand_fits is a pointer-to-a-pointer. It stores the resulting NOr fits, each one being 8 values. Memory must be allocated
to this pointer-to-a-pointer before it is passed to this function. It should be allocated as a pointer to NOr pointers to
8 values e.g. rand_fits = new float * [NOr]; for(i = 0; i < NOr; ++i){ rand_fits[i] = new float[8]; }.

fit_type is an integer value. It is the fit_type returned by FitBusyFunc(). Values range from 1 to 6.

fit_params is the 17 element array (as a pointer) returned by FitBusyFunc().

fit_covar is the 64 element array (as a pointer) returned by FitBusyFunc().

fit_x_min is the lower limit input to FitBusyFunc(). It *MUST* be identical to the value used to generate fit_params and fit_covar
using FitBusyFunc().

fit_x_max is the upper limit input to FitBusyFunc(). It *MUST* be identical to the value used to generate fit_params and fit_covar
using FitBusyFunc().

vb_flag is an integer value. It sets the verbosity of the function. -1 = none, 0 = minimal and 1 = maximal.

Output:

NOr correlated, random variants of the input BF fit. They are returned in rand_fits. This is a pointer-to-a-pointer structure.
Each random variant consists of 8 values, in the following order: alpha, beta_1, gamma_1, beta_2, gamma_2, phi, theta, N. 
These values will be zeroed accordingly for fit_type < 6.

2. CalcObsParams
----------------
This function calculates 7 observational parameters for a list of BF fits. The 7 observational parameters are: total flux, peak flux,
peak flux position, W_50 width, W_50 centre, W_20 width and W_20 centre.

Usage:

CalcObsParams(NOr,rand_fits,NOvals,x_vals,rand_obs_vals,vb_flag);

Input:

NOr is an integer value. It is the number of BF fits that you want to calculate observational parameters for.

rand_fits is a pointer-to-a-pointer structure. It has the same layout as rand_fits in CreateRandFits(). This allows the output of
CreateRandFits() to be directly input to this function.

NOvals is an integer value. It is the number of data points that was used in FitBusyFunc().

x_vals is an array (as a pointer). It is the x values that were used in FitBusyFunc().

rand_obs_vals is a pointer-to-a-pointer. It stores the resulting NOr sets of observational values, each one being 7 values. 
Memory must be allocated to this pointer-to-a-pointer before it is passed to this function. It should be allocated as a pointer
to NOr pointers to 7 values e.g. rand_obs_vals = new float * [NOr]; for(i = 0; i < NOr; ++i){ rand_obs_vals[i] = new float[8]; }.

vb_flag is an integer value. It sets the verbosity of the function. -1 = none, 0 = minimal and 1 = maximal.

Output:

NOr sets of 7 observational parameters. They are returned in rand_obs_vals. This is a pointer-to-a-pointer structure.
Each set of observational parameters consists of, in order: total flux, peak flux, peak flux position, W_50 width, W_50 centre,
W_20 width, W_20 centre.

3. AnalyseObsVals
-----------------
This function carries out a basic statistical analysis of sets of observational parameters. It returns the median, inter-quartile
range (in standard deviations), minimum, maximum, mean, standard deviation, skewness and kurtosis.

Usage:

AnalyseObsVals(NOr,NOparams,rand_obs_vals,obs_stats,vb_flag);

Input:

NOr is an integer value. It is the number of sets of observational parameters to analyse.

NOparams is an integer value. It is the number of parameters in a set. The default value is 7. This isn't fixed to 7. This allows you to
calculate/add additional parameters (such as flag values) to each object.

rand_obs_vals is a pointer-to-a-pointer structure. It has the same layout as rand_obs_vals in CalcObsParams(). This allows the output of
CalcObsParams() to be directly input to this function.

obs_stats is a pointer-to-a-pointer. It contains the results of the analysis. Memory must be allocated for this structure prior to calling
this function. It should be allocated as a pointer to NOparams pointers to 8 values e.g. 
obs_stats = new float * [NOparams]; for(i = 0; i < NOparams; ++i){ obs_stats[i] = new float[8]; }.

vb_flag is an integer value. It sets the verbosity of the function. -1 = none, 0 = minimal and 1 = maximal.

Output:

A statistical analysis of NOparams from NOr sets of parameter values. For each parameter, this function returns, in order: median,
inter-quartile range (in standard deviations), minimum, maximum, mean, standard deviation, skewness & kurtosis.

4. ApproxObsCovar
-----------------
This function assumes an unknown, linear dependence of observational parameters on the BF fit values. Under this assumption, a numerical
approximation of the Jacobian of the observational parameters w.r.t. the Bf fits is calculated (J), and applied to the BF fit covariance 
matrix (C). The result of J^T*C*J is a linear approximation of the observational parameter covariance matrix.

Usage:
ApproxObsCovar(fit_type,NOvals,x_vals,fit_params,fit_covar,obs_covar,fit_x_min,fit_x_max);

Input:

fit_type is an integer value. It is the value returned by FitBusyFunc().

NOvals is an integer value. It is the number of data points that was used in FitBusyFunc().

x_vals is an array (as a pointer). It is the x values that were used in FitBusyFunc().

fit_params is the 17 element array (as a pointer) returned by FitBusyFunc().

fit_covar is the 64 element array (as a pointer) returned by FitBusyFunc().

obs_covar is a pointer-to-a-pointer. It is a pointer to 7 pointers to 7 values. Memory for this structure must be allocated before
calling this function e.g. obs_covar = new float[7]; for(i = 0; i < 7; ++i){ obs_covar[i] = new float[7]; }. The linear approximation
of the observational parameter covariance matrix is returned in this structure.

fit_x_min is the lower limit input to FitBusyFunc(). It *MUST* be identical to the value used to generate fit_params and fit_covar
using FitBusyFunc().

fit_x_max is the upper limit input to FitBusyFunc(). It *MUST* be identical to the value used to generate fit_params and fit_covar
using FitBusyFunc().

Output:

A 7 by 7, linear approximation to the observational parameter covariance matrix is returned in obs_covar. Running from top to bottom and left
to right, the covariance elements correspond to: total flux, peak flux, peak flux position, W_50 width, W_50 centre, W_20 width & W_20 centre. 


---------------------------------------
Python core functionality
---------------------------------------

Usage: 

dims, fit_params, fit_covar = BusyFunc.fit(x_vals,y_vals,y_err_vals,verbose_flag,x_min,x_max,NOs,iter_max) 

Input: 
This package takes eight arguments. The first three are lists containing the x values, y values and errors in the y values. A 
list of "1"s should be used when you don't have/want to use uncertainties in the y values. Alternatively, spuriously large 
uncertainties can be assigned to y values that you want the fitting program to ignore eg. channels dominated by RFI in 
integrated HI spectra.

The verbose_flag specifies the amount of diagnostic output displayed on the terminal. Values of -1, 0 and 1 generate none, 
minimal, and maximal diagnostic output.

The x_min and x_max values specifies the region within the data believed to contain signal. This can be set to x_vals[0] and 
x_vals[len(x_vals) - 1] without causing any problems. If you know that the first 10 and last 20 values are noise however, 
setting x_min and x_max accordingly will improve your fitting results. 

The number of randomly generated Levenberg-Marquardt seeds used to carry out the fitting is specified by NOs. The maximum 
number of LVM iterations applied to each seed is specified by iter_max. If you don't wish to use random LVM seeds, then NOs 
can be set to -1, and the values in the fit_params array will be used as the sole LVM seed. In this situation, the x_min and
x_max limits are set to: 

x_min = max{x_vals[0],(0.5*(fit_params[4] + fit_params[8]) - 0.5*(fit_params[8] - fit_params[4]))}
x_max = min{x_vals[(NOvals - 1)],(0.5*(fit_params[4] + fit_params[8]) + 0.5*(fit_params[8] - fit_params[4]))}

Output:
This package returns a 4-tuple containg two integers and two lists. The first tuple value is an integer value. It corresponds
to the BF variant that is the best fit. The second tuple value is also an integer value. It is the dimensionality of the Busy 
Function fit. Possible values are 4 through 8. The second tuple is a list. This list contains 17 float values. The first 16 
are the Busy Function fit values and their uncertainties. The final value is the chi-squared value of the Busy Function fit. 
The second list is 64 float values in a list of lists structure (8 lists of 8). This structure contains the covariance matrix 
of the Busy Function fit. The covariance matrix can be used to check for degeneracies in the Busy Function fit.


---------------------------------------
Python extended functionality
---------------------------------------

1. refine
---------
Fit a busy function using a single, user-specified starting position. This function uses a user specified number of iterations, iter_max, to improve upon a starting position. This function can be used to refine the output from this module's .fit method.

Usage: 

fit_type,dims,fit_params,fit_covar = BusyFunc.fit(x_vals,y_vals,y_err_vals,verbose_flag,x_min,x_max,NOs,iter_max,start_position) 

Input:
All the inputs of BusyFunc.fit and an extra list at the end. This list at the end, start_position, has the same structure as the fit_params output of BusyFunc.fit(). This makes it easy to use this function to improve upon the results of a call to BusyFunc.fit(). Note that this method *ONLY* uses the 8 fit parameter values in start_position. The uncertainties and chi^2 value are superfluous. They can be set to arbitrary values without affecting this method's output.

2. rand_fits
------------
Generate random variations of a Busy Function fit using the fit and its covariance matrix.

Usage: 

rand_fits = (NOr,fit_type,fit_params,fit_covar,x_min,x_max,vb_flag)

Input:
The inputs, in order, are: the number of random fits to create; the numerical ID of the BF fit type returned by BusyFunc.fit() --- values range from 1 to 6; the BF fit parameters list returned by BusyFunc.fit(); the list of 8 lists structure returned by BusyFunc.fit() that contains the covariance matrix; the next two values are the x_min and x_max values input to BusyFunc.fit(), and the final value is a verbose flag --- -1, 0 and 1 generate none, minimal, and maximal diagnostic output.

It is *VERY* important that the x_min and x_max values match those used in BusyFunc.fit() (& BusyFunc.refine()), or the internal variable mapping used to constrain the fit parameters will be wrong. This will not cause a fault in this method (it has no way to tell what x_min and x_max should be!), but it will cause erroneous output.

Output: 
The output is a list of lists structure. It consists of NOr lists of 8 float values. Each list of 8 values is a properly correlated, random variant of the input Busy Function (fit_params).

3. obs_vals
-----------
Calculate 7 observational parameters for each Busy Function fit supplied by the user. 

Usage: 

obs_vals = BusyFunc.obs_vals(BF_fits,x_vals,vb_flag)

Input:
The inputs, in order, are: a list of lists structure containing 8 Busy Function fit values for each object; the x values of the input data, and the final value is a verbose flag --- -1, 0 and 1 generate none, minimal, and maximal diagnostic output. The BF_fits list of lists structure matches the structure of the BusyFunc.rand_fits output. These two methods can be chained together. In this instance, BF_fits is equal to rand_fits.

Output:
The output is a list of lists structure. There is a list of 7 float values for each set of 8 Busy Function parameter values in the input list (BF_fits). Each list of 7 float values is a set of observational parameter values --- total intensity, peak intensity, peak intensity position, W_50, W_50 centre, W_20, W_20 centre.

4. obs_stats
------------
Calculate 8 statistical properties for a list of obesrvational values. 

Usage: 

obs_stats = BusyFunc.obs_stats(obs_vals,vb_flag)

Input:
The inputs, in order, are: a list of observational properties, and a verbose flag --- -1, 0 and 1 generate none, minimal, and maximal diagnostic output.

Output:
The output is a list of 8 statistical properties for each of the 7 observational properties (see BusyFunc.obs_vals()). This is stored in a list of lists structure. 7 lists of 8 float values. These 8 float values are (in order): median; inter-quartile range scaled to standard deviations; minimum; maximum; mean; standard deviation; skewness, and kurtosis.

5. approx_obs_covar
-------------------
Calculate an approximation of the observable parameter covariance matrix from a busy function fit and covariance matrix. This covariance matrix and the corresponding uncertainties in the observable parameters are returned.

Usage: 

approx_errs, approx_obs_covar = BusyFunc.approx_obs_covar(fit_type,x_vals,fit_params,fit_covar,x_min,x_max)

Input:
The input is an integer, 2 lists of floats, a list of lists structure (8 of 8), and two floats. 

The fit_type is the BF variant ID returned by BusyFunc.fit --- values 1 through 6.
x_vals is the same as BusyFunc.fit().
fit_params and fit_covar are the BusyFunc.fit() and BusyFunc.refine() output.
x_min and x_max are the float values used to do the internal mapping.

It is *VERY* important that the x_min and x_max values match those used in BusyFunc.fit() (& BusyFunc.refine()), or the internal variable mapping used to constrain the fit parameters will be wrong. This will not cause a fault in this method (it has no way to tell what x_min and x_max should be!), but it will cause erroneous output.

Output:
The first tuple element is a list of observational parameter uncertainties. The second is a list of lists structure. 7 lists of 7 float values. 

approx_obs_covar = ([total_flux x total flux, total flux x peak flux, total flux x peak flux position, total flux x W_50, total flux x W_50 centre, total flux x W_20, total flux x W_20 centre],[peak flux x total flux, peak flux x peak flux, peak flux x peak flux position, peak flux x W_50, peak flux x W_50 centre, peak flux x W_20, peak flux x W_20 centre],[peak flux position x total flux, peak flux position x peak flux, peak flux position x peak flux position, peak flux position x W_50, peak flux position x W_50 centre, peak flux position x W_20, peak flux position x W_20 centre],[W_50 x total flux, W_50 x peak flux, W_50 x peak flux position, W_50 x W_50, W_50 x W_50 centre, W_50 x W_20, W_50 x W_20 centre],[W_50 centre x total flux, W_50 centre x peak flux, W_50 centre x peak flux position, W_50 centre x W_50, W_50 centre x W_50 centre, W_50 centre x W_20, W_50 centre x W_20 centre],[W_20 x total flux, W_20 x peak flux, W_20 x peak flux position, W_20 x W_50, W_20 x W_50 centre, W_20 x W_20, W_20 x W_20 centre],[W_20 centre x total flux, W_20 centre x peak flux, W_20 centre x peak flux position, W_20 centre x W_50, W_20 centre x W_50 centre, W_20 centre x W_20, W_20 centre x W_20 centre])


Common to C/C++ & Python
---------------------------------------

Output structure:

fit_params = 
	     (alpha, alpha error,
	     beta_1, beta_1 error,
	     gamma_1, gamma_1 error,
	     beta_2, beta_2 error,
	     gamma_2, gamma_2 error
	     phi, phi error,
	     theta, theta error,
	     N, N error,chi^2 value)

fit_covar = (alpha x alpha, alpha x beta_1, alpha x gamma_1, alpha x beta_2, alpha x gamma_2, alpha x phi, alpha x theta, alpha x N
	    beta_1 x alpha, beta_1 x beta_1, beta_1 x gamma_1, beta_1 x beta_2, beta_1 x gamma_2, beta_1 x phi, beta_1 x theta, beta_1 x N
	    gamma_1 x alpha, gamma_1 x beta_1, gamma_1 x gamma_1, gamma_1 x beta_2, gamma_1 x gamma_2, gamma_1 x phi, gamma_1 x theta, gamma_1 x N
	    beta_2 x alpha, beta_2 x beta_1, beta_2 x gamma_1, beta_2 x beta_2, beta_2 x gamma_2, beta_2 x phi, beta_2 x theta, beta_2 x N
	    gamma_2 x alpha, gamma_2 x beta_1, gamma_2 x gamma_1, gamma_2 x beta_2, gamma_2 x gamma_2, gamma_2 x phi, gamma_2 x theta, gamma_2 x N
	    phi x alpha, phi x beta_1, phi x gamma_1, phi x beta_2, phi x gamma_2, phi x phi, phi x theta, phi x N
	    theta x alpha, theta x beta_1, theta x gamma_1, theta x beta_2, theta x gamma_2, theta x phi, theta x theta, theta x N
	    N x alpha, N x beta_1, N x gamma_1, N x beta_2, N x gamma_2, N x phi, N x theta, N x N)

